# 04 · Intégration audio, JNI et Kotlin

Contexte (audit existant) : Oboe (AAudio, float, stéréo), un synthé FluidSynth 2.6.0 avec 16 canaux MIDI (pistes 0..7, Drum = 8, TonicPad = 9), un sampler DrumPad. **Ne change rien d'autre que ce qui est demandé.** Lis **une seule fois** les en-têtes `fluidsynth/synth.h` et `settings.h` de la version vendue pour confirmer les signatures citées (`fluid_synth_nwrite_float`, `fluid_synth_set_gen`, `fluid_synth_pitch_wheel_sens`, réglages `synth.audio-channels`, `synth.audio-groups`).

## Étape 1 · Bibliothèque
Copie les `fx_*.h` à plat dans `app/src/main/cpp/aetherfx/`, `target_include_directories(native-lib PRIVATE aetherfx)`, `minSdk 26`. Compile. Lance les tests hôte (05).

## Étape 2 · Une sortie stéréo par canal
Dans `SoundfontEngine::init`, avant la création du synthé : `synth.audio-channels = 16`, `synth.audio-groups = 16` (canal i vers groupe i), `synth.chorus.active = 0`, `synth.reverb.active = 0`. Remplace le rendu mono-mix par un rendu multi-canaux (`fluid_synth_nwrite_float`) qui remplit des tampons **préalloués à l'ouverture du flux** (taille max = rafale × 4, au moins 2048 images, jamais de `resize` dans le rappel). Le `synth.sample-rate` doit être celui du **flux réel** (`stream->getSampleRate()`).
**Mise à niveau du volume** : fixe CC7 = 127 et CC10 = 64 sur chaque canal ; le volume et la balance passent par les strips. Gain par défaut d'un strip = (108/127)² = 0,723 pour garder le niveau actuel.
**Test obligatoire** : strips à gain 1, effets vides : la somme des groupes doit égaler l'ancien mix à 1e-5 sur un morceau de test. Écris ce test et rapporte le résultat.

## Étape 3 · `FxMixer` dans l'AudioEngine
- Membre `aetherfx::FxMixer mFx;` ; `mFx.prepare(sampleRate, maxBlock)` à l'ouverture du flux (et si le taux change).
- Dans le rappel audio :
```
renderChannels(L[], R[], n)                       // étape 2
for s in 0..9:  interleave(L[s],R[s]) -> scratch
                if (mFx.soundfontPaused(s)) -> scratch = 0          // la source remplace
                mFx.processStrip(s, scratch, n); mix += scratch
sampler.render(scratch, n); mFx.processStrip(10, scratch, n); mix += scratch
mFx.processMaster(mix, n); -> sortie (float, ou int16 avec écrêtage)
```
- **Supprime du rappel** : `std::mutex`/`mRenderMutex`, `LOGI`, `pthread_setschedparam`, tout `resize`. Remplace-les par des compteurs atomiques lus depuis le thread de contrôle (`getXRunCount()`, `calculateLatencyMillis()`). Liste d'abord tous les endroits qui prennent ces verrous et remplace chaque usage concurrent par la file d'événements existante.
- **Supprime l'ancienne chaîne d'effets** (EQ, Goodizer, Reverb, Delay, Chorus, Compressor, Widener, Punch, PadFilter, SoftClipper, `processMasterChain`, setters JNI/Kotlin associés) **seulement après** compilation propre. Liste les fichiers concernés avant de les effacer.
- Le chemin de secours (`renderDirect`/`FallbackSynth`) doit appeler **exactement le même** code de rendu.

## Étape 4 · Notes vers les sources
Quand `mFx.soundfontPaused(strip)` est vrai : les notes de la piste vont à `mFx.noteOn/noteOff/pitchBend(strip, …)` **au lieu de** FluidSynth (même thread audio que la file MIDI existante). Au changement d'instrument, envoyer `fluid_synth_all_notes_off(chan)` et `mFx.allNotesOff(strip)` pour éviter les notes bloquées. La pédale de sustain n'est pas gérée par les sources en v1 (documente-le).

## Étape 5 · Façonneurs : décalages de générateurs
- Calcul : `GenUpdate u = mFx.instrumentGens(strip)` (thread de contrôle) après chaque changement de paramètre, de preset ou d'instrument. `u.gens` = liste (générateur, valeur) à **ajouter** au soundfont ; `u.perf.strumSpreadMs` et `u.perf.bendSemis` = options de notes.
- Application : `fluid_synth_set_gen(synth, canal, gen, valeur)` pour chaque couple, **seulement ceux qui ont changé** (compare avec les dernières valeurs envoyées). **Attention au thread** : avec `synth.threadsafe-api = 0` (recommandé), tout appel FluidSynth doit se faire sur le thread audio : poste une commande `SET_GEN(canal, gen, valeur)` dans la file d'événements existante et exécute-la dans le rappel. Quand l'instrument est retiré ou remplacé par une source : renvoie 0 pour tous les générateurs précédemment modifiés.
- Ré-applique tous les décalages après un changement de preset, de banque ou un « reset all controllers » sur ce canal (non vérifié : vérifie une fois, sur un soundfont réel, que les décalages persistent et agissent sur les notes déjà jouées ; sinon passe par NRPN).
- `strumSpreadMs` : quand plusieurs notes d'une même piste arrivent dans une fenêtre de 8 ms, retarde la n-ième de `n × spread / nbNotes`. `bendSemis` : `fluid_synth_pitch_wheel_sens(synth, canal, semitones)` via la même file.
- Détail des décalages par instrument : 02.

## Étape 6 · JNI et Kotlin (`NativeAudioBridge`)
Supprime les anciens `external fun` d'effets. Ajoute (strip : 0..7 pistes, 8 Drum, 9 TonicPad, 10 sampler, **15 = Master**). Tout est appelé depuis le thread de contrôle sauf mention :
| Fonction | Rôle |
|---|---|
| `fxPrepare(sampleRate, maxBlock)` | à l'ouverture du flux |
| `fxSetInstrument(strip, id): Boolean` | id ≥ 0 ; `-1` = soundfont seul ; refus si strip ≠ 0..7 ou id est un effet |
| `fxSetInstrumentParam(strip, idx, norm)` | atomique, appelable à 60 Hz |
| `fxApplyInstrumentPreset(strip, preset): Boolean` | |
| `fxSetInstrumentBypass(strip, b)` | |
| `fxGetInstrumentId(strip): Int` · `fxSoundfontPaused(strip): Boolean` | |
| `fxSetEffect(strip, slot, id): Boolean` | id = −1 vide ; refus si l'id n'est pas un effet ; 6 slots (0..5), 8 sur le Master |
| `fxSetParam(strip, slot, idx, norm)` · `fxSetBypass(strip, slot, b)` · `fxApplyPreset(strip, slot, preset): Boolean` | |
| `fxGetEffectId(strip, slot): Int` · `fxGetMeter(strip, slot, i): Float` | vumètres (30 Hz côté UI) |
| `stripSetGain(strip, lin)` · `stripSetPan(strip, −1..1)` · `stripSetMute(strip, b)` · `stripPeak(strip, canal): Float` | solo géré en Kotlin (mute des autres) |
| `fxInstrumentGens(strip)` | renvoie le tableau (gen, valeur) + strum + bend pour l'étape 5 |
| `fxMatchShaper(fxId, nomPreset, programmeGM, banque, notePlusBasse, notePlusHaute): Int` | 0 = Ok, 1 = Weak, 2 = Mismatch (`fx_match.h`) |
| `fxCollectGarbage()` | toutes les ~500 ms et après chaque `fxSetEffect`/`fxSetInstrument` |
Côté audio (pas d'appel Kotlin) : `mFx.noteOn/noteOff/pitchBend/allNotesOff`, `processStrip`, `processMaster`.
Place `FxRegistry.kt` dans le projet (adapte le `package`). Les valeurs de l'interface sont toujours normalisées 0..1 ; `FxRegistry.toReal` convertit pour l'affichage.

## Étape 7 · Latence et sécurité
Le Ceiling du Master a une anticipation de 48 échantillons à 48 kHz (1 ms), déjà compensée dans l'effet : n'ajoute rien. Tous les effets et instruments sont sans allocation ni verrou dans `process`. L'ajout, le retrait et le changement d'effet passent par un échange de pointeur atomique ; l'ancien effet est détruit par `collectGarbage()` après 3 blocs.

## Étape 8 · Limites de ressources (à respecter)
Synth : unison plafonné à `48 / voix max` ; Organ : coût proportionnel aux roues actives. Echo : ~512 Ko de ligne à retard par instance. Ne pré-alloue rien dans le rappel.
