// AetherFX test bench, part 2: Amp, Bass, Voices, shapers, match, Organ, Synth, instrument slot, registry. Exit code != 0 on failure.
#include <chrono>
#include <complex>
#include <cstdio>
#include <random>
#include <thread>
#include "fx_chain.h"
#include "fx_match.h"
#include "fx_mixer.h"
using namespace aetherfx;
static int fails = 0, checks = 0;
#define CHECK(cond, ...) do { ++checks; if (!(cond)) { ++fails; std::printf("  FAIL: "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)
static const double SR = 48000.0;
using Buf = std::vector<float>;

static Buf sineBuf(double f, double amp, int frames) { Buf b(frames * 2); for (int i = 0; i < frames; ++i) { float s = float(amp * std::sin(2 * kPi * f * i / SR)); b[2 * i] = b[2 * i + 1] = s; } return b; }
static Buf noiseBuf(double amp, int frames, unsigned seed = 1) { std::mt19937 r(seed); std::normal_distribution<float> d(0.f, float(amp)); Buf b(frames * 2); for (auto& v : b) v = d(r); return b; }
static void run(Effect& e, Buf& b, int block = 256) { int fr = int(b.size() / 2); for (int p = 0; p < fr; p += block) e.process(&b[2 * p], std::min(block, fr - p)); }
static double goertzel(const Buf& b, int from, int to, double f) {  // left channel, returns amplitude
  double w = 2 * kPi * f / SR, c = 2 * std::cos(w), s1 = 0, s2 = 0; int n = to - from;
  for (int i = from; i < to; ++i) { double s = b[2 * i] + c * s1 - s2; s2 = s1; s1 = s; }
  return std::sqrt(s1 * s1 + s2 * s2 - c * s1 * s2) * 2.0 / n;
}
static double db(double x) { return 20 * std::log10(x + 1e-12); }
static double rmsDb(const Buf& b, int from, int to) { double s = 0; for (int i = from; i < to; ++i) s += double(b[2 * i]) * b[2 * i]; return 10 * std::log10(s / (to - from) + 1e-20); }
static bool finite(const Buf& b, double lim = 1.12) { for (float x : b) if (!std::isfinite(x) || std::fabs(x) > lim) return false; return true; }
static double thd(const Buf& b, double f) { double f1 = goertzel(b, 24000, 48000, f), h = 0; for (int k = 2; k <= 7; ++k) { double a = goertzel(b, 24000, 48000, f * k); h += a * a; } return std::sqrt(h) / (f1 + 1e-12); }
static void setAll(Effect& e, int n, const float* v) { for (int i = 0; i < n; ++i) e.setNorm(i, v[i]); }
static void preset(Effect& e, int id, int idx) { const auto& p = info(id).presets[idx].v; setAll(e, int(p.size()), p.data()); }

static void testAmp() {
  std::printf("[AMP] Aether Amp\n");
  auto run1 = [&](int chan, float gain, float mpos) { AmpFx a; a.prepare(SR, 256); preset(a, FX_AMP, 0); a.setNorm(6, chan * 0.5f); a.setNorm(0, gain); a.setNorm(7, mpos); a.setNorm(11, 0.8f); Buf b = sineBuf(1000, 0.1, 96000); run(a, b); return b; };
  double t1 = thd(run1(0, .1f, .3f), 1000), t2 = thd(run1(0, .9f, .3f), 1000), t3 = thd(run1(1, .8f, .3f), 1000), t4 = thd(run1(2, .9f, .3f), 1000);
  std::printf("  THD clean g.1 %.3f | clean g.9 %.3f | crunch g.8 %.3f | lead g.9 %.3f\n", t1, t2, t3, t4);
  CHECK(t2 > t1 * 3, "gain must raise distortion"); CHECK(t3 > t2 * 0.9, "crunch >= clean at similar gain"); CHECK(t4 > 0.15, "lead must be heavily distorted: %.3f", t4);
  { Buf a = run1(0, .1f, 0.f), c = run1(0, .1f, 1.f); Buf a4 = sineBuf(4500, .1, 96000), c4 = a4; AmpFx x, y; x.prepare(SR, 256); y.prepare(SR, 256); preset(x, FX_AMP, 0); preset(y, FX_AMP, 0); x.setNorm(7, 0.f); y.setNorm(7, 1.f); x.setNorm(0, .1f); y.setNorm(0, .1f); run(x, a4); run(y, c4);
    double d = db(goertzel(a4, 24000, 48000, 4500)) - db(goertzel(c4, 24000, 48000, 4500)); std::printf("  mic centre vs edge at 4.5 kHz: %.1f dB\n", d); CHECK(d > 3.0, "mic position must darken the sound (%.1f dB)", d); }
  { AmpFx lo, hi; lo.prepare(SR, 256); hi.prepare(SR, 256); preset(lo, FX_AMP, 0); preset(hi, FX_AMP, 0); lo.setNorm(1, .1f); hi.setNorm(1, .9f); lo.setNorm(0, .05f); hi.setNorm(0, .05f);
    Buf a = sineBuf(120, .05, 96000), c = a; run(lo, a); run(hi, c); double d = db(goertzel(c, 24000, 48000, 120)) - db(goertzel(a, 24000, 48000, 120)); std::printf("  bass knob .9 vs .1 at 120 Hz: %+.1f dB\n", d); CHECK(d > 8.0, "bass control %.1f dB", d); }
  { AmpFx a; a.prepare(SR, 256); preset(a, FX_AMP, 0); a.setNorm(10, 1.f); a.setNorm(0, .05f); Buf b = sineBuf(1000, .1, 96000); run(a, b); double mn = 1e9, mx = -1e9; for (int w = 24000; w < 96000 - 2400; w += 2400) { double r = rmsDb(b, w, w + 2400); mn = std::min(mn, r); mx = std::max(mx, r); } std::printf("  tremolo swing: %.1f dB\n", mx - mn); CHECK(mx - mn > 3.0, "tremolo depth"); }
  { std::mt19937 r(5); bool ok = true; for (int t = 0; t < 120 && ok; ++t) { AmpFx a; a.prepare(SR, 256); for (int i = 0; i < 12; ++i) a.setNorm(i, std::uniform_real_distribution<float>(0, 1)(r)); Buf b = noiseBuf(.5, 9600, t); run(a, b); ok = finite(b); } CHECK(ok, "amp output must stay finite and bounded"); }
}
static void testBass() {
  std::printf("[BASS] Aether Bass\n");
  { BassAmp b; b.prepare(SR, 256); float v[10] = {0, 0, 0, .5f, .5f, .5f, .5f, .5f, .5f, .8f}; setAll(b, 10, v); Buf x = sineBuf(1000, .1, 48000); run(b, x); double g = db(goertzel(x, 24000, 48000, 1000)) - db(.1); std::printf("  DI path, flat EQ: %+.1f dB at 1 kHz\n", g); CHECK(std::fabs(g) < 1.5, "DI path must be transparent (%.1f)", g); }
  { BassAmp b; b.prepare(SR, 256); float v[10] = {0, 0, 0, .5f, .5f, 1.f, .5f, .5f, .5f, .8f}; setAll(b, 10, v); Buf x = sineBuf(1000, .1, 48000); run(b, x); double g = db(goertzel(x, 24000, 48000, 1000)) - db(.1); std::printf("  1 kHz band +12: %+.1f dB\n", g); CHECK(g > 9.5 && g < 14.5, "graphic EQ gain %.1f", g); }
  { BassAmp lo, hi; lo.prepare(SR, 256); hi.prepare(SR, 256); float v[10] = {0, 0, 1.f, .5f, .5f, .5f, .5f, .5f, 0.f, .8f}, w[10]; std::memcpy(w, v, sizeof v); w[8] = 1.f; setAll(lo, 10, v); setAll(hi, 10, w);
    Buf a = sineBuf(6000, .1, 48000), c = a; run(lo, a); run(hi, c); double d = db(goertzel(c, 24000, 48000, 6000)) - db(goertzel(a, 24000, 48000, 6000)); std::printf("  8x10 vs 1x15 at 6 kHz: %+.1f dB\n", d); CHECK(d > 3.0, "cab types must differ (%.1f)", d); }
  { BassAmp c0, c1; c0.prepare(SR, 256); c1.prepare(SR, 256); float v[10] = {0, 0, 0, .5f, .5f, .5f, .5f, .5f, .5f, .8f}; setAll(c0, 10, v); v[1] = 1.f; setAll(c1, 10, v); Buf a = sineBuf(100, .6, 48000), c = a; run(c0, a); run(c1, c); std::printf("  gain reduction meter: comp 0 -> %.1f dB, comp 1 -> %.1f dB\n", c0.meter(0), c1.meter(0)); CHECK(c1.meter(0) > c0.meter(0) + 2.0, "compressor must act"); }
  { std::mt19937 r(6); bool ok = true; for (int t = 0; t < 120 && ok; ++t) { BassAmp a; a.prepare(SR, 256); for (int i = 0; i < 10; ++i) a.setNorm(i, std::uniform_real_distribution<float>(0, 1)(r)); Buf b = noiseBuf(.5, 9600, t); run(a, b); ok = finite(b); } CHECK(ok, "bass output must stay finite and bounded"); }
}
static void testVoices() {
  std::printf("[VOX] Aether Voices\n");
  float f[3]; VoicesFx::formants(.5f, .1f, f); std::printf("  vowel A -> F1 %.0f F2 %.0f F3 %.0f Hz\n", f[0], f[1], f[2]); CHECK(std::fabs(f[0] - 800) < 80 && std::fabs(f[1] - 1150) < 120, "vowel A formants");
  VoicesFx::formants(.1f, .9f, f); CHECK(std::fabs(f[1] - 2290) < 230, "vowel I formants %.0f", f[1]);
  auto band = [&](Buf& b, double c) { double s = 0; for (int k = -3; k <= 3; ++k) s += goertzel(b, 12000, 96000, c * (1 + .03 * k)); return s; };
  VoicesFx a, i2; a.prepare(SR, 256); i2.prepare(SR, 256); float va[9] = {.5f, .1f, 0, 0, 0, .5f, 0, 0, .8f}, vi[9] = {.1f, .9f, 0, 0, 0, .5f, 0, 0, .8f}; setAll(a, 9, va); setAll(i2, 9, vi);
  Buf x = noiseBuf(.1, 96000), y = x; run(a, x); run(i2, y);
  double rA = db(band(x, 2300)) - db(band(x, 800)), rI = db(band(y, 2300)) - db(band(y, 800)); std::printf("  F2/F1 energy: A %.1f dB, I %.1f dB\n", rA, rI); CHECK(rI > rA + 6.0, "vowels must change the spectrum");
  CHECK(finite(x) && finite(y), "voices finite");
  { std::mt19937 r(7); bool ok = true; for (int t = 0; t < 80 && ok; ++t) { VoicesFx v; v.prepare(SR, 256); for (int k = 0; k < 9; ++k) v.setNorm(k, std::uniform_real_distribution<float>(0, 1)(r)); Buf b = noiseBuf(.5, 9600, t); run(v, b); ok = finite(b); } CHECK(ok, "voices bounded"); }
}
static void testShapers() {
  std::printf("[SHAPE] instrument shapers + match\n");
  const int ids[5] = {FX_PIANO, FX_SAX, FX_STRINGS, FX_GUITAR, FX_BRASS};
  std::mt19937 r(9); bool ok = true;
  for (int id : ids) for (int t = 0; t < 300; ++t) { float v[16]; for (auto& z : v) z = std::uniform_real_distribution<float>(0, 1)(r); GenSet g; PerfSet pf; computeGens(id, v, g, pf); if (g.n > 12) ok = false; for (int k = 0; k < g.n; ++k) if (!std::isfinite(g.val[k]) || std::fabs(g.val[k]) > 4000.f) ok = false; if (pf.bendSemis < 2 || pf.bendSemis > 12 || pf.strumSpreadMs > 60.001f) ok = false; }
  CHECK(ok, "generator offsets in range");
  { float v[9] = {0, .5f, .5f, .5f, .5f, .5f, .5f, .5f, .8f}; GenSet a, b; PerfSet pf; computeGens(FX_PIANO, v, a, pf); v[0] = 1.f; computeGens(FX_PIANO, v, b, pf); std::printf("  piano felt 0 -> 1: filter %+.0f -> %+.0f cents\n", a.val[0], b.val[0]); CHECK(b.val[0] < a.val[0], "softer felt = darker"); }
  { float v[11] = {0, .5f, .4f, 0, 0, .5f, .3f, .5f, .5f, .3f, .8f}; GenSet a; PerfSet pf; computeGens(FX_GUITAR, v, a, pf); v[3] = 1.f; GenSet b; computeGens(FX_GUITAR, v, b, pf); bool rel = false; for (int k = 0; k < b.n; ++k) if (b.gen[k] == GEN_VOLENVRELEASE && b.val[k] < -1000.f) rel = true; CHECK(rel, "palm mute shortens release"); }
  { ShaperFx open(FX_BRASS), harmon(FX_BRASS); open.prepare(SR, 256); harmon.prepare(SR, 256); float v[9] = {.5f, .3f, 0, 0, 0, .5f, .5f, 0, .8f}; setAll(open, 9, v); v[4] = .75f; setAll(harmon, 9, v);
    Buf a = noiseBuf(.1, 96000), c = a; run(open, a); run(harmon, c); double d = db(goertzel(c, 12000, 96000, 1400)) - db(goertzel(a, 12000, 96000, 1400)) - (db(goertzel(c, 12000, 96000, 6000)) - db(goertzel(a, 12000, 96000, 6000))); std::printf("  harmon mute: 1.4 kHz vs 6 kHz relative: %+.1f dB\n", d); CHECK(d > 6.0, "harmon mute character"); }
  { bool fin = true; for (int id : ids) { ShaperFx s(id); s.prepare(SR, 256); for (int t = 0; t < 40; ++t) { for (int k = 0; k < 11; ++k) s.setNorm(k, std::uniform_real_distribution<float>(0, 1)(r)); Buf b = noiseBuf(.4, 4800, t); run(s, b); fin = fin && finite(b); } } CHECK(fin, "shapers finite and bounded"); }
  CHECK(matchShaper(FX_SAX, "Alto Sax", 65, 0) == Match::Ok, "sax on a sax");
  CHECK(matchShaper(FX_SAX, "Grand Piano", 0, 0) == Match::Mismatch, "sax on a piano warns");
  CHECK(matchShaper(FX_PIANO, "Bright Grand Piano", -1, -1) == Match::Ok, "name beats unknown program");
  CHECK(matchShaper(FX_GUITAR, "Jazz Kit", 0, 128) == Match::Mismatch, "guitar on a drum kit warns");
  CHECK(matchShaper(FX_STRINGS, "Violin", 40, 0) == Match::Ok && matchShaper(FX_BRASS, "Trumpet", 56, 0) == Match::Ok, "strings/brass ok");
  CHECK(matchShaper(FX_GUITAR, "", -1, -1) == Match::Weak, "unknown = weak");
}
static void testOrgan() {
  std::printf("[ORG] Aether Organ\n");
  auto mk = [&](std::vector<int> up) { auto o = std::make_unique<OrganEngine>(); o->prepare(SR, 256); for (int i = 0; i < 31; ++i) o->setNorm(i, 0.f); for (size_t j = 0; j < up.size(); ++j) o->setNorm(int(j), up[j] / 8.f); o->setNorm(27, .5f); o->setNorm(30, .8f); return o; };
  const double f72 = 440.0 * std::pow(2.0, 3.0 / 12.0);
  { auto o = mk({0, 0, 8, 0, 0, 0, 0, 0, 0}); o->noteOn(72, 100); Buf b(192000); run(*o, b); double a1 = goertzel(b, 24000, 96000, f72), a2 = goertzel(b, 24000, 96000, 2 * f72), a3 = goertzel(b, 24000, 96000, 3 * f72);
    std::printf("  8' only: fundamental %.1f dBFS, 2nd %.1f dB, 3rd %.1f dB below\n", db(a1), db(a1) - db(a2), db(a1) - db(a3)); CHECK(db(a1) - db(a2) > 40 && db(a1) - db(a3) > 40, "pure fundamental"); CHECK(a1 > .02, "audible"); }
  { auto o8 = mk({0, 0, 8, 0, 0, 0, 0, 0, 0}), o4 = mk({0, 0, 4, 0, 0, 0, 0, 0, 0}); o8->noteOn(72, 100); o4->noteOn(72, 100); Buf a(192000), c(192000); run(*o8, a); run(*o4, c); double d = db(goertzel(a, 24000, 96000, f72)) - db(goertzel(c, 24000, 96000, f72)); std::printf("  drawbar 8 vs 4: %.1f dB (3 dB per step -> 12)\n", d); CHECK(std::fabs(d - 12.0) < 1.5, "drawbar law %.1f", d); }
  { auto o = mk({8, 0, 0, 0, 0, 0, 0, 0, 0}); o->noteOn(72, 100); Buf b(192000); run(*o, b); double s = db(goertzel(b, 24000, 96000, f72 / 2)) - db(goertzel(b, 24000, 96000, f72)); std::printf("  16' only: sub-octave %+.1f dB vs fundamental\n", s); CHECK(s > 40, "16' = one octave below"); }
  { auto o = mk({0, 0, 8, 0, 0, 0, 0, 0, 0}); o->setNorm(18, 1.f); o->setNorm(20, 1.f); o->noteOn(72, 100); Buf b(192000); run(*o, b); double e0 = goertzel(b, 480, 480 + 4800, 2 * f72), e1 = goertzel(b, 60000, 90000, 2 * f72); std::printf("  percussion 2nd harmonic: start %.1f dB -> after 1.2 s %.1f dB\n", db(e0), db(e1)); CHECK(db(e0) - db(e1) > 15, "percussion must decay");
    o->noteOn(76, 100); Buf c(48000); run(*o, c); double e2 = goertzel(c, 2400, 14400, 2 * 659.26); CHECK(db(e2) < db(e0) - 12, "single trigger: no new percussion while a key is held"); }
  auto env = [&](Buf& b) { double mn = 1e9, mx = -1e9; for (int w = 24000; w < 96000 - 2400; w += 1200) { double r = rmsDb(b, w, w + 1200); mn = std::min(mn, r); mx = std::max(mx, r); } return mx - mn; };
  { auto stop = mk({0, 0, 8, 0, 0, 0, 0, 0, 0}), fast = mk({0, 0, 8, 0, 0, 0, 0, 0, 0}); stop->setNorm(25, 0.f); fast->setNorm(25, 1.f); stop->noteOn(86, 100); fast->noteOn(86, 100); Buf a(192000), c(192000); run(*stop, a); run(*fast, c); double es = env(a), ef = env(c); std::printf("  rotary: stop swing %.1f dB, fast swing %.1f dB\n", es, ef); CHECK(ef > es + 1.5 && es < 1.0, "rotary speaker modulation"); }
  { auto o = mk({8, 8, 8, 8, 8, 8, 8, 8, 8}); for (int i = 0; i < 9; ++i) o->setNorm(9 + i, 1.f); o->setNorm(28, .5f); for (int k = 48; k < 84; k += 4) o->noteOn(k, 120); Buf b(96000); run(*o, b); std::printf("  10 keys, all drawbars: peak %.3f, active wheels %d\n", [&] { float m = 0; for (float x : b) m = std::max(m, std::fabs(x)); return m; }(), o->activeWheels()); CHECK(finite(b), "full chord bounded");
    for (int k = 48; k < 84; k += 4) o->noteOff(k); Buf c(28800); run(*o, c); CHECK(rmsDb(c, 9600, 14400) < -60, "release to silence (%.1f dB)", rmsDb(c, 9600, 14400)); }
  { std::mt19937 r(10); bool ok = true; for (int t = 0; t < 40 && ok; ++t) { OrganEngine o; o.prepare(SR, 256); for (int i = 0; i < 31; ++i) o.setNorm(i, std::uniform_real_distribution<float>(0, 1)(r)); for (int k = 0; k < 6; ++k) o.noteOn(36 + int(r() % 60), 100); Buf b(19200); run(o, b); ok = finite(b); } CHECK(ok, "organ random params bounded"); }
}
static void testSynth() {
  std::printf("[SYN] Aether Synth\n");
  auto mk = [&]() { auto s = std::make_unique<SynthEngine>(); s->prepare(SR, 256); float base[32] = {0, 0, 0, 0, 0, 0, 0, 1.f, 0, 0, 0, 0, 0, .1f, 1.f, .4f, .3f, 0, 0, 0, .2f, 0, .5f, .5f, .5f, .5f, 0, 0, 1.f, .09f, .5f, .8f}; setAll(*s, 32, base); return s; };
  auto zc = [&](const Buf& b, int a, int c) { int n = 0; for (int i = a + 1; i < c; ++i) if (b[2 * (i - 1)] < 0 && b[2 * i] >= 0) ++n; return n * SR / (c - a); };
  { auto s = mk(); s->noteOn(69, 100); Buf b(192000); run(*s, b); double f = zc(b, 24000, 96000); std::printf("  sine, note 69: %.2f Hz (440)\n", f); CHECK(std::fabs(f - 440) < 1.0, "pitch accuracy"); }
  { auto s = mk(); s->noteOn(81, 100); Buf b(192000); run(*s, b); double f = zc(b, 24000, 96000); CHECK(std::fabs(f - 880) < 2.0, "octave %.1f", f); }
  { auto s = mk(); s->setNorm(0, .67f); s->noteOn(93, 100); Buf b(192000); run(*s, b); const double f0 = 440 * std::pow(2.0, 24.0 / 12); // 1760 Hz saw
    const int N = 4096, st = 30000; double sig = 0, alias = 0; int cnt = 0;
    for (int k = 20; k < N / 2; ++k) { double fr = k * SR / N, rem = std::fmod(fr, f0); double dist = std::min(rem, f0 - rem); std::complex<double> acc(0, 0); for (int i = 0; i < N; ++i) { double w = 0.5 - 0.5 * std::cos(2 * kPi * i / N); acc += w * double(b[2 * (st + i)]) * std::polar(1.0, -2 * kPi * k * i / N); }
      double mag = std::abs(acc); if (dist < 25) sig = std::max(sig, mag); else if (dist > 200) { alias = std::max(alias, mag); ++cnt; } }
    std::printf("  saw 1.76 kHz: strongest non-harmonic component %.1f dB below the fundamental\n", db(sig) - db(alias)); CHECK(db(sig) - db(alias) > 35, "alias suppression"); }
  { auto lp = mk(), op = mk(); lp->setNorm(0, .67f); op->setNorm(0, .67f); lp->setNorm(7, std::log(1000.0 / 20) / std::log(1000.0)); lp->noteOn(57, 100); op->noteOn(57, 100); Buf a(192000), c(192000); run(*lp, a); run(*op, c); double h = 3960; double d = db(goertzel(c, 24000, 96000, h)) - db(goertzel(a, 24000, 96000, h)); std::printf("  low-pass 1 kHz: 4 kHz harmonic %.1f dB lower\n", d); CHECK(d > 18, "filter slope %.1f", d); }
  { auto hp = mk(), op = mk(); hp->setNorm(0, .67f); op->setNorm(0, .67f); hp->setNorm(11, .33f); hp->setNorm(7, std::log(1000.0 / 20) / std::log(1000.0)); hp->noteOn(57, 100); op->noteOn(57, 100); Buf a(192000), c(192000); run(*hp, a); run(*op, c); double d = db(goertzel(c, 24000, 96000, 220)) - db(goertzel(a, 24000, 96000, 220)); std::printf("  high-pass 1 kHz: 220 Hz %.1f dB lower\n", d); CHECK(d > 15, "high-pass %.1f", d); }
  { auto s = mk(); s->setNorm(12, std::log(100.0) / std::log(4000.0)); s->noteOn(69, 127); Buf b(96000); run(*s, b); double mx = 0; for (int i = 0; i < 48000; ++i) mx = std::max(mx, double(std::fabs(b[2 * i]))); int t90 = -1; for (int i = 0; i < 48000 && t90 < 0; ++i) if (std::fabs(b[2 * i]) >= .9 * mx) t90 = i; std::printf("  attack set to 100 ms: 90%% reached at %.0f ms\n", t90 * 1000.0 / SR); CHECK(t90 / SR > .07 && t90 / SR < .13, "attack time"); }
  { auto s = mk(); s->setNorm(15, std::log(50.0) / std::log(500.0)); s->noteOn(69, 127); Buf b(48000); run(*s, b); s->noteOff(69); Buf c(192000); run(*s, c); double pk0 = 0, pk1 = 0; for (int i = 0; i < 480; ++i) pk0 = std::max(pk0, double(std::fabs(c[2 * i]))); for (int i = 24000; i < 24480; ++i) pk1 = std::max(pk1, double(std::fabs(c[2 * i]))); std::printf("  release 0.5 s: level after 0.5 s = %.2f of start (e^-1 = .37)\n", pk1 / pk0); CHECK(pk1 / pk0 > .2 && pk1 / pk0 < .55, "release time"); }
  { auto s = mk(); for (int k = 0; k < 8; ++k) s->noteOn(48 + 3 * k, 100); Buf b(9600); run(*s, b); CHECK(s->activeVoices() == 8, "8 notes = 8 voices (%d)", s->activeVoices()); auto t = mk(); t->setNorm(28, 3 / 15.f); for (int k = 0; k < 6; ++k) t->noteOn(48 + 3 * k, 100); Buf c(9600); run(*t, c); CHECK(t->activeVoices() <= 4, "voice limit (%d)", t->activeVoices()); }
  { auto s = mk(); s->setNorm(26, 1.f); s->setNorm(14, 1.f); s->noteOn(57, 100); Buf a(48000); run(*s, a); s->noteOn(69, 100); Buf b(96000); run(*s, b); double f = zc(b, 12000, 48000); CHECK(s->activeVoices() == 1 && std::fabs(f - 440) < 3, "mono voice follows the new note (%.1f Hz)", f); }
  { std::mt19937 r(11); bool ok = true; for (int t = 0; t < 40 && ok; ++t) { SynthEngine s; s.prepare(SR, 256); for (int i = 0; i < 32; ++i) s.setNorm(i, std::uniform_real_distribution<float>(0, 1)(r)); for (int k = 0; k < 10; ++k) s.noteOn(30 + int(r() % 70), 20 + int(r() % 100)); Buf b(48000); run(s, b); for (int k = 0; k < 5; ++k) s.noteOff(30 + int(r() % 70)); run(s, b); ok = finite(b); } CHECK(ok, "synth random params + notes bounded"); }
}
static void testChain() {
  std::printf("[TRACK] instrument slot + effects\n");
  TrackStrip t; t.prepare(SR, 256);
  CHECK(t.instrumentId() == -1 && !t.hasSource(), "no instrument by default");
  Buf sf = sineBuf(440, .3, 4800), keep = sf; t.process(sf.data(), 256); CHECK(std::fabs(sf[200] - keep[200] * 1.f) < 1.5f, "plain soundfont passes through");
  t.setInstrument(FX_ORGAN); CHECK(t.hasSource(), "organ is a source"); t.noteOn(60, 100); Buf b(96000); for (int p = 0; p + 256 <= 24000; p += 256) t.process(&b[2 * p], 256); CHECK(rmsDb(b, 12000, 24000) > -40, "organ sound reaches the track output");
  t.setInstrument(FX_SAX); CHECK(!t.hasSource() && t.instrumentId() == FX_SAX, "sax is a shaper"); t.setInstrument(-1); CHECK(t.instrumentId() == -1, "back to soundfont");
  FxStrip master(8, true); master.prepare(SR, 256); CHECK(master.chain.slots() == 8, "master has 8 slots");
  for (int i = 0; i < 6; ++i) CHECK(t.strip.chain.setEffect(i, i < 5 ? i : FX_AMP), "6 track effect slots");
  CHECK(!t.strip.chain.setEffect(0, FX_ORGAN), "an instrument can never be inserted as an effect");
  std::atomic<bool> run2{true}; std::thread ctl([&] { std::mt19937 r(2); while (run2.load()) { switch (r() % 4) { case 0: t.setInstrument(int(r() % 16) - 1); break; case 1: t.strip.chain.setEffect(int(r() % 6), int(r() % 14) - 1); break; case 2: t.instrument.setParam(0, int(r() % 20), (r() % 100) / 99.f); break; default: t.collectGarbage(); } std::this_thread::sleep_for(std::chrono::microseconds(300)); } });
  Buf x(1024); std::mt19937 rr(3); bool ok = true; auto t0 = std::chrono::steady_clock::now(); long blocks = 0;
  while (std::chrono::steady_clock::now() - t0 < std::chrono::seconds(3)) { for (auto& v : x) v = std::uniform_real_distribution<float>(-.5f, .5f)(rr); if (blocks % 7 == 0) t.noteOn(40 + int(rr() % 40), 100); if (blocks % 11 == 0) t.noteOff(40 + int(rr() % 40)); t.process(x.data(), 256); ++blocks; ok = ok && finite(x, 1e6); }
  run2 = false; ctl.join(); CHECK(ok, "random instrument/effect swapping while rendering stays finite"); std::printf("  rendered %ld blocks while swapping instruments and effects\n", blocks);
}
static void testMixer() {
  std::printf("[MIX] FxMixer facade\n");
  auto m = std::make_unique<FxMixer>(); m->prepare(SR, 256);
  CHECK(m->setInstrument(0, FX_SAX) && m->instrumentId(0) == FX_SAX, "instrument on a track");
  CHECK(!m->setInstrument(FxMixer::kMaster, FX_SAX) && !m->setInstrument(10, FX_PIANO) && !m->setInstrument(8, FX_ORGAN), "no instrument on master, drum-pad sampler or drum/tonic channels");
  CHECK(!m->setInstrument(1, FX_AMP) && !m->setEffect(1, 0, FX_ORGAN), "lots cannot be mixed up");
  CHECK(m->setEffect(0, 5, FX_VOICES) && m->setEffect(FxMixer::kMaster, 7, FX_CEILING) && !m->setEffect(FxMixer::kMaster, 8, FX_TONE), "6 slots per strip, 8 on the master");
  m->setInstrument(2, FX_PIANO); m->applyInstrumentPreset(2, 0); GenUpdate g = m->instrumentGens(2); CHECK(g.valid && g.gens.n > 0, "piano preset gives generator offsets");
  m->setInstrument(3, FX_ORGAN); CHECK(m->soundfontPaused(3) && !m->soundfontPaused(2), "only a source pauses the soundfont"); m->noteOn(3, 60, 100);
  Buf b(512, 0.f); for (int i = 0; i < 80; ++i) m->processStrip(3, b.data(), 256); CHECK(rmsDb(b, 0, 256) > -50, "source output on its strip");
  m->setInstrument(3, -1); CHECK(!m->soundfontPaused(3), "soundfont comes back");
  m->applyPreset(0, 5, 2); m->processMaster(b.data(), 256);
}
static void testRegistry() {
  std::printf("[REG] registry\n");
  bool ok = true; for (int id = 0; id < FX_COUNT; ++id) { const auto& e = info(id); if (e.params.empty() || int(e.params.size()) > kMaxParams) ok = false; for (const auto& pr : e.presets) { if (pr.v.size() != e.params.size()) { ok = false; std::printf("  preset size mismatch %s/%s\n", e.name, pr.name); } for (float v : pr.v) if (v < -1e-6f || v > 1.000001f) ok = false; } for (const auto& p : e.params) if (p.def < 0 || p.def > 1) ok = false; }
  CHECK(ok, "every preset has one value per parameter, all within 0..1");
  CHECK(info(FX_ORGAN).params.size() == 31 && info(FX_SYNTH).params.size() == 32 && kMaxParams >= 32, "organ 31 / synth 32 params fit");
  int effects = 0, shapers = 0, sources = 0; for (int id = 0; id < FX_COUNT; ++id) { auto k = kindOf(id); effects += k == Kind::Effect; shapers += k == Kind::Shaper; sources += k == Kind::Source; }
  std::printf("  %d effects, %d shapers, %d sources\n", effects, shapers, sources); CHECK(effects == 8 && shapers == 5 && sources == 2, "lot split");
  for (int id = 0; id < FX_COUNT; ++id) { auto e1 = makeEffect(id, false), e2 = makeInstrument(id); CHECK((kindOf(id) == Kind::Effect) == (e1 != nullptr) && (kindOf(id) != Kind::Effect) == (e2 != nullptr), "factory split for id %d", id); }
}
static void bench() {
  std::printf("[BENCH] CPU, 10 s of audio, block 256, this machine (-O2); phones are ~3-6x slower\n");
  auto time = [&](const char* name, auto fn) { auto t0 = std::chrono::steady_clock::now(); fn(); double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count(); std::printf("  %-34s %5.2f %% of one core\n", name, s / 10.0 * 100); };
  Buf x = noiseBuf(.3, 256);
  for (int id : {FX_AMP, FX_BASS, FX_VOICES}) { auto e = makeEffect(id); e->prepare(SR, 256); preset(*e, id, 0); time(info(id).name, [&] { for (int b = 0; b < 1875; ++b) e->process(x.data(), 256); }); }
  for (int id : {FX_PIANO, FX_STRINGS, FX_BRASS}) { auto e = makeInstrument(id); e->prepare(SR, 256); preset(*e, id, 0); time(info(id).name, [&] { for (int b = 0; b < 1875; ++b) e->process(x.data(), 256); }); }
  { OrganEngine o; o.prepare(SR, 256); preset(o, FX_ORGAN, 0); for (int k = 48; k < 72; k += 3) o.noteOn(k, 100); time("Aether Organ (8 keys)", [&] { for (int b = 0; b < 1875; ++b) o.process(x.data(), 256); }); }
  { SynthEngine s; s.prepare(SR, 256); preset(s, FX_SYNTH, 0); for (int k = 0; k < 8; ++k) s.noteOn(48 + 3 * k, 100); time("Aether Synth (8 voices, Pad)", [&] { for (int b = 0; b < 1875; ++b) s.process(x.data(), 256); }); }
}
int main() {
  testAmp(); testBass(); testVoices(); testShapers(); testOrgan(); testSynth(); testChain(); testMixer(); testRegistry(); bench();
  std::printf("\n%d checks, %d failed\n", checks, fails); return fails ? 1 : 0;
}
