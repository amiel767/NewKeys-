# 02 · Paramètres, presets et mappages audio

Source de vérité des valeurs : `fx_registry.h` (généré avec le même contenu que l'aperçu `fx-window-preview.html`). `FxRegistry.kt` en est la copie Kotlin générée. **Tous les paramètres sont normalisés 0..1** entre l'interface et le moteur ; la conversion en unités réelles se fait avec `min`/`max`/`curve` du registre.

Légende : *UI* = paramètre visuel seulement, jamais envoyé au moteur audio.


## 0 · Æther Space  —  Effet

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Size | 0 | 100 | % | 0.62 |  |
| 1 | Decay | 0.4 | 8 | s | 0.7 |  |
| 2 | Pre-delay | 0 | 120 | ms | 0.2 |  |
| 3 | Damp | 1 | 12 | kHz | 0.45 |  |
| 4 | Width | 0 | 100 | % | 0.8 |  |
| 5 | Mix | 0 | 100 | % | 0.35 |  |
| 6 | Diffuse | 0 | 100 | % | 0.5 |  |

Presets : `Hall`, `Plate`, `Room`, `Cathedral`, `Shimmer`, `Chamber`, `Bloom`, `Infinite`


## 1 · Æther Echo  —  Effet

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Time 1 | 10 | 1000 | ms | 0.15 |  |
| 1 | Level 1 | 0 | 100 | % | 0.9 |  |
| 2 | Time 2 | 10 | 1000 | ms | 0.3 |  |
| 3 | Level 2 | 0 | 100 | % | 0.7 |  |
| 4 | Time 3 | 10 | 1000 | ms | 0.45 |  |
| 5 | Level 3 | 0 | 100 | % | 0.5 |  |
| 6 | Time 4 | 10 | 1000 | ms | 0.6 |  |
| 7 | Level 4 | 0 | 100 | % | 0.3 |  |
| 8 | Feedback | 0 | 95 | % | 0.42 |  |
| 9 | Tone | 1 | 12 | kHz | 0.6 |  |
| 10 | Wow | 0 | 100 | % | 0.2 |  |
| 11 | Mix | 0 | 100 | % | 0.28 |  |

Presets : `Dotted`, `Tape`, `Ping-pong`, `Slap`, `Ambient`, `Dub`, `Doubler`, `Pulse`


## 2 · Prism Tone  —  Effet

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Low freq | 20 | 20000 | Hz | 0.15 |  |
| 1 | Low | -12 | 12 | dB | 0.62 |  |
| 2 | Mid freq | 20 | 20000 | Hz | 0.5 |  |
| 3 | Mid | -12 | 12 | dB | 0.45 |  |
| 4 | Mid Q | 0.3 | 4 | — | 0.4 |  |
| 5 | High freq | 20 | 20000 | Hz | 0.85 |  |
| 6 | High | -12 | 12 | dB | 0.7 |  |
| 7 | Output | -12 | 12 | dB | 0.5 |  |

Presets : `Air`, `Warm`, `Vocal`, `Presence`, `Telephone`, `Smile`, `Flat`, `Black Box`


## 3 · Iron Grip  —  Effet

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Threshold | -60 | 0 | dB | 0.48 |  |
| 1 | Ratio | 1 | 20 | — | 0.35 |  |
| 2 | Attack | 0.1 | 100 | ms | 0.25 |  |
| 3 | Release | 10 | 1000 | ms | 0.52 |  |
| 4 | Knee | 0 | 24 | dB | 0.4 |  |
| 5 | Makeup | 0 | 24 | dB | 0.4 |  |

Presets : `Glue`, `Gentle`, `Punch`, `Limit`, `Vocal Leveler`, `Drum Bus`, `Parallel`


## 4 · Solar Ceiling  —  Effet

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Amount | 0 | 100 | % | 0.5 |  |
| 1 | Ceiling | -6 | 0 | dB | 0.92 |  |
| 2 | Release | 10 | 500 | ms | 0.4 |  |
| 3 | Width | 0 | 100 | % | 0.3 |  |
| 4 | Mix | 0 | 100 | % | 1 |  |
| 5 | Output | -12 | 12 | dB | 0.5 |  |

Presets : `Transparent`, `Loud`, `Punch`, `Wide`, `Master Glue`, `Warm Tape`, `Radio`


## 5 · Aether Piano  —  Façonneur

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Felt | 0 | 100 | % | 0.8 |  |
| 1 | Lid | 0 | 100 | % | 0.35 |  |
| 2 | Pedal | 0 | 100 | % | 0.55 |  |
| 3 | Room | 0 | 100 | % | 0.3 |  |
| 4 | Width | 0 | 100 | % | 0.7 |  |
| 5 | Tone | 0 | 100 | % | 0.4 |  |
| 6 | Body | 0 | 100 | % | 0.6 |  |
| 7 | Space | 0 | 100 | % | 0.25 |  |
| 8 | Level | -24 | 6 | dB | 0.8 |  |

Presets : `Felt`, `Studio`, `Upright`, `Concert`, `Mellow`, `Bright`


## 6 · Aether Organ  —  Source

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Upper 16' | 0 | 8 | — | 1 |  |
| 1 | Upper 5⅓' | 0 | 8 | — | 1 |  |
| 2 | Upper 8' | 0 | 8 | — | 1 |  |
| 3 | Upper 4' | 0 | 8 | — | 1 |  |
| 4 | Upper 2⅔' | 0 | 8 | — | 0 |  |
| 5 | Upper 2' | 0 | 8 | — | 0 |  |
| 6 | Upper 1⅗' | 0 | 8 | — | 0 |  |
| 7 | Upper 1⅓' | 0 | 8 | — | 0 |  |
| 8 | Upper 1' | 0 | 8 | — | 0 |  |
| 9 | Lower 16' | 0 | 8 | — | 1 |  |
| 10 | Lower 5⅓' | 0 | 8 | — | 1 |  |
| 11 | Lower 8' | 0 | 8 | — | 1 |  |
| 12 | Lower 4' | 0 | 8 | — | 0 |  |
| 13 | Lower 2⅔' | 0 | 8 | — | 0 |  |
| 14 | Lower 2' | 0 | 8 | — | 0 |  |
| 15 | Lower 1⅗' | 0 | 8 | — | 0 |  |
| 16 | Lower 1⅓' | 0 | 8 | — | 0 |  |
| 17 | Lower 1' | 0 | 8 | — | 0 |  |
| 18 | Perc on | 0 | 1 | — | 0 |  |
| 19 | Perc soft | 0 | 1 | — | 0 |  |
| 20 | Perc fast | 0 | 1 | — | 0 |  |
| 21 | Perc 3rd | 0 | 1 | — | 0 |  |
| 22 | Vibrato | 0 | 5 | — | 0.6 |  |
| 23 | Vib upper | 0 | 1 | — | 1 |  |
| 24 | Vib lower | 0 | 1 | — | 1 |  |
| 25 | Rotary | 0 | 2 | — | 1 |  |
| 26 | Click | 0 | 100 | % | 0.3 |  |
| 27 | Tone | 0 | 100 | % | 0.55 |  |
| 28 | Drive | 0 | 100 | % | 0.4 |  |
| 29 | Space | 0 | 100 | % | 0.25 |  |
| 30 | Level | -24 | 6 | dB | 0.8 |  |

Presets : `Gospel`, `Full`, `Jazz`, `Rock`, `Balanced`, `Whisper`


## 7 · Aether Sax  —  Façonneur

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Breath | 0 | 100 | % | 0.55 |  |
| 1 | Reed | 0 | 100 | % | 0.5 |  |
| 2 | Growl | 0 | 100 | % | 0.15 |  |
| 3 | Vibrato | 0 | 100 | % | 0.35 |  |
| 4 | Rate | 0 | 100 | % | 0.4 |  |
| 5 | Tone | 0 | 100 | % | 0.5 |  |
| 6 | Body | 0 | 100 | % | 0.6 |  |
| 7 | Space | 0 | 100 | % | 0.3 |  |
| 8 | Level | -24 | 6 | dB | 0.8 |  |

Presets : `Smooth`, `Breathy`, `Growl`, `Club`, `Bright`, `Subtone`


## 8 · Aether Strings  —  Façonneur

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Pressure | 0 | 100 | % | 0.5 |  |
| 1 | Speed | 0 | 100 | % | 0.5 |  |
| 2 | Motion | 0 | 100 | % | 0.35 |  |
| 3 | Morph | 0 | 100 | % | 0.1 |  |
| 4 | Time | 0 | 100 | % | 0.5 |  |
| 5 | Color | 0 | 100 | % | 0.1 | UI |
| 6 | Tone | 0 | 100 | % | 0.5 |  |
| 7 | Body | 0 | 100 | % | 0.6 |  |
| 8 | Space | 0 | 100 | % | 0.3 |  |
| 9 | Level | -24 | 6 | dB | 0.8 |  |

Presets : `Solo`, `Chamber`, `Orchestra`, `Cinematic`, `Warm`, `Bright`


## 9 · Aether Guitar  —  Façonneur

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Body | 0 | 3 | — | 0 |  |
| 1 | Pick | 0 | 100 | % | 0.5 |  |
| 2 | Strum | 0 | 100 | % | 0.4 |  |
| 3 | Mute | 0 | 100 | % | 0.1 |  |
| 4 | Bend | 0 | 100 | % | 0.2 |  |
| 5 | Pickup | 0 | 100 | % | 0.5 |  |
| 6 | Finish | 0 | 3 | — | 0.33 | UI |
| 7 | Tone | 0 | 100 | % | 0.5 |  |
| 8 | Resonance | 0 | 100 | % | 0.7 |  |
| 9 | Space | 0 | 100 | % | 0.25 |  |
| 10 | Level | -24 | 6 | dB | 0.8 |  |

Presets : `Acoustic`, `Nylon`, `Clean`, `Crunch`, `Lead`, `Ambient`


## 10 · Aether Amp  —  Effet

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Gain | 0 | 100 | % | 0.3 |  |
| 1 | Bass | 0 | 100 | % | 0.5 |  |
| 2 | Mid | 0 | 100 | % | 0.5 |  |
| 3 | Treble | 0 | 100 | % | 0.6 |  |
| 4 | Presence | 0 | 100 | % | 0.5 |  |
| 5 | Master | 0 | 100 | % | 0.6 |  |
| 6 | Channel | 0 | 2 | — | 0 |  |
| 7 | Mic pos | 0 | 100 | % | 0.4 |  |
| 8 | Mic dist | 0 | 100 | % | 0.4 |  |
| 9 | Boost | 0 | 1 | — | 0 |  |
| 10 | Tremolo | 0 | 1 | — | 0 |  |
| 11 | Level | -24 | 6 | dB | 0.8 |  |

Presets : `Clean`, `Crunch`, `Lead`, `Blues`, `Jazz`, `Metal`


## 11 · Aether Bass  —  Effet

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Drive | 0 | 100 | % | 0.25 |  |
| 1 | Comp | 0 | 100 | % | 0.4 |  |
| 2 | Blend | 0 | 100 | % | 0.6 |  |
| 3 | 63 Hz | 0 | 100 | % | 0.55 |  |
| 4 | 250 Hz | 0 | 100 | % | 0.5 |  |
| 5 | 1 kHz | 0 | 100 | % | 0.5 |  |
| 6 | 3 kHz | 0 | 100 | % | 0.45 |  |
| 7 | 8 kHz | 0 | 100 | % | 0.4 |  |
| 8 | Cab | 0 | 2 | — | 0.5 |  |
| 9 | Level | -24 | 6 | dB | 0.8 |  |

Presets : `Motown`, `Rock`, `Slap`, `Fuzz`, `Dub`, `Clean DI`


## 12 · Aether Brass  —  Façonneur

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Lips | 0 | 100 | % | 0.5 |  |
| 1 | Bite | 0 | 100 | % | 0.45 |  |
| 2 | Vibrato | 0 | 100 | % | 0.3 |  |
| 3 | Section | 0 | 4 | — | 0.25 |  |
| 4 | Mute | 0 | 4 | — | 0 |  |
| 5 | Tone | 0 | 100 | % | 0.5 |  |
| 6 | Body | 0 | 100 | % | 0.6 |  |
| 7 | Space | 0 | 100 | % | 0.3 |  |
| 8 | Level | -24 | 6 | dB | 0.8 |  |

Presets : `Open`, `Muted Jazz`, `Section Stab`, `Fanfare`, `Soft`, `Harmon`


## 13 · Aether Voices  —  Effet

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Vowel X | 0 | 100 | % | 0.5 |  |
| 1 | Vowel Y | 0 | 100 | % | 0.3 |  |
| 2 | Breath | 0 | 100 | % | 0.3 |  |
| 3 | Choir | 0 | 100 | % | 0.5 |  |
| 4 | Vibrato | 0 | 100 | % | 0.35 |  |
| 5 | Tone | 0 | 100 | % | 0.5 |  |
| 6 | Body | 0 | 100 | % | 0.5 |  |
| 7 | Space | 0 | 100 | % | 0.45 |  |
| 8 | Level | -24 | 6 | dB | 0.8 |  |

Presets : `Ah`, `Ooh`, `Eeh`, `Ensemble`, `Whisper`, `Angels`


## 14 · Aether Synth  —  Source

| # | Réglage | Min | Max | Unité | Défaut (0..1) | Remarque |
|---|---|---|---|---|---|---|
| 0 | Wave A | 0 | 100 | % | 0.4 |  |
| 1 | Wave B | 0 | 100 | % | 0.4 |  |
| 2 | Detune | 0 | 100 | % | 0.4 |  |
| 3 | Sub | 0 | 100 | % | 0.4 |  |
| 4 | Noise | 0 | 100 | % | 0.4 |  |
| 5 | Unison | 0 | 100 | % | 0.4 |  |
| 6 | Spread | 0 | 100 | % | 0.4 |  |
| 7 | Cutoff | 0 | 100 | % | 0.4 |  |
| 8 | Resonance | 0 | 100 | % | 0.4 |  |
| 9 | Drive | 0 | 100 | % | 0.4 |  |
| 10 | Env amt | 0 | 100 | % | 0.4 |  |
| 11 | Filter | 0 | 3 | — | 0 |  |
| 12 | Attack | 0 | 100 | % | 0.4 |  |
| 13 | Decay | 0 | 100 | % | 0.4 |  |
| 14 | Sustain | 0 | 100 | % | 0.4 |  |
| 15 | Release | 0 | 100 | % | 0.4 |  |
| 16 | LFO1 rate | 0 | 100 | % | 0.4 |  |
| 17 | LFO1 depth | 0 | 100 | % | 0.4 |  |
| 18 | LFO1 shape | 0 | 100 | % | 0.4 |  |
| 19 | LFO1 dest | 0 | 100 | % | 0.4 |  |
| 20 | LFO2 rate | 0 | 100 | % | 0.4 |  |
| 21 | LFO2 depth | 0 | 100 | % | 0.4 |  |
| 22 | Macro 1 | 0 | 100 | % | 0.4 |  |
| 23 | Macro 2 | 0 | 100 | % | 0.4 |  |
| 24 | Macro 3 | 0 | 100 | % | 0.4 |  |
| 25 | Macro 4 | 0 | 100 | % | 0.4 |  |
| 26 | Mode | 0 | 2 | — | 0 |  |
| 27 | Glide | 0 | 100 | % | 0.4 |  |
| 28 | Voices | 0 | 100 | % | 0.4 |  |
| 29 | Bend | 0 | 100 | % | 0.4 |  |
| 30 | Tune | 0 | 100 | % | 0.4 |  |
| 31 | Level | -24 | 6 | dB | 0.8 |  |

Presets : `Pad`, `Lead`, `Bass`, `Pluck`, `Keys`, `FX`


---
## Mappages audio par effet (ce que fait chaque réglage)

### Effets (emplacements de piste ou master)
- **0 Space, 1 Echo, 2 Tone, 3 Grip, 4 Ceiling** : inchangés, déjà dans la bibliothèque et testés (voir 05).
- **10 Amp** : Gain/Channel → étages à lampes sur-échantillonnés x2 (Clean, Crunch, Lead = 1, 1 et 2 étages) ; Bass/Mid/Treble/Presence → correcteur (shelf 120 Hz, cloche 700 Hz, shelf 3,2 kHz, shelf 5,5 kHz) ; Master → saturation de l'étage de puissance et volume ; MicPos → coupe-haut de l'enceinte 6,5 → 3,2 kHz et creux de présence ; MicDist → effet de proximité (grave) ; Boost = +9 dB avant les étages ; Tremolo = 5 Hz, profondeur 50 % ; Level = −24..+6 dB.
- **11 Bass** : Comp → compresseur (seuil −18 dB, rapport 1,5..8) ; Drive → préampli à lampe ; Blend → mélange voie directe (DI) / voie ampli+enceinte ; EQ 63 Hz (shelf), 250 Hz, 1 kHz, 3 kHz (cloches), 8 kHz (shelf), ±12 dB ; Cab → 1×15, 4×10, 8×10 (filtres d'enceinte) ; Level. Compteurs : 0 = réduction de gain (dB), 1 = crête de sortie.
- **13 Voices** (EFFET, pas une source) : Vowel X/Y → carte de voyelles I, U, E, O, A, interpolation inverse-distance des formants F1..F3 ; trois filtres passe-bande en parallèle ; Breath = bruit modulé par l'enveloppe du signal, passé dans les mêmes formants ; Choir = ensemble de 4 voix à retard modulé ; Vibrato = modulation de retard à 5,5 Hz ; Tone = shelf 3 kHz ; Body = mélange du signal sec ; Space = réverbe interne (SpaceReverb) ; Level.

### Façonneurs (un seul par piste, agissent sur le soundfont chargé)
Deux parties : **(a) décalages de générateurs SoundFont** calculés par `computeGens()` (appliqués sur le canal MIDI de la piste, voir 04) et **(b) traitement audio interne** de `ShaperFx`. Les décalages sont **additifs** aux valeurs du soundfont.
| Façonneur | Générateurs (décalages) | Traitement audio interne |
|---|---|---|
| 5 Piano | Felt, Lid, Tone → fréquence de coupure (gen 8) ; Pedal → release (38) et decay (36) | Tone = shelf 3 kHz ; Body = cloche 250 Hz ; Width = largeur stéréo ; Room + Space = réverbe |
| 7 Sax | Reed, Tone → coupure (8) et Q (9) ; Breath → attack (34) ; Vibrato → vibLfoToPitch (6) ; Rate → vibLfoFreq (24) | Growl = saturation + flutter 7 Hz ; Breath = bruit de souffle ; Body = cloche 350 Hz |
| 8 Strings | Pressure, Tone → coupure (8) ; Speed, Time → attack (34) ; Time → release (38) ; Motion → vibrato (6) | Morph = ensemble de 1..6 voix détunées ; Body = cloche 300 Hz ; **Color = UI seulement** |
| 9 Guitar | Pick, Pickup, Tone, Mute → coupure (8) ; Pick → attack (34) ; Mute → decay (36) et release (38) | Body (type) = courbe d'EQ du corps (acoustique, nylon, double cut, simple cut) ; Resonance = cloche 100 Hz ; **Finish = UI seulement**. Niveau « note » : **Strum** = décalage de 0..60 ms entre les notes d'un accord, **Bend** = sensibilité du pitch-bend 2..12 demi-tons (`PerfSet`) |
| 12 Brass | Lips, Tone → coupure (8) ; Bite → attack (34) ; Vibrato → (6) | Bite = saturation ; Section = ensemble de 1..5 voix ; Mute = filtres (Open rien, Straight HP 500 Hz + LP 6,5 kHz, Cup LP 2,4 kHz, Harmon cloche 1,4 kHz +9 dB, Plunger LP 1,7 kHz) |
Tous : Tone, Body, Space, Level (bandeau du bas) sont traités par le même code (indices selon `shaperMap()`).

### Sources (remplacent le soundfont de la piste tant qu'elles sont choisies)
- **6 Organ** (31 réglages) : tirettes Upper 0..8 et Lower 9..17 (0..8 pas de 3 dB), percussion (18..21), vibrato/chorus V1..C3 (22..24, appliqué aux deux claviers à la fois), rotary Stop/Slow/Fast (25), click, tone, drive, space, level. Touches < 60 = clavier Lower, ≥ 60 = Upper. Moteur à roues phoniques additif : le coût dépend du nombre de roues actives, pas du nombre de notes.
- **14 Synth** (32 réglages) : 2 oscillateurs à forme continue (sinus > triangle > scie > carré, PolyBLEP), sub, bruit, unison 1..8 (plafonné à 48 / voix max pour tenir le CPU), filtre SVF (LP, HP, BP, notch), ADSR (commune ampli et filtre), LFO1 (4 formes, 4 destinations), LFO2 → pitch, macros M1 → coupure ±3 octaves, M2 → résonance, M3 → forme de l'oscillateur A, M4 → drive (**assignation fixe en v1**, la matrice modifiable est la v2), modes poly / mono / legato, glide.

### Tiroir « Soundfont edit » (aperçu seulement en v1)
Les curseurs du tiroir (Attack, Decay, Sustain, Release, Cutoff, Resonance, Coarse, Fine, Vib depth, Vib rate, Key low/high) sont des **maquettes** sans effet audio dans cette version. Mappage prévu avec le même mécanisme : Attack → gen 34, Decay → 36, Sustain → 37, Release → 38, Cutoff → 8, Resonance → 9, Coarse → 51, Fine → 52, Vib depth → 6, Vib rate → 24 ; Velocity curve et plage de touches se font dans le moteur de notes.
