# Æther Keys · Package FX (effets, instruments, interface) · À LIRE EN PREMIER

Tu implémentes le système d'effets et d'instruments d'Æther Keys dans l'application existante. **Tout ce dont tu as besoin est dans ce dossier, à plat.** Ne cherche rien sur internet pour les API déjà décrites ici.

## Règles (à respecter à la lettre)
1. **Agis, ne divague pas.** Pas de recherches inutiles, pas de refactor non demandé. Fais l'étape, lance son test, passe à la suivante.
2. **Copie les fichiers `fx_*.h` et `fx-window-preview.html` octet pour octet.** Seuls le `package` des `.kt` et les chemins CMake peuvent changer. Si un en-tête ne compile pas, rapporte l'erreur : ne réécris pas la logique.
3. **Ne casse rien d'existant.** Chaque piste garde **sa propre soundfont** à tout moment. Ne touche pas aux sources de FluidSynth (réglages CMake seulement). Ne modifie pas le fonctionnement des pistes, du mixeur, du TonicPad, du DrumPad, des Sheets.
4. **Deux lots bien séparés** : *Effets* (6 emplacements par piste, 8 sur le Master) et *Instrument* (un seul par piste, **jamais** sur le Master). Voir 01.
5. **L'aperçu HTML est la référence visuelle sans altération.** Aucune couleur, cote, police ou animation « à ta façon ». Voir 03.
6. **Si un test échoue trois fois de suite, arrête-toi** et rapporte en 10 lignes maximum (ce que tu as fait, l'erreur exacte, ce que tu supposes). Ne devine pas.
7. **Ne prétends pas avoir vérifié ce que tu n'as pas exécuté.** Écris « non vérifié » quand c'est le cas.

## Contenu (tout à plat)
| Fichiers | Rôle |
|---|---|
| `00` à `05-*.md` | Ces instructions. 01 architecture · 02 paramètres et mappages · 03 interface · 04 intégration audio et JNI · 05 tests |
| `fx-window-preview.html` | **Référence visuelle et comportementale** de toute la fenêtre FX (téléphone et tablette). À ouvrir dans un navigateur |
| `ref-NN-*.png`, `ref-NN-*-presets.png`, `ref-tablet-*.png` | Rendus de référence (2× pour le preset par défaut, feuille de tous les presets, tablette) |
| `ic_fx_*.xml` / `ic_fx_*.svg` | 15 icônes (VectorDrawable Android et SVG), conversion vérifiée pixel à pixel |
| `fx_core.h` … `fx_mixer.h` | Bibliothèque C++17 header-only (DSP, moteurs, façade `FxMixer`) |
| `fx_test.cpp`, `fx_test2.cpp`, `Makefile` | Bancs de test hôte (116 contrôles) |
| `gen_kotlin.cpp`, `FxRegistry.kt` | Générateur et registre Kotlin (même contenu que `fx_registry.h`) |

## Ordre de travail
**Étape 0 · Tests hôte.** `make test` dans ce dossier. Attendu : `26 checks, 0 failed` puis `90 checks, 0 failed`. Si ce n'est pas le cas, arrête-toi.
**Étape 1 · Bibliothèque dans le projet.** Copie les `fx_*.h` dans `app/src/main/cpp/aetherfx/`, ajoute `target_include_directories(native-lib PRIVATE aetherfx)` (aucun .cpp à ajouter). `minSdk` = 26. Compile. *Critère : le projet compile, le son est inchangé.*
**Étape 2 · Sortie séparée par canal** (04, étape 2). *Critère : la somme des canaux égale l'ancien mix à 1e-5.*
**Étape 3 · Brancher `FxMixer`** dans `AudioEngine` (04, étape 3), supprimer l'ancienne chaîne d'effets, retirer mutex, logs et redimensionnements du rappel audio. *Critère : 8 pistes et 2 réverbes pendant 10 minutes sans xrun.*
**Étape 4 · Instruments** : notes routées vers les sources, soundfont mise en pause pour les sources, décalages de générateurs pour les façonneurs (04, étapes 4 et 5).
**Étape 5 · JNI et Kotlin** : `FxRegistry.kt` + pont natif (04, étape 6).
**Étape 6 · Interface** : port fidèle de `fx-window-preview.html` (03). Un effet à la fois, comparaison aux `ref-*.png`.
**Étape 7 · Persistance et avertissement de soundfont** (01).
**Étape 8 · Validation sur appareil** (05, liste de contrôle).

## Format du rapport après chaque étape (10 lignes maximum)
`Étape N : faite / bloquée` · fichiers modifiés · commande de test lancée et résultat exact · ce qui n'a pas été vérifié · prochaine étape.

## Ce qui n'a PAS été vérifié par l'auteur de ce package
- **Aucun code Kotlin/Compose de l'interface n'a été écrit ni compilé** : l'interface est livrée comme aperçu HTML de référence et rendus PNG. Le port Compose est ton travail (03).
- `FxRegistry.kt` est généré mais n'a pas été compilé dans le projet.
- Le son sur un téléphone réel (qualité subjective, CPU, latence). Les mesures de 05 sont sur un ordinateur ; compte 3 à 6 fois plus sur téléphone.
- L'effet réel de `fluid_synth_set_gen` sur **tes** soundfonts (voir 04, étape 5 : à tester une fois sur un soundfont réel).
- Le bug de « disparition des animations » n'a pas été reproduit dans l'aperçu ; des protections sont en place (03).
