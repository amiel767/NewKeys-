// Offline test bench for AetherFX. Build: see Makefile. Exit code != 0 when a check fails.
#include <chrono>
#include <cstdio>
#include <random>
#include <thread>
#include "fx_chain.h"
using namespace aetherfx;

static int fails = 0, checks = 0;
#define CHECK(cond, ...) do { ++checks; if (!(cond)) { ++fails; std::printf("  FAIL: "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)
static const double SR = 48000.0;

static std::vector<float> sine(double f, double amp, int frames, double phase = 0) {
  std::vector<float> b(frames * 2);
  for (int i = 0; i < frames; ++i) { float s = static_cast<float>(amp * std::sin(2 * kPi * f * i / SR + phase)); b[2 * i] = b[2 * i + 1] = s; }
  return b;
}
static void runBlocks(Effect& e, std::vector<float>& b, int block = 256) {
  int frames = static_cast<int>(b.size() / 2);
  for (int pos = 0; pos < frames; pos += block) e.process(&b[2 * pos], std::min(block, frames - pos));
}
static double rmsDb(const std::vector<float>& b, int from, int to) {
  double s = 0; for (int i = from; i < to; ++i) s += b[2 * i] * b[2 * i];
  return 10 * std::log10(s / (to - from) + 1e-20);
}
static double peak(const std::vector<float>& b, int from = 0) { double m = 0; for (size_t i = from * 2; i < b.size(); ++i) m = std::max(m, (double)std::fabs(b[i])); return m; }
static bool finite(const std::vector<float>& b) { for (float x : b) if (!std::isfinite(x)) return false; return true; }

static void testEq() {
  std::printf("[EQ] Prism Tone\n");
  auto eq = std::make_unique<ToneEq>(); eq->prepare(SR, 256);
  // mid bell +6 dB at ~1 kHz, others flat
  float uMid = std::log(1000.f / 20.f) / std::log(1000.f);
  eq->setNorm(0, .15f); eq->setNorm(1, .5f); eq->setNorm(2, uMid); eq->setNorm(3, .75f); eq->setNorm(4, .4f); eq->setNorm(5, .85f); eq->setNorm(6, .5f); eq->setNorm(7, .5f);
  auto warm = sine(1000, .1, 48000); runBlocks(*eq, warm);
  auto b = sine(1000, .1, 48000); runBlocks(*eq, b);
  double g = rmsDb(b, 24000, 48000) - rmsDb(sine(1000, .1, 48000), 24000, 48000);
  std::printf("  mid +6 dB at 1 kHz -> measured %+.2f dB (analytic %+.2f)\n", g, eq->responseDb(1000));
  CHECK(std::fabs(g - 6.0) < 0.3, "mid gain %.2f", g);
  auto far = sine(100, .1, 48000); runBlocks(*eq, far);
  double g2 = rmsDb(far, 24000, 48000) - rmsDb(sine(100, .1, 48000), 24000, 48000);
  CHECK(std::fabs(g2) < 0.6, "100 Hz should be ~flat, got %.2f", g2);
  // low shelf +9 dB, check well below corner
  auto eq2 = std::make_unique<ToneEq>(); eq2->prepare(SR, 256);
  float uLow = std::log(200.f / 20.f) / std::log(1000.f);
  eq2->setNorm(0, uLow); eq2->setNorm(1, .5f + 9.f / 24.f); eq2->setNorm(2, .5f); eq2->setNorm(3, .5f); eq2->setNorm(4, .4f); eq2->setNorm(5, .9f); eq2->setNorm(6, .5f); eq2->setNorm(7, .5f);
  auto lo = sine(30, .1, 96000); runBlocks(*eq2, lo);
  double g3 = rmsDb(lo, 70000, 96000) - rmsDb(sine(30, .1, 96000), 70000, 96000);
  std::printf("  low shelf +9 dB @200 Hz, measured at 30 Hz: %+.2f dB\n", g3);
  CHECK(std::fabs(g3 - 9.0) < 0.8, "low shelf %.2f", g3);
  // flat settings must be transparent
  auto eq3 = std::make_unique<ToneEq>(); eq3->prepare(SR, 256); for (int i = 0; i < 8; ++i) eq3->setNorm(i, i == 0 ? .15f : (i == 2 ? .5f : (i == 5 ? .85f : (i == 4 ? .4f : .5f))));
  auto t = sine(3000, .3, 24000); auto ref = t; runBlocks(*eq3, t);
  double md = 0; for (size_t i = 12000 * 2; i < t.size(); ++i) md = std::max(md, (double)std::fabs(t[i] - ref[i]));
  CHECK(md < 0.002, "flat EQ not transparent (max diff %.5f)", md);
}

static void testGrip() {
  std::printf("[COMP] Iron Grip static curve\n");
  // threshold -18 dB, ratio 4, knee 0, attack 1 ms, release 50 ms, makeup 0
  auto run = [&](double inDb, float ratioIdx) {
    auto c = std::make_unique<GripCompressor>(); c->prepare(SR, 256);
    c->setNorm(0, 42.f / 60.f); c->setNorm(1, ratioIdx); c->setNorm(2, 0.f); c->setNorm(3, .04f); c->setNorm(4, 0.f); c->setNorm(5, 0.f);
    auto b = sine(1000, std::pow(10.0, inDb / 20.0), 96000); runBlocks(*c, b);
    return 20 * std::log10(peak(b, 80000) + 1e-12);
  };
  double o1 = run(-30, 3.f / 5.f), o2 = run(-6, 3.f / 5.f);
  std::printf("  in -30 dB -> out %.2f dB (expect -30), in -6 dB -> out %.2f dB (expect %.1f)\n", o1, o2, -18 + 12.0 / 4);
  CHECK(std::fabs(o1 + 30) < 0.4, "below threshold must be untouched: %.2f", o1);
  CHECK(std::fabs(o2 - (-18 + 12.0 / 4)) < 0.8, "above threshold: %.2f", o2);
  auto c = std::make_unique<GripCompressor>(); c->prepare(SR, 256); c->setNorm(0, .5f); c->setNorm(1, 1.f); c->setNorm(4, 0); c->setNorm(5, 0);
  auto b = sine(1000, 0.9, 48000); runBlocks(*c, b);
  CHECK(c->meter(0) > 5.f, "gain reduction meter should report > 5 dB, got %.2f", c->meter(0));
  CHECK(c->latencySamples() == 0, "compressor must be zero latency");
}

static void testCeiling() {
  std::printf("[MAX] Solar Ceiling\n");
  std::mt19937 rng(7); std::uniform_real_distribution<float> d(-1.f, 1.f);
  for (int look = 0; look < 2; ++look) {
    auto m = std::make_unique<CeilingMaximizer>(look ? 1.0f : 0.0f); m->prepare(SR, 256);
    m->setNorm(0, 1.f); m->setNorm(1, .5f); m->setNorm(2, .3f); m->setNorm(3, .3f); m->setNorm(4, 1.f); m->setNorm(5, .5f);
    std::vector<float> b(96000 * 2);
    for (int i = 0; i < 96000; ++i) { float s = 0.8f * std::sin(2 * 3.14159f * 220 * i / 48000.f) + 0.6f * d(rng); b[2 * i] = s; b[2 * i + 1] = 0.9f * s; }
    runBlocks(*m, b);
    double pk = peak(b, 4800);
    double ceilLin = std::pow(10.0, -3.0 / 20.0);
    std::printf("  lookahead=%s: output peak %.4f (ceiling %.4f at -3 dB), latency %d samples, GR meter %.1f dB\n", look ? "1 ms" : "none", pk, ceilLin, m->latencySamples(), m->meter(0));
    CHECK(pk <= ceilLin * 1.001, "ceiling exceeded: %.4f > %.4f", pk, ceilLin);
    CHECK(finite(b), "non-finite output");
  }
  // louder with amount
  auto lo = std::make_unique<CeilingMaximizer>(1.f), hi = std::make_unique<CeilingMaximizer>(1.f); lo->prepare(SR, 256); hi->prepare(SR, 256);
  for (auto* e : {lo.get(), hi.get()}) { e->setNorm(1, 1.f); e->setNorm(2, .3f); e->setNorm(3, 0); e->setNorm(4, 1); e->setNorm(5, .5f); }
  lo->setNorm(0, 0.f); hi->setNorm(0, .8f);
  auto a = sine(500, .2, 48000), c = sine(500, .2, 48000); runBlocks(*lo, a); runBlocks(*hi, c);
  double ra = rmsDb(a, 24000, 48000), rc = rmsDb(c, 24000, 48000);
  std::printf("  quiet signal: amount 0 -> %.1f dB RMS, amount 0.8 -> %.1f dB RMS\n", ra, rc);
  CHECK(rc > ra + 6, "amount must raise loudness (%.1f vs %.1f)", rc, ra);
}

static void testReverbDelay() {
  std::printf("[REV] Aether Space\n");
  auto r = std::make_unique<SpaceReverb>(); r->prepare(SR, 256);
  for (int i = 0; i < 7; ++i) r->setNorm(i, info(FX_SPACE).params[i].def);
  r->setNorm(1, .25f); r->setNorm(5, 1.f);  // decay = 0.4 + 7.6*0.25 = 2.3 s, full wet
  std::vector<float> b(SR * 6 * 2, 0.f); b[0] = b[1] = 1.f;
  runBlocks(*r, b);
  CHECK(finite(b), "reverb produced NaN/Inf");
  auto lvl = [&](double t0) { int a = (int)(t0 * SR), e = a + 2400; double s = 0; for (int i = a; i < e; ++i) s += b[2 * i] * b[2 * i]; return 10 * std::log10(s / 2400 + 1e-30); };
  double l1 = lvl(0.3), l2 = lvl(1.3), l3 = lvl(2.3);
  std::printf("  tail level at 0.3 s / 1.3 s / 2.3 s: %.1f / %.1f / %.1f dB\n", l1, l2, l3);
  CHECK(l2 < l1 - 6 && l3 < l2 - 6, "tail must decay steadily");
  double dec = (l3 - l1) / 2.0;  // dB per second
  double rt60 = -60.0 / dec;
  std::printf("  estimated RT60 %.2f s (target 2.3 s)\n", rt60);
  CHECK(rt60 > 1.4 && rt60 < 3.4, "RT60 out of range: %.2f", rt60);
  {  // loudness: full wet reverb on noise should sit near the dry level
    auto rv = std::make_unique<SpaceReverb>(); rv->prepare(SR, 256);
    for (int i = 0; i < 7; ++i) rv->setNorm(i, info(FX_SPACE).params[i].def);
    rv->setNorm(5, 1.f);
    std::mt19937 rg(5); std::normal_distribution<float> nd(0.f, 0.1f);
    std::vector<float> nz(96000 * 2); for (auto& v : nz) v = nd(rg);
    auto in = nz; runBlocks(*rv, nz);
    double dg = rmsDb(nz, 48000, 96000) - rmsDb(in, 48000, 96000);
    std::printf("  full-wet level vs dry on noise: %+.1f dB (aim -6..0)\n", dg);
    CHECK(dg > -9 && dg < 2, "reverb wet level off: %.1f dB", dg);
  }
  std::printf("[DLY] Aether Echo\n");
  auto e = std::make_unique<EchoDelay>(); e->prepare(SR, 256);
  const float t1 = (250.f - 10.f) / 990.f, t2 = (500.f - 10.f) / 990.f;
  e->setNorm(0, t1); e->setNorm(1, 1.f); e->setNorm(2, t2); e->setNorm(3, .5f); e->setNorm(4, .9f); e->setNorm(5, 0.f); e->setNorm(6, .9f); e->setNorm(7, 0.f);
  e->setNorm(8, 0.f); e->setNorm(9, 1.f); e->setNorm(10, 0.f); e->setNorm(11, 1.f);
  std::vector<float> d(SR * 2 * 2, 0.f); d[0] = 1.f; d[1] = 1.f; runBlocks(*e, d);
  auto at = [&](double ms) { int c = (int)(ms * 0.001 * SR); double m = 0; for (int i = c - 6; i <= c + 6; ++i) m = std::max(m, (double)std::fabs(d[2 * i]) + std::fabs(d[2 * i + 1])); return m; };
  std::printf("  tap 1 @250 ms level %.3f, tap 2 @500 ms level %.3f (cross-fed), empty @350 ms %.4f\n", at(250), at(500), at(350));
  CHECK(at(250) > 0.5 && at(500) > 0.2 && at(350) < 0.01, "taps not at expected times");
  CHECK(finite(d), "echo produced NaN");
}

static void testChain() {
  std::printf("[CHAIN] swap, bypass, preset, strip\n");
  FxChain ch(4); ch.prepare(SR, 256);
  ch.setEffect(0, FX_TONE); ch.setEffect(1, FX_GRIP); ch.setEffect(2, FX_SPACE);
  CHECK(ch.effectId(1) == FX_GRIP && ch.effectId(3) == -1, "slot ids");
  CHECK(ch.applyPreset(2, 4), "preset apply (Shimmer)");
  // bypass crossfade must not click
  auto b = sine(440, .5, 48000);
  float maxJump = 0.f;
  ch.setBypass(1, false);
  for (int pos = 0; pos + 256 <= 48000; pos += 256) {
    if (pos == 24064) ch.setBypass(1, true);
    ch.process(&b[2 * pos], 256);
  }
  for (int i = 24000; i < 32000; ++i) maxJump = std::max(maxJump, std::fabs(b[2 * i] - b[2 * (i - 1)]));
  std::printf("  max sample-to-sample jump with bypass toggled mid-stream: %.4f (sine step max %.4f)\n", maxJump, 2 * 3.14159 * 440 / 48000 * .5);
  CHECK(maxJump < 0.05, "bypass click detected (%.4f)", maxJump);
  CHECK(finite(b), "chain output not finite");
  // strip: gain, pan, mute, safety
  FxStrip st(2, true); st.prepare(SR, 256);
  std::vector<float> x(256 * 2, 0.9f); st.setGain(2.f); st.setPan(0.f);
  for (int k = 0; k < 40; ++k) { std::fill(x.begin(), x.end(), 0.9f); st.process(x.data(), 256); }
  CHECK(peak(x) <= 1.0, "master safety must clamp to full scale");
  st.setMute(true); for (int k = 0; k < 40; ++k) { std::fill(x.begin(), x.end(), 0.9f); st.process(x.data(), 256); }
  CHECK(peak(x) < 1e-4, "mute must reach silence");
}

// Stress: control thread hammers params/effects while the audio thread renders. Run with -fsanitize=thread for races.
static void testStress() {
  std::printf("[STRESS] concurrent control + audio (3 s)\n");
  FxChain ch(4); ch.prepare(SR, 256);
  std::atomic<bool> run{true};
  std::thread ctl([&] {
    std::mt19937 rng(3); int n = 0;
    while (run.load()) {
      int slot = rng() % 4;
      switch (rng() % 5) {
        case 0: ch.setEffect(slot, (int)(rng() % 6) - 1); break;
        case 1: ch.setParam(slot, rng() % 12, (rng() % 1000) / 999.f); break;
        case 2: ch.setBypass(slot, rng() & 1); break;
        case 3: ch.applyPreset(slot, rng() % 8); break;
        default: ch.collectGarbage();
      }
      if (++n % 50 == 0) std::this_thread::sleep_for(std::chrono::microseconds(200));
    }
  });
  std::mt19937 rng(9); std::uniform_real_distribution<float> d(-.5f, .5f);
  std::vector<float> b(256 * 2); bool ok = true; long blocks = 0;
  auto t0 = std::chrono::steady_clock::now();
  while (std::chrono::steady_clock::now() - t0 < std::chrono::seconds(3)) {
    for (auto& v : b) v = d(rng);
    ch.process(b.data(), 256); ++blocks;
    if (!finite(b)) { ok = false; break; }
  }
  run = false; ctl.join(); ch.collectGarbage();
  std::printf("  rendered %ld blocks while reconfiguring continuously\n", blocks);
  CHECK(ok, "non-finite output during stress");
}

static void bench() {
  std::printf("[BENCH] CPU cost, 10 s of stereo audio at 48 kHz, block 256 (this machine, -O2)\n");
  std::mt19937 rng(1); std::uniform_real_distribution<float> d(-.5f, .5f);
  for (int id = 0; id < 5; ++id) {
    for (int variant = 0; variant < (id == FX_CEILING ? 2 : 1); ++variant) {
    auto e = makeEffect(id, variant == 1); e->prepare(SR, 256);
    for (size_t i = 0; i < info(id).params.size(); ++i) e->setNorm((int)i, info(id).params[i].def);
    std::vector<float> b(256 * 2);
    auto t0 = std::chrono::steady_clock::now();
    for (int blk = 0; blk < 48000 * 10 / 256; ++blk) { for (auto& v : b) v = d(rng); NoDenormals nd; e->process(b.data(), 256); }
    double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::printf("  %-14s %5.2f %% of one core%s\n", info(id).name, sec / 10.0 * 100, variant ? "  (master, 1 ms lookahead)" : (id == FX_CEILING ? "  (track, no lookahead)" : ""));
    }
  }
}

int main() {
  testEq(); testGrip(); testCeiling(); testReverbDelay(); testChain(); testStress(); bench();
  std::printf("\n%d checks, %d failed\n", checks, fails);
  return fails ? 1 : 0;
}
