# 05 · Tests et validation

## Commandes (dans ce dossier, g++ ≥ 9)
```
make test      # compile et lance fx_test (26 contrôles) puis fx_test2 (90 contrôles)
make asan      # idem sous AddressSanitizer + UBSan
make tsan      # idem sous ThreadSanitizer
```
Résultat attendu : `26 checks, 0 failed` et `90 checks, 0 failed`, aucune alerte de sanitizer.

## Ce que couvrent les tests
- **Effets 0 à 4** (fx_test) : EQ ±6 dB mesuré, courbe statique du compresseur, plafond du maximizer avec et sans anticipation, durée de queue de réverbe, retards à l'échantillon près, fondu au bypass, échange d'effets pendant le rendu (stress multi-threads).
- **Amp, Bass, Voices** (fx_test2) : distorsion croissante avec le gain et le canal, position du micro, contrôle des graves, trémolo, vumètre de compression, gain de l'EQ graphique, voie directe transparente, cabinets différents, formants des voyelles, 120 jeux de paramètres aléatoires finis et bornés.
- **Façonneurs** : décalages dans la plage, sens des effets (feutre plus mou = plus sombre, étouffement = release plus court), sourdine harmon, avertissement de soundfont (6 cas).
- **Organ** : fondamentale pure à 40 dB, loi des tirettes (3 dB par pas : mesuré 12 dB sur 4 pas), pied de 16, percussion qui décroît à déclenchement unique, modulation du rotary, 10 touches bornées, relâchement.
- **Synth** : justesse (440 Hz à ±1), repliement < −35 dB, pente du filtre, passe-haut, durée d'attaque, constante de relâchement (0,37 à t = release), polyphonie et vol de voix, mode mono, 40 jeux aléatoires.
- **Piste** : un seul instrument, sources vs façonneurs, interdits (instrument sur le Master, instrument dans un emplacement d'effet, effet dans l'emplacement instrument), 8 emplacements Master, échange concurrent instrument/effets.
- **Registre** : chaque preset a une valeur par paramètre, toutes entre 0 et 1, 15 entrées, répartition 8 effets / 5 façonneurs / 2 sources.

## Mesures de coût (ordinateur de bureau, -O2, 10 s d'audio stéréo à 48 kHz ; téléphone : compte 3 à 6 fois plus)
| Module | % d'un cœur |
|---|---|
| Space | 0,51 | 
| Echo | 0,36 |
| Tone | 0,16 |
| Grip | 0,18 |
| Ceiling (piste / Master avec anticipation) | 0,39 / 0,81 |
| Amp | 2,47 |
| Bass | 1,50 |
| Voices | 1,54 |
| Piano (façonneur) | 0,76 |
| Strings (façonneur) | 0,86 |
| Brass (façonneur) | 1,82 |
| Organ (8 touches) | 2,41 |
| Synth (8 voix, preset Pad) | 5,17 |
Le Synth est le module le plus coûteux : surveille-le sur appareil (budget : voix max 8 et unison ≤ 4 pour les téléphones modestes).

## Liste de contrôle sur appareil (Étape 8)
1. 8 pistes + 2 réverbes + 1 Amp : 10 minutes, **0 xrun**.
2. Changer d'instrument, d'effet et de preset **pendant le jeu** : aucun clic ni blocage ; notes tenues sans note bloquée.
3. Passer Organ → soundfont → Organ : le soundfont de la piste est identique à l'origine.
4. Façonneur sur un mauvais soundfont : le bandeau rouge s'affiche, rien n'est bloqué.
5. Interface : mode Debug, 10 minutes d'utilisation, **aucune** disparition d'animation ; si elle se produit, relève les compteurs du mode Debug et envoie-les.
6. Mémoire : une seule surface plein cadre active, pas de croissance au fil des ouvertures/fermetures.

## Limites connues
Les amplis sont des simulations (le son est celui d'un ampli simulé). Les articulations de guitare (palm mute, glissés) et de sax (growl) sont des approximations à partir des échantillons du soundfont : le soundfont doit les contenir pour qu'elles sonnent juste. Le Synth ne propose pas encore de matrice de modulation éditable (macros à assignation fixe). Le tiroir « Soundfont edit » est une maquette. Qualité sonore subjective et CPU sur téléphone : non mesurés.
