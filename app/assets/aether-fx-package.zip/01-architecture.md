# 01 · Architecture : deux lots séparés

## Vocabulaire
- **Effet** (`Kind::Effect`) : traite le son d'une piste ou du Master. Ids 0 Space, 1 Echo, 2 Tone, 3 Grip, 4 Ceiling, 10 Amp, 11 Bass, 13 Voices.
- **Façonneur** (`Kind::Shaper`) : *modifie le soundfont chargé* sur la piste (décalages de générateurs + traitement interne). Ids 5 Piano, 7 Sax, 8 Strings, 9 Guitar, 12 Brass.
- **Source** (`Kind::Source`) : *remplace* le son du soundfont tant qu'elle est choisie. Ids 6 Organ, 14 Synth.
- Façonneurs et sources forment le lot **Instrument**. `kindOf(id)` (dans `fx_registry.h`) est la seule règle de répartition.

## Règles
| Règle | Détail |
|---|---|
| Lot Effets | 6 emplacements par piste, **8 sur le Master**. Un effet ne peut être présent qu'une fois par piste. `FxMixer::setEffect` refuse tout id qui n'est pas un effet. |
| Lot Instrument | **Un seul** par piste (`FxMixer::setInstrument`). Choisir un nouvel instrument **remplace** l'ancien (message « X remplace Y »). Refusé sur le Master, le sampler DrumPad et les canaux Drum/TonicPad (`instrumentAllowed`). |
| Soundfont | Chaque piste garde sa soundfont **chargée en permanence**. Pas d'instrument = le soundfont tel quel. Façonneur = soundfont modifié. Source = soundfont **en pause** (ne pas le rendre, `soundfontPaused(strip)`), il revient à l'identique quand on repasse sur « aucun instrument » ou sur un façonneur. |
| Master | Seulement des effets. Aucune option Instrument. |
| Voices | C'est un **effet** (filtre à formants), pas une source. |
| Couches | Une source par piste en v1. Soundfont + Synth en même temps = v2. |

## Strips (`FxMixer`)
0..7 pistes (canaux MIDI 0..7) · 8 canal Drum du soundfont · 9 TonicPad (canal 9) · 10 sampler DrumPad · `kMaster = 15`. Chaque strip a fader, balance, mute et vumètres ; les strips 0..7 ont en plus l'emplacement Instrument.

## Interface : où vit chaque lot
- En-tête du rack : titre « Effects », compteur `n / 6 effects`, puce **Soundfont**, boutons **+ Instrument** et **+ Effect** (voir l'aperçu).
- La **puce Soundfont ouvre la fenêtre soundfonts qui existe déjà dans l'app** (ne la refais pas). Dans l'aperçu c'est une doublure qui reproduit sa structure. Si une source est active, la puce affiche « Soundfont paused · nom ».
- La grille d'ajout a deux onglets : **EFFECTS** (puces Dynamics, EQ, Space, Amps, Voices) et **INSTRUMENT** (Keys, Guitar, Winds, Strings, Synth). Dans l'onglet Instrument, choisir remplace l'instrument courant.
- L'instrument est toujours la **première** carte du rack, avec un liseré doré.

## Avertissement soundfont / façonneur (ne bloque jamais)
`matchShaper(fxId, presetName, gmProgram, bank, keyLow, keyHigh)` (`fx_match.h`) renvoie `Ok`, `Weak` ou `Mismatch`. Ordre : le **nom du preset** d'abord, puis la famille General MIDI du **numéro de programme**, puis la plage de notes. Un kit de batterie (bank 128) donne toujours `Mismatch`.
- À chaque changement de soundfont/preset de la piste, et à l'ajout d'un façonneur : appeler `matchShaper` avec les données de la fenêtre soundfonts existante (nom du preset, programme, banque).
- Si `Mismatch` : afficher le **gros bandeau rouge** de l'aperçu en haut de la fenêtre du façonneur : « This doesn't look like a saxophone. The loaded soundfont is “…”. Using Aether Sax on it may sound wrong. Choose a matching soundfont for the best result. » avec deux boutons : **Change soundfont** (ouvre la fenêtre soundfonts existante) et **Use anyway** (masque le bandeau jusqu'au prochain changement de soundfont).
- Les sources et les effets n'affichent pas ce bandeau.

## Persistance (JSON par piste, clés stables)
```json
{ "track": 2, "instrument": {"id": 7, "preset": "Smooth", "params": [0.55, 0.4, ...], "bypass": false},
  "effects": [ {"id": 0, "preset": "Hall", "params": [...], "bypass": false}, null, ... 6 entrées ],
  "ab": {"a": [...], "b": [...], "cur": "a"} }
```
Master : `{"effects": [ ... 8 entrées ]}`. Les presets utilisateur (« My preset N ») sont stockés à part, par id d'effet. Les paramètres sont toujours normalisés 0..1. À la restauration : `setInstrument`, `setInstrumentParam` pour chaque indice, puis les décalages de générateurs (04).
