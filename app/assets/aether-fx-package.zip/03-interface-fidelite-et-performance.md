# 03 · Interface : fidélité visuelle, performance, robustesse

## Principe
`fx-window-preview.html` est **la** référence. Il contient tout le dessin (fonction par effet), la logique des commandes et le comportement (rack, ajout, remplacement, avertissement, soundfont, tablette). Tu le **portes** en Jetpack Compose sans rien changer aux valeurs : mêmes coordonnées, mêmes couleurs, mêmes dégradés, mêmes durées. Les rendus `ref-*.png` servent à vérifier.

## Fonctions à porter (dans cet ordre, une par effet)
Utilitaires d'abord : `rr2` (rectangle arrondi), `knob` (potard SVG, voir plus bas), `rail` (bandeau du bas), `mic`, `tag`, `wrapMini` (version carte du rack), `chaikin`/`resample`.
Puis les scènes : `orb`(0 Space) · `echo`(1) · `eq`(2 Tone) · `grip`(3) · `ceil`(4) · `piano`(5) · `organ`(6) · `sax`(7) · `strings`(8) · `guitar`(9) · `amp`(10) · `bass`(11) · `brass`(12) · `voices`(13) · `synth`(14), plus `bg` (ambiance plein cadre des effets 0 à 4).
Chaque scène reçoit `(x, W, H, v, a, t, m)` : contexte, taille, valeurs 0..1, couleur d'accent, temps, `m = 1` pour la **carte du rack** (version réduite) et `0` pour la fenêtre.

## Géométrie
- Fenêtre téléphone : région logique **825 × 343**, contenu **779 × 263** posé à (20, 58). Le bandeau du bas commence à y = 214 (hauteur 71). Les scènes dessinent leur fond sur **toute** la région (de `-OXL`, `-OYL` sur `PWL × PHL`), jamais seulement sur le contenu.
- **Mode tablette** : mêmes dispositions. Scène 1100 × 520, facteur d'agrandissement `KS = 1.28`, contenu centré : `L = (W − 779·KS)/2`, `T = 58 + (H − 58 − 263·KS)/2`, `PWL = W/KS`, `PHL = H/KS`, `OXL = L/KS`, `OYL = T/KS`. Le bandeau s'étire jusqu'en bas : `RH = max(71, PHL − OYL − 214)`. Les écrans tactiles (hit-tests) utilisent la même conversion : `X = (clientX − r.left)/r.width·PWL − OXL`.
- Commandes dans la scène (« hotspots ») : liste `HS[i] = [x, y, rayon, indiceVertical, indiceHorizontal, rectAbsolu?, échelleH?, échelleV?]`. Par défaut le glissement est **relatif** (110 px verticaux = pleine course, 160 px horizontaux). Avec `rectAbsolu` la valeur suit directement la position du doigt dans le rectangle (curseur filtre du Synth, pad XY de Voices). La zone Level du bandeau : x 528..752, y 232..272.

## Identité par instrument (ne pas uniformiser)
| Id | Bandeau (matière) | Potards | Remarque |
|---|---|---|---|
| 5 Piano | laque noire + filet or | ivoire | scène : intérieur de piano à queue |
| 6 Organ | noyer veiné | bakélite brune cannelée | deux claviers de tirettes, cadran V/C, rotary |
| 7 Sax | cuivre perforé | nacre | souffle en particules le long du tube |
| 8 Strings | bois clair | bois clair | construit / dissous, couleur sur toute la roue |
| 9 Guitar | acier brossé | nickel | manche droit, 4 corps |
| 10 Amp | (pas de bandeau) | noirs moletés + liseré ambre | lampes, cône animé, micro mobile |
| 11 Bass | (pas de bandeau) | chrome à anneaux | vumètre, EQ graphique, 3 baffles |
| 12 Brass | velours bordeaux | laiton | sourdines, pistons, section |
| 13 Voices | verre dépoli | verre translucide | pad XY de voyelles, formants |
| 14 Synth | quadrillage LED | plats à LED (point lumineux) | 3 pages Sound / Motion / Voice |
Table des couleurs d'accent et polices (toutes OFL, à placer dans `res/font`) : police de l'interface **Plus Jakarta Sans** ; libellés techniques **Share Tech Mono** ; **Orbitron**, **Space Grotesk**, **Sora**, **JetBrains Mono** selon le tableau.

| Id | Effet | Couleur d'accent | Police du titre |
|---|---|---|---|
| 0 | Æther Space | `#a99ad8` | Space Grotesk |
| 1 | Æther Echo | `#d4b06a` | JetBrains Mono |
| 2 | Prism Tone | `#8fd0ff` | Orbitron |
| 3 | Iron Grip | `#b8c2d4` | Share Tech Mono |
| 4 | Solar Ceiling | `#c9852c` | Sora |
| 5 | Aether Piano | `#e8c98a` | Sora |
| 6 | Aether Organ | `#d9c08a` | Sora |
| 7 | Aether Sax | `#e0a45a` | Sora |
| 8 | Aether Strings | `hsl(36,85%,62%)` | Space Grotesk |
| 9 | Aether Guitar | `#e08a4a` | Space Grotesk |
| 10 | Aether Amp | `#ff9a3c` | Orbitron |
| 11 | Aether Bass | `#f0c060` | Sora |
| 12 | Aether Brass | `#e8c060` | Space Grotesk |
| 13 | Aether Voices | `#c9b8ff` | Space Grotesk |
| 14 | Aether Synth | `#7ad0ff` | Orbitron |

## Potard (`knob`)
Un potard est un SVG 100×100 : piste de 270° (pas de rotation de −135°), arc de valeur en couleur d'accent, anneau, jupe (cannelée selon le style), capuchon dégradé, reflet, repère. **Ne le reconstruis pas à chaque image** : pré-rends **un sprite par matière** et fais pivoter le repère seul, ou mets le potard en cache (`drawWithCache`) et ne le redessine que quand sa valeur change. Styles : `flat` (Synth), `glass` (Voices), `flute` (Organ), `knurl` (Amp), `chrome` (Bass), `round` (autres).

## Comportement du rack
Compteur `n / 6 effects` ; une seule carte instrument, toujours première ; ajouter un instrument alors qu'il y en a un le **remplace** (bandeau « X replaces Y ») ; suppression par appui long puis glissé vers la corbeille, avec bandeau « Undo » 5 s (le remplacement n'a pas d'Undo) ; **Surprise me** (verrous : toucher un libellé de potard le verrouille), **A/B** (comparaison avec transition 420 ms), **Edit** (tiroir soundfont, façonneurs seulement : maquette en v1).

## Robustesse : le bug des animations qui disparaissent
Je n'ai **pas** pu le reproduire. Dans l'aperçu d'origine, l'animation se relançait à la fin de chaque image : **une seule exception dans un dessin l'arrêtait pour toujours, pour tous les effets**. Deux autres causes plausibles : perte de contexte graphique (mémoire) et grosse empreinte mémoire. Règles obligatoires (déjà dans l'aperçu, à reproduire) :
1. **Une seule boucle**, qui se **reprogramme en premier** (avant tout dessin). Chaque dessin est dans un `try/catch` : l'erreur est comptée, le dessin concerné est désactivé après 40 erreurs, **les autres effets continuent**.
2. **Changer de preset ne recrée jamais la surface de dessin** ni ne relance la boucle : on ne met à jour que les valeurs.
3. **Surveillance** : si aucune image n'a été dessinée depuis 1,5 s alors que l'écran est visible, relancer la boucle. Relancer aussi quand l'application revient au premier plan.
4. **Perte de contexte** (`contextlost` / `contextrestored` sur le web ; sur Android : surfaces/bitmaps invalidés) : recréer la ressource et redessiner.
5. **Mode Debug** (bouton dans l'aperçu) : affiche ms de dessin par image, qualité, pixels alloués, pertes de contexte, erreurs. Garde-le dans l'application (réglages développeur).

## Performance (à implémenter, mesurable avec le mode Debug)
- **Qui dessine quoi** : rack visible = seules les **cartes** (version réduite) à ~15 images/s ; fenêtre ouverte = **seulement cet effet** à pleine cadence ; les voisins uniquement pendant le balayage (500 ms) ; les autres surfaces sont **libérées** (2×2 px dans l'aperçu).
- **Résolution adaptative** : qualité initiale `min(2, échelle × densité)`. Si le temps de dessin dépasse 12 ms pendant 30 images → qualité × 0,8 (plancher 0,9) et **mode Lite** ; retour progressif si < 5 ms pendant 300 images.
- **Mode Lite** : plafonds de particules Strings 160 (480 sinon), Sax 40 (90), Brass 30 (70) ; mêmes dessins sinon. À exposer aussi comme réglage manuel.
- **Cache** : fonds, grain du bois, quadrillages, corps de violon/guitare, matières des bandeaux = dessinés une fois (`drawWithCache` / `ImageBitmap`), seules les parties animées sont redessinées.
- **Pas d'allocation dans le dessin** : réutilise `Path`, `Brush`, tableaux de particules (primitifs). Aucune recomposition par image : lis l'horloge uniquement dans la portée de dessin.
- **Mémoire** : une surface plein cadre active à la fois ; ne mets pas les surfaces des effets non visibles en mémoire.

## Correspondance Canvas 2D → Compose
`createLinearGradient/RadialGradient` + `addColorStop` → `Brush.linearGradient/radialGradient` · `arc/ellipse` → `Path.arcTo / addOval` · `clip` → `clipPath` · `setLineDash` → `PathEffect.dashPathEffect` · `globalAlpha` → paramètre `alpha` · `save/restore/translate/scale/rotate` → `withTransform` · **`shadowBlur` n'existe pas en Compose natif** : simule-le par des couches translucides empilées (méthode déjà utilisée pour `FaderThumb.kt`) · `fillText` → `drawText(TextMeasurer)`. Garde chaque constante numérique identique à l'aperçu.

## Icônes
`ic_fx_*.xml` : VectorDrawable 32×32, blanc unique. Conversion vérifiée pixel à pixel contre le SVG d'origine (au pire 35 pixels sur 16 384 s'écartent de plus de 40/255, soit l'anti-crénelage). N'y touche pas.

## Critères de réussite
Pour chaque effet : capture Compose du preset par défaut à la même taille que `ref-NN-*.png`, comparaison côte à côte, aucun écart de couleur, de position ni d'animation visible ; puis les 6 presets contre la feuille `*-presets.png`. Tablette : `ref-tablet-*.png`.
