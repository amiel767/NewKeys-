package com.aetherkeys.instruments

import android.content.Context
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Æther Piano — 9 models, each a scene (photo) + a sound character. Param order (12): 0 Hardness, 1 Tone, 2 Resonance, 3 Lid,
 * 4 Mic, 5 Space, 6 Width, 7 Level, 8 Release, 9 Velocity curve, 10 Pedal noise, 11 MODEL (i / 8, discrete: the engine rounds it).
 * Scene images (supplied separately): res/drawable-nodpi/ae_piano_<id>.webp, id = felt studio bright mellow dark upright lady honky electric.
 */
class AePianoModel(val id: String, val name: String, val tag: String, val dark: Boolean, val acc: Color, val petals: List<Color>, val ptype: AePType, d: FloatArray, idx: Int) {
    val values: FloatArray = d + (idx / 8f)
}
private fun col(h: Long) = Color(0xFF000000 or h)
object AePianoModels {
    val all = listOf(
        AePianoModel("felt", "Felt", "Soft felt hammers · warm & round", false, col(0xE9A8B8), listOf(col(0xF7C6D3), col(0xFBE0E6), col(0xF2A9BD)), AePType.PETAL, floatArrayOf(.25f, .45f, .5f, .6f, .5f, .45f, .5f, .75f, .5f, .5f, .4f), 0),
        AePianoModel("studio", "Studio", "Concert grand · balanced & clear", false, col(0x4F9FE6), listOf(col(0xFFFFFF), col(0xCFE6FF), col(0x9CCAF5)), AePType.SPARK, floatArrayOf(.55f, .5f, .45f, .8f, .45f, .35f, .6f, .75f, .45f, .55f, .3f), 1),
        AePianoModel("bright", "Bright", "Crisp attack · sparkling top", false, col(0xE8A812), listOf(col(0xFFE9A8), col(0xFFD166), col(0xFFF3C9)), AePType.LEAF, floatArrayOf(.85f, .7f, .35f, .9f, .35f, .3f, .7f, .72f, .4f, .6f, .25f), 2),
        AePianoModel("mellow", "Mellow", "Warm mids · rounded highs", true, col(0xFF9A5A), listOf(col(0xFFB27A), col(0xFF8A5C), col(0xFFD0A0)), AePType.PETAL, floatArrayOf(.3f, .3f, .6f, .55f, .55f, .5f, .5f, .74f, .55f, .45f, .4f), 3),
        AePianoModel("dark", "Dark", "Deep bass · cinematic night", true, col(0x8A9BFF), listOf(col(0xAEBCFF), col(0x7F8FE8), col(0xDFE6FF)), AePType.STAR, floatArrayOf(.3f, .2f, .75f, .4f, .6f, .7f, .7f, .72f, .65f, .4f, .45f), 4),
        AePianoModel("upright", "Upright", "Wooden upright · intimate", true, col(0xD9A15A), listOf(col(0xE8C58F), col(0xD9A15A), col(0xFFF1D6)), AePType.DUST, floatArrayOf(.5f, .4f, .4f, .5f, .3f, .25f, .4f, .74f, .35f, .5f, .6f), 5),
        AePianoModel("lady", "Lady D", "Parlor grand · close & golden", true, col(0xE0A25A), listOf(col(0xFFD9A0), col(0xF2B866), col(0xFFF0D0)), AePType.SPARK, floatArrayOf(.4f, .4f, .35f, .55f, .25f, .2f, .45f, .74f, .4f, .5f, .3f), 6),
        AePianoModel("honky", "Honky", "Detuned old upright · vintage", false, col(0xB8863C), listOf(col(0xA8743A), col(0xC89A5A), col(0x8A5A28)), AePType.LEAF, floatArrayOf(.7f, .5f, .3f, .5f, .3f, .3f, .5f, .72f, .35f, .6f, .7f), 7),
        AePianoModel("electric", "Electric Keys", "Tine keys · tremolo & neon", true, col(0xFF6AD5), listOf(col(0xFF8BE0), col(0x7BE0FF), col(0xC9A0FF)), AePType.NEON, floatArrayOf(.5f, .5f, .2f, .5f, .4f, .4f, .7f, .7f, .4f, .5f, .2f), 8))
}
/** Plugs into AeManager.presets(PIANO): choosing a model = loading a preset (knobs glide, MODEL switches at once). */
val AePianoPresets: List<AePreset> = AePianoModels.all.map { AePreset(it.name, "Piano", it.values) }

object AePianoAssets {
    private val cache = LruCache<String, ImageBitmap>(4)
    fun bitmap(ctx: Context, id: String): ImageBitmap? {
        val name = "ae_piano_$id"; cache.get(name)?.let { return it }
        val rid = ctx.resources.getIdentifier(name, "drawable", ctx.packageName); if (rid == 0) return null
        val bm = BitmapFactory.decodeResource(ctx.resources, rid) ?: return null
        return bm.asImageBitmap().also { cache.put(name, it) }
    }
}

private class K(val label: String, val idx: Int, val fmt: (Float) -> String)
private fun pc(v: Float) = "${(v * 100).toInt()}%"
private fun db(v: Float) = "${(-40 + v * 46).toInt()}dB"
private val PK = listOf(K("Hardness", 0, ::pc), K("Tone", 1) { "${((it - .5f) * 16).toInt()}dB" }, K("Resonance", 2, ::pc),
    K("Lid", 3) { if (it < .33f) "Closed" else if (it < .66f) "Half" else "Open" }, K("Mic", 4) { if (it < .33f) "Close" else if (it < .66f) "Room" else "Hall" },
    K("Space", 5, ::pc), K("Width", 6, ::pc), K("Level", 7, ::db))
private val PSL = listOf(K("Release", 8) { "${(50 + it * 450).toInt()}ms" }, K("Velocity", 9) { if (it < .4f) "Soft" else if (it < .6f) "Linear" else "Hard" }, K("Pedal noise", 10, ::pc))

/** Card preview (middle of the card): the Felt scene, centre-cropped. */
@Composable
fun AePianoCardPreview(modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp = remember { AePianoAssets.bitmap(ctx, "felt") }
    Canvas(modifier.clip(RoundedCornerShape(12.dp))) {
        bmp?.let { val sc = max(size.width / it.width, size.height / it.height); val dw = it.width * sc; val dh = it.height * sc
            drawImage(it, dstOffset = IntOffset(((size.width - dw) / 2f).roundToInt(), ((size.height - dh) / 2f).roundToInt()), dstSize = IntSize(dw.roundToInt(), dh.roundToInt())) }
    }
}

/** The Piano window. Own container (scene fills it, stage UI letterboxed on top) so full screen can be offered. */
@Composable
fun AePianoWindow(manager: AeManager, strip: Int, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val s = manager.sessions[strip] ?: return
    val c = remember(s) { AeCtl(s, manager) }
    val scene = remember(s) { AeSceneRuntime(procedural = false) }
    var fs by remember { mutableStateOf(false) }
    var base by remember { mutableIntStateOf(48) }
    AeFullscreenHost(fs, { fs = false }) { full ->
        PianoContent(manager, s, c, scene, full, base, { base = it }, { fs = !fs }, onClose, if (full) Modifier.fillMaxSize() else modifier.clip(RoundedCornerShape(24.dp)))
    }
}

@Composable
private fun PianoContent(manager: AeManager, s: AeSession, c: AeCtl, scene: AeSceneRuntime, full: Boolean, base: Int, onBase: (Int) -> Unit, onFs: () -> Unit, onClose: () -> Unit, mod: Modifier) {
    val ctx = LocalContext.current
    val dens = LocalDensity.current.density
    val model = AePianoModels.all[s.preset.coerceIn(0, AePianoModels.all.size - 1)]
    val th = rememberAeTheme(model.dark, model.acc)
    val baseNow by rememberUpdatedState(base)
    var lastTouch by remember { mutableLongStateOf(System.nanoTime()) }
    var hidden by remember { mutableStateOf(false) }
    var ped by remember { mutableStateOf(false) }
    LaunchedEffect(model.id) { scene.setBackground(AePianoAssets.bitmap(ctx, model.id)); scene.particles.type = model.ptype; scene.particles.colors = model.petals }
    LaunchedEffect(s) {
        var last = System.nanoTime(); var seen = s.noteEvents
        while (true) {
            delay(if (s.held.isNotEmpty()) 33L else 45L)
            val now = System.nanoTime(); val dt = min(0.1f, (now - last) / 1e9f); last = now
            manager.pollLevel(s.strip); hidden = full && (now - lastTouch) > 4_000_000_000L
            if (s.noteEvents != seen) {
                seen = s.noteEvents; val ux = 0.3f + ((s.lastNote - baseNow) / 36f).coerceIn(0f, 1f) * 0.4f
                scene.waves.drop(ux, 0.8f, 0.5f * (0.5f + 0.9f * 0.78f)); scene.particles.spawn(2, scene.w.toFloat(), scene.h.toFloat(), scene.dp, ux * scene.w, scene.h * 0.45f, true)
            }
            if (Random.nextFloat() < dt * scene.particles.ambientRate) scene.particles.spawn(1, scene.w.toFloat(), scene.h.toFloat(), scene.dp)
            scene.update(dt)
        }
    }
    val ui by animateFloatAsState(if (hidden) 0f else 1f, label = "ui")
    Box(mod.pointerInput(Unit) { awaitPointerEventScope { while (true) { awaitPointerEvent(PointerEventPass.Initial); lastTouch = System.nanoTime() } } }) {
        Canvas(Modifier.fillMaxSize().onSizeChanged { scene.resize(it.width, it.height, dens) }) { scene.frame; scene.draw(this); scene.particles.draw(this) }
        AeStage(Modifier.fillMaxSize()) {
            AeT("ÆTHER PIANO", 10, th.ink2, Modifier.at(24, 24, 200, 12), AeFonts.display, FontWeight.Normal, 0.3f)
            AeT("PIANO", 10, th.ink, Modifier.at(300, 12, 400, 12), AeFonts.display, FontWeight.Light, 0.42f, TextAlign.Center)
            AeT(model.name.uppercase(), 30, th.ink, Modifier.at(300, 24, 400, 38), AeFonts.display, FontWeight.ExtraLight, 0.2f, TextAlign.Center)
            AeT(model.tag, 11, th.ink2, Modifier.at(300, 66, 400, 14), AeFonts.display, FontWeight.Light, 0.14f, TextAlign.Center)
            AeIconBtn(th, if (full) 1 else 0, 914, 14, onFs); AeIconBtn(th, 2, 954, 14, onClose)
            Box(Modifier.fillMaxSize().graphicsLayer { alpha = ui }) {
                AeModelList(th, AePianoModels.all.map { it.name }, s.preset, 28, 100) { manager.loadPreset(s.strip, it) }
                AeGlassCard(th, 712, 92, 262, 236)
                PK.forEachIndexed { j, k -> AeLightKnob(th, c.v(k.idx), k.label, k.fmt(c.v(k.idx)), 722 + (j % 4) * 62, 104 + (j / 4) * 70) { c.set(k.idx, it) } }
                PSL.forEachIndexed { j, k -> AeLightSlider(th, c.v(k.idx), k.label, 726, 250 + j * 24) { c.set(k.idx, it) } }
                AeGlassKeyboard(c, th, base, 150, 396, 700, 52)
                AeSmallBtn(th, "PED", 66, 410, 36, 28, ped) { ped = !ped; manager.setSustain(s.strip, ped) }
                AeSmallBtn(th, "−", 108, 410, 28, 28) { onBase((base - 12).coerceAtLeast(24)) }
                AeSmallBtn(th, "+", 864, 410, 28, 28) { onBase((base + 12).coerceAtMost(60)) }
            }
        }
    }
}
