package com.aetherkeys.instruments

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.LruCache
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.delay
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/**
 * Æther Strings — 8 models. Param order (13): 0 Players (1..16), 1 Bow, 2 Vibrato, 3 Vib rate, 4 Ensemble, 5 Bright, 6 Body,
 * 7 Position (tasto..pont.), 8 Room, 9 Dissolve, 10 Legato, 11 Level, 12 MODEL (i / 7, discrete: the engine rounds it).
 * Instrument images (supplied separately, transparent, any aspect, >= 720 px tall):
 * res/drawable-nodpi/ae_str_violin, ae_str_viola, ae_str_cello, ae_str_bass (.webp or .png).
 */
class AeStringsModel(val name: String, val tag: String, val dark: Boolean, val acc: Color, val petals: List<Color>, val ptype: AePType, val solo: String?, val base: Int, val pal: FloatArray, d: FloatArray, idx: Int) {
    val values: FloatArray = d + (idx / 7f)
}
private fun col(h: Long) = Color(0xFF000000 or h)
object AeStringsModels {
    val all = listOf(
        AeStringsModel("Solo Violin", "One violin · expressive & airy", false, col(0x4F9FE6), listOf(col(0xFFFFFF), col(0xCFE6FF), col(0xF5C6D8)), AePType.PETAL, "violin", 60, floatArrayOf(.62f, .78f, .95f, .86f, .88f, .97f, 1f, .86f, .86f, 1f, .8f, .7f, .55f, .72f, .86f, .62f, .40f, .9f, 5f), floatArrayOf(0f, .45f, .45f, .5f, .2f, .55f, .5f, .5f, .35f, .2f, .5f, .75f), 0),
        AeStringsModel("Solo Viola", "One viola · dark & rosy", false, col(0xC0577A), listOf(col(0xF5B5C8), col(0xE98AA8), col(0xFFD7E2)), AePType.PETAL, "viola", 48, floatArrayOf(.70f, .55f, .75f, .96f, .66f, .72f, 1f, .80f, .62f, 1f, .7f, .5f, .60f, .45f, .62f, .4f, .42f, .9f, 5f), floatArrayOf(0f, .5f, .45f, .45f, .2f, .5f, .55f, .5f, .4f, .2f, .5f, .75f), 1),
        AeStringsModel("Solo Cello", "One cello · deep & green dusk", false, col(0x3F9A78), listOf(col(0xBFE8C9), col(0x8ED1A8), col(0xE8F6D8)), AePType.LEAF, "cello", 36, floatArrayOf(.30f, .52f, .50f, .60f, .80f, .68f, .93f, .93f, .78f, .9f, 1f, .8f, .28f, .50f, .46f, .5f, .44f, .9f, 5f), floatArrayOf(0f, .55f, .4f, .4f, .2f, .45f, .65f, .45f, .4f, .2f, .5f, .78f), 2),
        AeStringsModel("Solo Bass", "One double bass · golden low end", false, col(0xC8892E), listOf(col(0xFFE0A0), col(0xF2C46B), col(0xFFF0CF)), AePType.DUST, "bass", 36, floatArrayOf(.85f, .70f, .45f, .98f, .84f, .58f, 1f, .92f, .75f, 1f, .85f, .55f, .68f, .55f, .35f, .7f, .45f, .9f, 5f), floatArrayOf(0f, .6f, .3f, .35f, .2f, .4f, .7f, .45f, .4f, .15f, .5f, .8f), 3),
        AeStringsModel("Section", "Compact section · choose the players", false, col(0xE08A6A), listOf(col(0xFFD1BF), col(0xFFB59A), col(0xFFF0E6)), AePType.PETAL, null, 48, floatArrayOf(.78f, .84f, .95f, .99f, .86f, .80f, 1f, .92f, .82f, 1f, .85f, .7f, .62f, .72f, .80f, .5f, .4f, .9f, 5f), floatArrayOf(.2f, .5f, .4f, .5f, .55f, .5f, .55f, .5f, .45f, .25f, .5f, .75f), 4),
        AeStringsModel("Orchestra", "Full strings · wide hall", false, col(0x8A6AD8), listOf(col(0xE8D8FF), col(0xC9B0F5), col(0xFFE0F2)), AePType.SPARK, null, 48, floatArrayOf(.55f, .50f, .80f, .78f, .70f, .92f, .97f, .84f, .90f, .95f, .8f, 1f, .45f, .45f, .70f, .5f, .40f, .9f, 5f), floatArrayOf(.47f, .55f, .4f, .5f, .7f, .5f, .6f, .5f, .6f, .3f, .5f, .75f), 5),
        AeStringsModel("Pizzicato", "Plucked · crisp & playful", false, col(0x2FB59A), listOf(col(0xD8FFF4), col(0x9BE8D4), col(0xFFFFFF)), AePType.SPARK, null, 48, floatArrayOf(.60f, .88f, .85f, .82f, .96f, .90f, .98f, .98f, .88f, 1f, .98f, .8f, .50f, .78f, .76f, .5f, .42f, .9f, 5f), floatArrayOf(.2f, .1f, .2f, .5f, .4f, .6f, .5f, .6f, .35f, .2f, .3f, .75f), 6),
        AeStringsModel("Pad", "Slow bowed cloud · aurora night", true, col(0x6FD8D0), listOf(col(0x9FF0E8), col(0xB4A8FF), col(0xE0FFF8)), AePType.STAR, null, 48, floatArrayOf(.05f, .08f, .20f, .16f, .26f, .44f, .38f, .52f, .64f, .45f, .9f, .9f, .08f, .15f, .28f, .5f, .36f, .9f, 5f), floatArrayOf(.35f, .9f, .5f, .3f, .85f, .35f, .5f, .35f, .75f, .7f, .8f, .7f), 7))
}
val AeStringsPresets: List<AePreset> = AeStringsModels.all.map { AePreset(it.name, "Strings", it.values) }

object AeStringsArt {
    private val cache = LruCache<String, Bitmap>(4)
    fun bitmap(ctx: Context, kind: String): Bitmap? {
        val name = "ae_str_$kind"; cache.get(name)?.let { return it }
        val rid = ctx.resources.getIdentifier(name, "drawable", ctx.packageName); if (rid == 0) return null
        val bm = BitmapFactory.decodeResource(ctx.resources, rid) ?: return null
        return bm.also { cache.put(name, it) }
    }
}

private class K(val label: String, val idx: Int, val fmt: (Float) -> String)
private fun pc(v: Float) = "${(v * 100).toInt()}%"

/** Card preview (middle of the card): the violin image, fitted. */
@Composable
fun AeStringsCardPreview(modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp = remember { AeStringsArt.bitmap(ctx, "violin") }
    Canvas(modifier) {
        bmp?.let { val w = min(size.width, size.height * it.width / it.height); val h = w * it.height / it.width
            drawImage(it.asImageBitmap(), dstOffset = IntOffset(((size.width - w) / 2f).roundToInt(), ((size.height - h) / 2f).roundToInt()), dstSize = IntSize(w.roundToInt(), h.roundToInt())) }
    }
}

private fun kindsFor(model: AeStringsModel, players: Float): List<String> {
    model.solo?.let { return listOf(it) }
    val n = min(8, 1 + (players * 15).roundToInt()); val rank = mapOf("violin" to 0, "viola" to 1, "cello" to 2, "bass" to 3)
    return listOf("violin", "violin", "viola", "cello", "violin", "viola", "cello", "bass").take(n).sortedBy { rank[it] }
}

/** Floating instruments, drawn into the half-resolution layer that the water reflects. */
private fun drawLayer(cv: android.graphics.Canvas, W: Int, H: Int, t: Float, kinds: List<String>, solo: Boolean, diss: Float, act: Float, art: (String) -> Bitmap?, paint: Paint, onDissolve: (Float, Float) -> Unit) {
    val n = kinds.size
    kinds.forEachIndexed { i, k ->
        val b = art(k) ?: return@forEachIndexed
        val hf = if (solo) 0.5f else when (k) { "violin" -> 0.30f; "viola" -> 0.32f; "cello" -> 0.40f; else -> 0.48f } * (if (n < 4) 1.35f else 1f)
        val h = hf * H; val w = h * b.width / b.height
        val x = if (n == 1) W * 0.46f else W * (0.25f + 0.42f * i / (n - 1)); val by = H * 0.688f
        val bob = sin(t * 0.7f + i * 1.7f) * H * 0.013f; val rot = sin(t * 0.5f + i * 2.1f) * 0.035f + (if (n > 1) (i - (n - 1) / 2f) * 0.018f else 0f)
        cv.save(); cv.translate(x, by + bob); cv.rotate(Math.toDegrees(rot.toDouble()).toFloat())
        if (act > 0.02f) { paint.shader = RadialGradient(0f, -h * 0.45f, h * 0.62f, intArrayOf(android.graphics.Color.argb((0.2f * act * 255).toInt(), 255, 226, 170), 0), null, Shader.TileMode.CLAMP); cv.drawRect(-w * 2f, -h * 1.2f, w * 2f, h * 0.2f, paint); paint.shader = null }
        paint.alpha = (255 * (1f - diss * act * 0.5f)).toInt().coerceIn(0, 255)
        cv.drawBitmap(b, null, RectF(-w / 2f, -h, w / 2f, 0f), paint); paint.alpha = 255; cv.restore()
        if (act > 0.1f && diss > 0.3f && Random.nextFloat() < diss * 0.25f) onDissolve(x + (Random.nextFloat() - 0.5f) * w, by - h * Random.nextFloat())
    }
}

/** The Strings window: same scene concept as the piano, instruments float on the water. */
@Composable
fun AeStringsWindow(manager: AeManager, strip: Int, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val s = manager.sessions[strip] ?: return
    val c = remember(s) { AeCtl(s, manager) }
    val scene = remember(s) { AeSceneRuntime(procedural = true) }
    var fs by remember { mutableStateOf(false) }
    var base by remember { mutableIntStateOf(48) }
    AeFullscreenHost(fs, { fs = false }) { full ->
        StringsContent(manager, s, c, scene, full, base, { base = it }, { fs = !fs }, onClose, if (full) Modifier.fillMaxSize() else modifier.clip(RoundedCornerShape(24.dp)))
    }
}

@Composable
private fun StringsContent(manager: AeManager, s: AeSession, c: AeCtl, scene: AeSceneRuntime, full: Boolean, base: Int, onBase: (Int) -> Unit, onFs: () -> Unit, onClose: () -> Unit, mod: Modifier) {
    val ctx = LocalContext.current
    val dens = LocalDensity.current.density
    val model = AeStringsModels.all[s.preset.coerceIn(0, AeStringsModels.all.size - 1)]
    val th = rememberAeTheme(model.dark, model.acc)
    var lastTouch by remember { mutableLongStateOf(System.nanoTime()) }
    var hidden by remember { mutableStateOf(false) }
    val paint = remember { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG) }
    LaunchedEffect(model.name) { scene.setPalette(model.pal); scene.particles.type = model.ptype; scene.particles.colors = model.petals; onBase(model.base) }
    LaunchedEffect(s) {
        var last = System.nanoTime(); var act = 0f
        while (true) {
            delay(if (s.held.isNotEmpty()) 33L else 45L)
            val now = System.nanoTime(); val dt = min(0.1f, (now - last) / 1e9f); last = now
            manager.pollLevel(s.strip); hidden = full && (now - lastTouch) > 4_000_000_000L
            act += ((if (s.held.isNotEmpty()) 1f else 0f) - act) * min(1f, dt * 7f)
            if (Random.nextFloat() < dt * scene.particles.ambientRate) scene.particles.spawn(1, scene.w.toFloat(), scene.h.toFloat(), scene.dp)
            val m = AeStringsModels.all[s.preset.coerceIn(0, AeStringsModels.all.size - 1)]; val kinds = kindsFor(m, s.values[0])
            scene.update(dt) { cv, W, H, t -> drawLayer(cv, W, H, t, kinds, m.solo != null, s.values[9], act, { AeStringsArt.bitmap(ctx, it) }, paint) { x, y -> scene.particles.spawn(1, scene.w.toFloat(), scene.h.toFloat(), scene.dp, x * 2f, y * 2f, false) } }
        }
    }
    val XK = listOf(K("Players", 0) { if (model.solo != null) "1" else "${1 + (it * 15).roundToInt()}" }, K("Bow", 1, ::pc), K("Vibrato", 2, ::pc), K("Vib rate", 3) { "${"%.1f".format(4f + it * 3f)}Hz" },
        K("Ensemble", 4, ::pc), K("Bright", 5, ::pc), K("Body", 6, ::pc), K("Position", 7) { if (it < .33f) "Tasto" else if (it < .66f) "Natural" else "Pont." },
        K("Room", 8, ::pc), K("Dissolve", 9, ::pc), K("Legato", 10, ::pc), K("Level", 11) { "${(-40 + it * 46).toInt()}dB" })
    val ui by animateFloatAsState(if (hidden) 0f else 1f, label = "ui")
    Box(mod.pointerInput(Unit) { awaitPointerEventScope { while (true) { awaitPointerEvent(PointerEventPass.Initial); lastTouch = System.nanoTime() } } }) {
        Canvas(Modifier.fillMaxSize().onSizeChanged { scene.resize(it.width, it.height, dens) }) { scene.frame; scene.draw(this); scene.particles.draw(this) }
        AeStage(Modifier.fillMaxSize()) {
            AeT("ÆTHER STRINGS", 10, th.ink2, Modifier.at(24, 24, 200, 12), AeFonts.display, FontWeight.Normal, 0.3f)
            AeT("STRINGS", 10, th.ink, Modifier.at(300, 12, 400, 12), AeFonts.display, FontWeight.Light, 0.42f, TextAlign.Center)
            AeT(model.name.uppercase(), 30, th.ink, Modifier.at(300, 24, 400, 38), AeFonts.display, FontWeight.ExtraLight, 0.2f, TextAlign.Center)
            AeT(model.tag, 11, th.ink2, Modifier.at(300, 66, 400, 14), AeFonts.display, FontWeight.Light, 0.14f, TextAlign.Center)
            AeIconBtn(th, if (full) 1 else 0, 914, 14, onFs); AeIconBtn(th, 2, 954, 14, onClose)
            Box(Modifier.fillMaxSize().graphicsLayer { alpha = ui }) {
                AeModelList(th, AeStringsModels.all.map { it.name }, s.preset, 28, 100) { manager.loadPreset(s.strip, it) }
                AeGlassCard(th, 712, 92, 262, 290)
                XK.forEachIndexed { j, k -> AeLightKnob(th, c.v(k.idx), k.label, k.fmt(c.v(k.idx)), 722 + (j % 4) * 62, 104 + (j / 4) * 90) { c.set(k.idx, it) } }
                AeGlassKeyboard(c, th, base, 150, 396, 700, 52)
                AeSmallBtn(th, "−", 108, 410, 28, 28) { onBase((base - 12).coerceAtLeast(24)) }
                AeSmallBtn(th, "+", 864, 410, 28, 28) { onBase((base + 12).coerceAtMost(60)) }
            }
        }
    }
}
