# Æther Piano + Æther Strings · Kotlin (interface seule, sans assets)

Deux instruments séparés, chacun avec sa carte, sa fenêtre et ses modèles. Même concept de scène (ciel, pétales, eau animée, plein écran).

## Fichiers
| Fichier | Rôle |
|---|---|
| `AePianoUi.kt` | Piano : 9 modèles, fenêtre, carte, plein écran |
| `AeStringsUi.kt` | Strings : 8 modèles, nombre d'instruments (Players), instruments flottants, fenêtre, carte |
| `AeWaterScene.kt` | scène partagée : eau (équation d'onde), ciel, particules, shader AGSL (Android 13+) avec version Canvas en dessous |
| `AeLightControls.kt` | potards, curseurs, clavier verre, boutons, liste, hôte plein écran |
| `AeCore.kt`, `AeWindow.kt` | **remplacent** ceux du paquet précédent : ajout de PIANO (fxId 17, 12 params) et STRINGS (fxId 18, 13 params), 6 cartes (3×2), MIDI |

## Assets à fournir (res/drawable-nodpi/, noms exacts)
- Piano : `ae_piano_felt`, `ae_piano_studio`, `ae_piano_bright`, `ae_piano_mellow`, `ae_piano_dark`, `ae_piano_upright`, `ae_piano_lady`, `ae_piano_honky`, `ae_piano_electric` (.webp ou .png, 16:9 conseillé, 2400 px de large ou plus ; sans interface ni texte).
- Strings : `ae_str_violin`, `ae_str_viola`, `ae_str_cello`, `ae_str_bass` (fond transparent, ≥ 720 px de haut, proportions libres).
Tant qu'une image manque, la scène s'affiche sans elle (pas de plantage).

## Branchement
1. Copier les fichiers (les deux `.kt` du paquet précédent sont remplacés par ceux-ci).
2. Dépendance : `androidx.core:core-ktx` (déjà là en général). Compose animation/foundation déjà présents.
3. Le modèle choisi est le dernier paramètre (Piano : index 11 = i/8 ; Strings : index 12 = i/7). Le moteur l'arrondit. Il passe immédiatement (jamais en fondu).
4. MIDI : `ae.ccPiano`, `ae.ccStrings` (CC64 sustain géré par `setSustain`). Strings : CC1 vibrato, CC2 archet, CC11 expression.
5. Fenêtre soundfonts : `PATCH-SoundfontWindow.md` du paquet précédent (inchangé). Ratio conseillé 1000:460.

## Réglages doux (demandés)
Étincelles, pétales et lueurs à ~50 %, gouttes plus rares et plus faibles, réfraction de l'eau divisée par 2, reflet spéculaire réduit.

## À savoir
- Rien n'a été compilé ni testé sur appareil.
- Pas de moteur C++ pour Piano et Strings : tant que `loadInstrument` renvoie `false`, la carte ne s'ouvre pas (hôte factice possible pour tester l'interface).
- Sous Android 12 et moins : version Canvas (même ambiance, sans réfraction ni reflet précis).
- Les images que tu m'as envoyées sont de basse résolution (458×256 par piano) : prévoir des versions haute résolution pour le plein écran.
