package com.aetherkeys.fx.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * The whole FX window, bound to [store]. Replaces the old FxWindow.
 * [scale]: logical px -> dp (calibrate against the PNG references; see the brief).
 */
@Composable
fun FxWindowHost(store: FxShellStore, scale: Float, modifier: Modifier = Modifier) {
    LaunchedEffect(store.notice) {
        if (store.notice != null) { delay(2400); store.notice = null }
    }
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1A2030), Color(0xFF121722)))),
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp)) {
            Header(store)
            Spacer(Modifier.height(10.dp))
            val openId = store.openId
            val module = openId?.let { store.modules[it] }
            if (module != null) {
                FxOpenPanel(
                    module = module,
                    params = store.valuesOf(module.id),
                    scale = scale,
                    presets = module.presets,
                    activePreset = null,
                    bypassed = store.isBypassed(module.id),
                    abLabel = store.abLabel(module.id),
                    onParam = { i, v -> store.setParam(module.id, i, v) },
                    onPreset = { name -> store.applyPreset(module.id, module.presets.indexOf(name)) },
                    onBypass = { store.toggleBypass(module.id) },
                    onAb = { store.toggleAB(module.id) },
                    onSurprise = { store.surprise(module.id) },
                    onClose = { store.openId = null },
                    time = 0f,
                )
            } else {
                Rack(store, scale)
            }
        }
        if (store.addOpen) {
            Box(modifier = Modifier.fillMaxSize().background(Color(0xE60A0E16))) {
                FxAddOverlay(
                    modules = store.modules.values.sortedBy { it.id },
                    tab = store.addTab,
                    onTab = { store.addTab = it },
                    onPick = { m ->
                        val ok = if (m.kind == FxScreenKind.EFFECT) store.addEffect(m.id) else store.setInstrument(m.id)
                        if (ok) store.addOpen = false
                    },
                    isOn = { store.isOn(it) },
                    effectsUsed = store.effectCount(),
                    onClose = { store.addOpen = false },
                )
            }
        }
        store.notice?.let { msg ->
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xF0232A3A))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(msg, fontSize = 12.sp, color = Color(0xFFE6EAF3)) }
        }
    }
}

@Composable
private fun Header(store: FxShellStore) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text("Effects", fontSize = 22.sp, color = Color(0xFFD7DCE8))
        Spacer(Modifier.weight(1f))
        Text("${store.effectCount()} / 6 effects", fontSize = 13.sp, color = Color(0xFF8D96AB))
        Spacer(Modifier.width(12.dp))
        Chip("+ Instrument") { store.addTab = FxAddTab.INSTRUMENT; store.addOpen = true }
        Spacer(Modifier.width(8.dp))
        Chip("+ Effect") { store.addTab = FxAddTab.EFFECTS; store.addOpen = true }
        Spacer(Modifier.width(8.dp))
        Chip("✕") { store.openId = null; store.addOpen = false }
    }
}

@Composable
private fun Rack(store: FxShellStore, scale: Float) {
    val ids = buildList {
        store.instrumentOf(store.strip)?.let { add(it) }
        store.slotsOf(store.strip).forEach { if (it != null) add(it) }
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(ids) { id ->
            val m = store.modules[id] ?: return@items
            RackCard(m) { store.openId = id }
        }
    }
}

@Composable
private fun Chip(label: String, onClick: () -> Unit) {
    Text(
        label,
        fontSize = 13.sp,
        color = Color(0xFFE6EAF3),
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

/** Card size from FxGeom (CSS px). Mini scene is driven by rememberFxClock(fullRate = false). */
@Composable
internal fun RackCard(m: EffectModule, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .size(FxGeom.CARD_W.dp, FxGeom.CARD_H.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF232A3A))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
    ) {
        Text(m.type.uppercase(), fontSize = 10.sp, color = Color(0xFF8D96AB))
        Spacer(Modifier.height(6.dp))
        Text(m.name, fontSize = 16.sp, color = Color(0xFFE6EAF3))
        Spacer(Modifier.height(8.dp))
        Box(modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF111620)))
        Spacer(Modifier.weight(1f))
        Text("${m.knobs.size} knobs", fontSize = 11.sp, color = Color(0xFF8D96AB))
    }
}
