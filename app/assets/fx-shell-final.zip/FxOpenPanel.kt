package com.aetherkeys.fx.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Measured in the reference preview: scene content box inside the panel, in logical px. */
object FxContent {
    const val W = 779f
    const val H = 263f
    /** Scene frame = content top down to the bottom bar. */
    val SCENE_H: Float get() = FxGeom.BOTTOM_BAR_Y - FxGeom.CONTENT_Y
}

/**
 * Open effect panel. Every control is placed from FxKnobBoxes (logical px x [scale] = dp).
 * Nothing here is laid out by hand: positions come from the measured boxes.
 */
@Composable
fun FxOpenPanel(
    module: EffectModule,
    params: FloatArray,
    scale: Float,
    presets: List<String>,
    activePreset: String?,
    bypassed: Boolean,
    abLabel: String,
    onParam: (index: Int, value: Float) -> Unit,
    onPreset: (String) -> Unit,
    onBypass: () -> Unit,
    onAb: () -> Unit,
    onSurprise: () -> Unit,
    onClose: () -> Unit,
    time: Float,
) {
    val s: Dp = scale.dp
    Box(
        modifier = Modifier
            .width((FxGeom.LOGICAL_W * scale).dp)
            .height((FxGeom.LOGICAL_H * scale).dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0xFF151A26))
            .border(1.dp, module.accent.copy(alpha = 0.35f), RoundedCornerShape(22.dp)),
    ) {
        // header: name, bypass, preset chip, A/B, surprise, close
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(horizontal = (FxGeom.CONTENT_X * scale).dp, vertical = 8.dp),
        ) {
            Text(module.name, fontSize = (20 * scale).sp, color = Color(0xFFE6EAF3))
            Spacer(Modifier.width(12.dp))
            BypassChip(bypassed, onBypass)
            Spacer(Modifier.weight(1f))
            PresetChip(activePreset ?: presets.firstOrNull() ?: "", presets, onPreset)
            Spacer(Modifier.width(8.dp))
            SmallChip("Surprise me", onSurprise)
            Spacer(Modifier.width(6.dp))
            SmallChip(abLabel, onAb)
            Spacer(Modifier.width(6.dp))
            SmallChip("✕", onClose)
        }

        // scene frame, from the measured content origin
        Box(
            modifier = Modifier
                .offset(x = (FxGeom.CONTENT_X * scale).dp, y = (FxGeom.CONTENT_Y * scale).dp)
                .size((FxContent.W * scale).dp, (FxContent.SCENE_H * scale).dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0B0E15)),
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                with(module) { drawScene(params, time, mini = false) }
            }
        }

        // knobs, placed at their measured boxes (x, y, w, h in logical px)
        FxKnobBoxes.byEffect[module.id].orEmpty().forEachIndexed { i, box ->
            val spec = module.knobs.getOrNull(i)
            if (spec != null) {
                val v = params.getOrElse(spec.paramIndex) { 0f }
                FxKnob(
                    label = box.label,
                    value = v,
                    accent = module.accent,
                    diameter = (box.h * scale).dp,
                    valueText = "${(v * 100).toInt()} %",
                    onChange = { onParam(spec.paramIndex, it) },
                    modifier = Modifier.offset(x = (box.x * scale).dp, y = (box.y * scale).dp),
                )
            }
        }

        // bottom bar at the measured Y, with level
        Box(
            modifier = Modifier
                .offset(y = (FxGeom.BOTTOM_BAR_Y * scale).dp)
                .fillMaxWidth()
                .height((FxGeom.BOTTOM_BAR_H * scale).dp)
                .background(Color(0xFF1B1F2B)),
        ) {
            Box(modifier = Modifier.offset(x = (FxGeom.LEVEL_X * scale).dp, y = ((FxGeom.LEVEL_Y - FxGeom.BOTTOM_BAR_Y) * scale - 2f).dp)) {
                Slider(
                    value = params.getOrElse(params.size - 1) { 0.8f },
                    onValueChange = { onParam(params.size - 1, it) },
                    colors = SliderDefaults.colors(thumbColor = Color(0xFFE6E0D2), activeTrackColor = module.accent),
                    modifier = Modifier.width((FxGeom.LEVEL_W * scale).dp),
                )
            }
        }
    }
}

@Composable
private fun BypassChip(bypassed: Boolean, onClick: () -> Unit) = SmallChip(if (bypassed) "● Bypass" else "○ Bypass", onClick)

@Composable
private fun SmallChip(label: String, onClick: () -> Unit) {
    Text(
        label,
        fontSize = 11.sp,
        color = Color(0xFFE6EAF3),
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.07f))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

@Composable
private fun PresetChip(current: String, presets: List<String>, onPick: (String) -> Unit) {
    // Dropdown menu: same chip, list of presets. Presets change values only, never the surface.
    var open by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    Box {
        SmallChip("$current ▾") { open = true }
        androidx.compose.material3.DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            presets.forEach { p ->
                androidx.compose.material3.DropdownMenuItem(text = { Text(p) }, onClick = { open = false; onPick(p) })
            }
        }
    }
}
