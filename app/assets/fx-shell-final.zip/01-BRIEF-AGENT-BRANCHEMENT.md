# Brief agent · Branchement de la fenêtre FX (à faire AVANT toute compilation)

Tu reçois deux zips :
- **fx-screens-spec.zip** : spec exacte et références (`fx_layout_spec.json`, `references/*.png`, `compare_refs.py`, `reference_source_fx_window.html`).
- **fx-shell-kotlin-complete.zip** : coque Kotlin (ce brief est dedans).

Ce brief est pour **écrire le branchement sans compiler**. La compilation viendra plus tard, sur ordre.

## Périmètre (liste blanche)
Tu crées ou modifies UNIQUEMENT :
- les 11 fichiers Kotlin du zip coque, dans `com.aetherkeys.fx.ui`
- `FxRegistry.kt` (déjà généré, à copier tel quel dans `com.aetherkeys.fx`)
- une classe `FxJniEngine` qui implémente `FxEngine` (fichier séparé, ne touche pas au code audio existant)

Interdit : toute modification du moteur audio, des pistes, du mixeur, du DrumPad, des Sheets, de Settings et Setlists. Interdit : retoucher la géométrie (`FxGeometry.kt` est généré, lecture seule).

## Ce que tu dois produire, dans l'ordre
1. **`FxWindowHost` branché au store** : déjà écrit. Vérifie seulement que chaque lambda du panneau appelle une action du store (`setParam`, `applyPreset`, `toggleBypass`, `toggleAB`, `surprise`, `openId = null`). Aucun callback vide ne doit rester.
2. **Ajout** : `FxAddOverlay.onPick` appelle `addEffect` ou `setInstrument` selon le kind. Le panneau se ferme seulement si l'action réussit. Une refusée affiche `notice`.
3. **`FxJniEngine`** : implémente `FxEngine` en appelant les fonctions JNI existantes ou à créer (`fxSetEffect`, `fxSetInstrument`, `fxSetParam`, `fxSetInstrumentParam`, `fxSetBypass`, `fxApplyPreset`, `fxMeter`). Si une fonction JNI n'existe pas, **écris le `external fun` et marque-le `// TODO(native): à implémenter`**, ne l'invente pas dans le C++.
4. **Instanciation** : un seul `FxShellStore` par écran, créé avec `modules` (les `EffectModule` de l'app, un par id 0..14) et le `FxJniEngine`.

## Règles de cohérence (à vérifier et rapporter)
- **Lots** : effets dans 6 emplacements (8 sur master), un instrument par piste, jamais sur master. Le store les fait respecter ; ne contourne pas.
- **Paramètres** : la taille du tableau vient de `FxRegistry.all[id].params`. Le **dernier** paramètre est le niveau. Vérifie cette convention pour chaque id (rapport : id, nombre de params, index du niveau).
- **Potards** : `FxKnobSpec.paramIndex` doit correspondre à l'index du registre. Si un effet a plus de potards que de paramètres ou l'inverse, **ne corrige pas en silence** : liste-le dans le rapport.
- **Presets** : `applyPreset` utilise les valeurs du registre, pas une copie locale.
- **A/B** : deux états par (strip, id). Le label affiché vient de `abLabel`.
- **Surprise me** : ne touche jamais le niveau (dernier index).

## Rapport à rendre (obligatoire, sans compilation)
Un tableau :
| Fichier | Créé / modifié | Symboles non résolus (attendus) | Doute |
Puis :
- la liste des `external fun` ajoutés et ceux qui manquent côté C++ (`TODO(native)`)
- la liste des incohérences de paramètres trouvées (id, attendu, trouvé)
- ce qui n'a pas été vérifié (tout ce qui touche au rendu, au son, à la compilation)

Aucun « ça marche » sans preuve. Aucun test lancé ici : la compilation et les captures viendront à l'étape suivante.

## Ce qui n'est pas dans ce brief
Les scènes animées (`drawScene`), la calibration du facteur d'échelle, la comparaison pixel. Elles viendront après la compilation de cette étape.
