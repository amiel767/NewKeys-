package com.aetherkeys.fx.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Knob with the reference look: dark well, arc track 270 degrees (-135 to +135), accent value arc,
 * glossy cap, white indicator. [value] is normalised 0..1. [onChange] is called while dragging.
 * Vertical drag: 110 px = full range (same constant as the preview).
 */
@Composable
fun FxKnob(
    label: String,
    value: Float,
    accent: Color,
    diameter: Dp,
    valueText: String,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Canvas(
            modifier = Modifier
                .size(diameter)
                .pointerInput(value) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        onChange((value - drag.y / 110f).coerceIn(0f, 1f))
                    }
                },
        ) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val r = size.minDimension / 2f
            val a0 = 135f
            val sweep = 270f * value
            // track
            drawArc(Color.White.copy(alpha = 0.10f), startAngle = a0, sweepAngle = 270f, useCenter = false,
                style = Stroke(width = r * 0.11f, cap = StrokeCap.Round))
            // value arc
            if (value > 0.001f) drawArc(accent, startAngle = a0, sweepAngle = sweep, useCenter = false,
                style = Stroke(width = r * 0.11f, cap = StrokeCap.Round))
            // well
            drawCircle(Color(0xFF0A0C12), radius = r * 0.92f, center = c)
            // cap
            drawCircle(
                Brush.radialGradient(
                    colors = listOf(Color(0xFFB7BCCB), Color(0xFF3A3F52)),
                    center = Offset(c.x - r * 0.25f, c.y - r * 0.3f),
                    radius = r * 0.7f,
                ),
                radius = r * 0.66f, center = c,
            )
            // indicator, rotated with value
            val ang = (a0 + sweep) * PI.toFloat() / 180f
            val p1 = Offset(c.x + cos(ang) * r * 0.2f, c.y + sin(ang) * r * 0.2f)
            val p2 = Offset(c.x + cos(ang) * r * 0.58f, c.y + sin(ang) * r * 0.58f)
            drawLine(Color.White, p1, p2, strokeWidth = r * 0.07f, cap = StrokeCap.Round)
        }
        Text(label, fontSize = 9.sp, color = Color(0xFF8D96AB))
        Text(valueText, fontSize = 10.sp, color = Color(0xFFE6EAF3))
    }
}
