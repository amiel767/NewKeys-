package com.aetherkeys.fx.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin

/**
 * Aether Echo scene. Port of echo(x,W,H,v,a,t,m) from fx-window-preview.html.
 * params: 0 t1, 1 l1, 2 t2, 3 l2, 4 t3, 5 l3, 6 t4, 7 l4 (time, level per tap, 0..1), 8 feedback, 10 wow.
 * The taps' node drawing is reconstructed from the reference screenshot after the last line that was readable
 * in the source; check it against the reference PNG before trusting it.
 */
object FxSceneEcho {
    // tape-reel and history panel geometry, logical panel coords (full mode / mini mode)
    private fun geom(mini: Boolean) = if (mini) Geo(56f, 16f, 74f, 98f, Offset(27f, 50f), 19f)
                                      else Geo(190f, 18f, 400f, 218f, Offset(95f, 80f), 62f)
    private data class Geo(val px0: Float, val py0: Float, val pw: Float, val ph: Float, val reel: Offset, val rr: Float)

    fun DrawScope.draw(v: FloatArray, t: Float, mini: Boolean, accent: Color) {
        val g = geom(mini)
        val pb = g.py0 + g.ph
        val speed = 1.7f - (v[0] + v[2] + v[4] + v[6]) / 4f * 1.3f
        val fb = 0.2f + v[8] * 0.8f
        val wobble = v[10]

        panelSpace {
            // ---- tape reel (rotating, six lobes)
            withTransform({ translate(g.reel.x, g.reel.y); rotate(degrees = (t * speed + sin(t * 6f) * wobble * 0.1f) * 180f / PI.toFloat(), pivot = Offset.Zero) }) {
                drawCircle(
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        colorStops = arrayOf(0f to hex("#E8D2A0"), 0.4f to hex("#7D6335"), 0.7f to hex("#D9BF86"), 1f to hex("#5F4A28")),
                        start = Offset(-g.rr, -g.rr), end = Offset(g.rr, g.rr)),
                    radius = g.rr, center = Offset.Zero,
                )
                for (k in 0 until 6) {
                    withTransform({ rotate(degrees = k * 60f, pivot = Offset.Zero) }) {
                        drawOval(hex("#14110C"), topLeft = Offset(g.rr * 0.55f - g.rr * 0.26f, -g.rr * 0.17f),
                            size = androidx.compose.ui.geometry.Size(g.rr * 0.52f, g.rr * 0.34f))
                    }
                }
                drawCircle(hex("#D9BF86"), radius = g.rr * 0.22f, center = Offset.Zero)
            }
            // specular highlight on the reel
            drawCircle(
                androidx.compose.ui.graphics.Brush.radialGradient(
                    colorStops = arrayOf(0f to Color.White.copy(alpha = 0.33f), 1f to Color.Transparent),
                    center = Offset(g.reel.x, g.reel.y), radius = g.rr),
                radius = g.rr, center = g.reel,
            )

            // ---- history panel background
            drawRect(hex("#0D0B08"), topLeft = Offset(g.px0, g.py0), size = androidx.compose.ui.geometry.Size(g.pw, g.ph))
            // grid: 4 verticals, 4 horizontals, alpha .07
            for (k in 1 until 5) {
                drawRect(Color.White.copy(alpha = 0.07f), topLeft = Offset(g.px0 + g.pw * k / 5f, g.py0), size = androidx.compose.ui.geometry.Size(1f, g.ph))
                drawRect(Color.White.copy(alpha = 0.07f), topLeft = Offset(g.px0, g.py0 + g.ph * k / 5f), size = androidx.compose.ui.geometry.Size(g.pw, 1f))
            }

            // ---- tap points, sorted by x
            val pts = (0 until 4).map { n -> Offset(g.px0 + v[2 * n] * g.pw, pb - v[2 * n + 1] * g.ph) }.sortedBy { it.x }
            val sp2 = (pts[3].x - pts[0].x) + g.pw * 0.1f

            // ---- bars under each tap, and their repeats (echo tails)
            val barAlpha = 0.25f * fb
            for (q in pts) {
                drawRect(accent.copy(alpha = barAlpha), topLeft = Offset(q.x - (if (mini) 1.5f else 4f), q.y),
                    size = androidx.compose.ui.geometry.Size(if (mini) 3f else 8f, pb - q.y))
            }
            for (r in 1 until 4) for (q in pts) {
                val gx = q.x + sp2 * r
                if (gx < g.px0 + g.pw) {
                    val h = (pb - q.y) * fb.pow(r.toFloat())
                    drawRect(accent.copy(alpha = 0.18f * fb.pow(r + 1f)), topLeft = Offset(gx - (if (mini) 1f else 3f), pb - h),
                        size = androidx.compose.ui.geometry.Size(if (mini) 2f else 6f, h))
                }
            }

            // ---- the envelope line through the taps, from left baseline to right baseline
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(g.px0, pb)
                pts.forEach { lineTo(it.x, it.y) }
                lineTo(g.px0 + g.pw, pb)
            }
            drawPath(path, accent.copy(alpha = 0.5f + 0.5f * fb), style = Stroke(width = if (mini) 1.4f else 2f))

            // ---- moving playhead dot following the line
            val u = (t * 0.28f) % 1f
            val dx = g.px0 + u * g.pw
            var dy = pb
            for (k in 0..pts.size) {
                val a = if (k == 0) Offset(g.px0, pb) else pts[k - 1]
                val b = if (k < pts.size) pts[k] else Offset(g.px0 + g.pw, pb)
                if (dx >= a.x && dx <= b.x) {
                    dy = a.y + (b.y - a.y) * (dx - a.x) / maxOf(1f, b.x - a.x)
                    break
                }
            }
            val dr = if (mini) 6f else 14f
            drawCircle(
                androidx.compose.ui.graphics.Brush.radialGradient(
                    colorStops = arrayOf(0f to Color.White, 0.3f to accent, 1f to Color.Transparent),
                    center = Offset(dx, dy), radius = dr),
                radius = dr, center = Offset(dx, dy),
            )

            // ---- tap nodes (reconstructed; verify against the reference)
            for (n in 0 until 4) {
                val p = Offset(g.px0 + v[2 * n] * g.pw, pb - v[2 * n + 1] * g.ph)
                val r = if (mini) 3.4f else 9f
                drawCircle(
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        colorStops = arrayOf(0f to hex("#FFF0C8"), 0.5f to hex("#C9A45C"), 1f to hex("#6B4E22")),
                        center = Offset(p.x - r * 0.3f, p.y - r * 0.3f), radius = r),
                    radius = r, center = p,
                )
            }
        }
    }
}
