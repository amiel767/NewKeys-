# Amp et Echo · scènes Kotlin (méthode + test)

## Fichiers
- `FxSceneKit.kt` : helpers (`panelSpace`, `fillRr`, `radial`, `linear`, `hex`, `alpha`).
- `FxSceneAmp.kt` : scène Amp, portée ligne à ligne de `amp()` (fenêtre-référence).
- `FxSceneEcho.kt` : scène Echo, portée de `echo()` ; la partie des nœuds est reconstruite (voir ci-dessous).

## Méthode (à respecter)
1. **Coordonnées** : toutes les coordonnées sont celles du repère logique du panneau (825 × 343), identiques à la référence. `panelSpace {}` met le dessin à l'échelle du panneau réel. Aucune constante en pixels.
2. **Plein panneau** : la scène occupe TOUT le panneau (comme la référence), pas seulement le cadre de contenu. La coque `FxOpenPanel` doit donc dessiner le `Canvas` de scène sur `fillMaxSize()`, derrière l'en-tête et les potards. (Modification à faire dans la coque, à valider à la compilation.)
3. **Ordre** : fond → lueurs → cadre/tubes → cône → micro, comme dans la référence. Ne pas réordonner.
4. **Temps** : `t` vient de `rememberFxClock`. Un changement de preset ne remet jamais `t` à zéro.
5. **Mini (carte)** : même dessin, `mini = true` réduit les épaisseurs et les rayons, sans texte.
6. **Pas de flou** : `shadowBlur` n'existe pas en Canvas Compose. Les halos sont des dégradés radiaux transparents, ce qui donne un rendu proche mais pas identique.

## Ce qui est exact
- Amp : fond, lueur de chaleur, bande à tubes et ses trois lampes, grille du cabinet (70 + 22 traits, clip), cône qui respire, trois anneaux, position du micro, courbe du micro. Valeurs copiées de `amp()`.
- Echo : bobine (six lobes, rotation), panneau d'historique et sa grille, barres et répétitions, ligne d'enveloppe, tête de lecture. Valeurs copiées de `echo()`.

## Ce qui est reconstruit ou approché (à vérifier)
- **Echo, nœuds** : la fin de `echo()` n'était pas lisible en entier. Les nœuds sont reconstruits à partir de la capture (dégradé doré). Vérifie-les contre `ref-01-echo.png`.
- **Amp, micro** : le contour du micro (anneau strié) est simplifié : un disque dégradé. Le détail de la grille de micro n'est pas porté.
- **Halos** : remplacés par des dégradés transparents (pas de `shadowBlur`).
- **Polices** : le texte des scènes (tags MIC, valeurs) n'est pas dessiné ici, il est laissé à la coque.

## Test (à faire après compilation)
1. Compiler. Rapporter les erreurs exactes.
2. Panneau Amp et Echo, preset par défaut, capture à la taille de la référence.
3. `compare_refs.py` contre `references/ref-10-amp.png` et `references/ref-01-echo.png`.
4. Zones animées : vérifier qu'elles changent entre deux instants (lampes, cône, bobine, tête de lecture).
5. Seuil : 1,5 % de pixels hors tolérance. Au-delà, rapport détaillé par zone, pas de correction à l'aveugle.

## Limite honnête
Je n'ai pas pu compiler ni capturer le rendu Compose. Le code suit la référence, mais la fidélité réelle se mesure par le test ci-dessus.
