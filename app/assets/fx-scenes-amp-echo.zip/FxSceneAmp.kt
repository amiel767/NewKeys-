package com.aetherkeys.fx.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.roundToInt

/**
 * Aether Amp scene. Port of amp(x,W,H,v,a,t,m) from fx-window-preview.html.
 * params: 0 gain, 1 bass, 2 mid, 3 treble, 4 presence, 5 master, 6 channel(0..1 -> 0,1,2),
 *         7 mic position, 8 mic distance, 9 boost(>0.5), 10 tremolo, 11 level.
 * [t] seconds. [mini]: rack card, same drawing, no text.
 */
object FxSceneAmp {
    fun DrawScope.draw(v: FloatArray, t: Float, mini: Boolean) {
        val gain = v[0]
        val ch = (v[6] * 2f).roundToInt()
        val boost = v[9] > 0.5f
        val lvl = v[11]
        val mpos = v[7]
        val mdist = v[8]
        val heat = min(1f, gain * (0.55f + 0.3f * ch) + (if (boost) 0.2f else 0f))

        panelSpace {
            // background: vertical dark brown gradient over the whole panel
            drawRect(linear(0f, 0f, 0f, FxSceneKit.H, 0f to hex("#1A1410"), 1f to hex("#07050A")))
            // heat glow from the top centre
            drawRect(radial(400f, 60f, 420f, 0f to Color(1f, 140f / 255f, 50f / 255f, 0.1f + 0.3f * heat), 1f to Color.Transparent))

            // tube bar (top strip) with the three lamp housings
            drawRoundRect(
                brush = linear(0f, 4f, 0f, 126f, 0f to hex("#2A2622"), 0.5f to hex("#16130F"), 1f to hex("#0C0A08")),
                topLeft = Offset(24f, 36f), size = androidx.compose.ui.geometry.Size(764f, 92f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f),
            )
            drawRoundRect(
                color = hex("#C9A45C"), topLeft = Offset(24f, 36f), size = androidx.compose.ui.geometry.Size(764f, 92f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f), style = Stroke(width = 1.5f),
            )
            // faint horizontal scanlines inside the bar (reference: 22 lines, 4 px apart, alpha .06)
            for (k in 0 until 22) {
                drawLine(Color.White.copy(alpha = 0.06f), Offset(30f, 40f + k * 4f), Offset(780f, 40f + k * 4f), strokeWidth = 1f)
            }

            // lamps: three glowing tubes at x = 560, 612, 664
            listOf(560f, 612f, 664f).forEachIndexed { k, tx ->
                val f = 0.35f + 0.65f * heat * (0.85f + 0.15f * sin(t * 9f + k * 2f))
                val red = (255 - (60f * heat).toInt()).coerceIn(0, 255)
                drawCircle(
                    radial(tx, 86f, 26f, 0f to Color(red / 255f, 180f / 255f, 70f / 255f, f), 1f to Color.Transparent),
                    radius = 26f, center = Offset(tx, 86f),
                )
                fillRr(tx - 11f, 52f, 22f, 56f, 11f, hex("#0A0806"))
                drawRoundRect(
                    color = Color.White.copy(alpha = 0.19f), topLeft = Offset(tx - 11f, 52f),
                    size = androidx.compose.ui.geometry.Size(22f, 56f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(11f, 11f),
                    style = Stroke(width = 1f),
                )
                fillRr(tx - 2.5f, 64f, 5f, 36f, 2.5f, Color(1f, 200f / 255f, 120f / 255f, 0.4f + 0.6f * f))
            }

            // cabinet: grille panel 170..650 x 138..288, clipped, with grid lines
            val cabTop = 138f
            val cabBot = 288f
            drawRoundRect(
                brush = linear(0f, 138f, 0f, 284f, 0f to hex("#2A1D12"), 1f to hex("#120B06")),
                topLeft = Offset(170f, cabTop), size = androidx.compose.ui.geometry.Size(480f, cabBot - cabTop),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f),
            )
            drawRoundRect(
                color = hex("#C9A45C").copy(alpha = 0.53f), topLeft = Offset(170f, cabTop),
                size = androidx.compose.ui.geometry.Size(480f, cabBot - cabTop),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f), style = Stroke(width = 2f),
            )
            clipRect(182f, 148f, 182f + 456f, 148f + 130f) {
                drawRect(hex("#0C0907"), topLeft = Offset(170f, cabTop), size = androidx.compose.ui.geometry.Size(480f, 150f))
                for (k in 0 until 70) drawLine(hex("#8A7A5A").copy(alpha = 0.25f), Offset(170f + k * 7f, 138f), Offset(170f + k * 7f, 288f), strokeWidth = 1f)
                for (k in 0 until 22) drawLine(hex("#8A7A5A").copy(alpha = 0.25f), Offset(170f, 138f + k * 7f), Offset(650f, 138f + k * 7f), strokeWidth = 1f)

                // speaker: cone with pump (breathes with level and heat)
                val cx = 410f
                val cy = 212f
                val pump = 1f + 0.04f * sin(t * 50f) * (0.3f + lvl * 0.7f) * (0.4f + heat)
                drawCircle(hex("#0A0A0C"), radius = 66f, center = Offset(cx, cy))
                drawCircle(hex("#44444A"), radius = 60f, center = Offset(cx, cy), style = Stroke(width = 5f))
                drawCircle(
                    radial(cx, cy, 50f * pump, 0f to hex("#3A3A40"), 0.35f to hex("#1C1C20"), 1f to hex("#060608")),
                    radius = 50f * pump, center = Offset(cx, cy),
                )
                drawCircle(hex("#16161A"), radius = 13f * pump, center = Offset(cx, cy))
                // three rings expanding from the cone while the amp is hot
                for (k in 0 until 3) {
                    val u = ((t * 0.8f + k / 3f) % 1f)
                    drawCircle(
                        Color(1f, 154f / 255f, 60f / 255f, (1f - u) * 0.25f * (0.3f + heat)),
                        radius = 18f + u * 34f, center = Offset(cx, cy), style = Stroke(width = 1.5f),
                    )
                }
            }

            // mic lead: a curve from the mic to the right edge; mic drawn at its position
            val mx = 340f + mpos * 140f
            val my = 150f + mdist * 90f
            drawLine(Color.White.copy(alpha = 0.25f), Offset(mx, my), Offset(720f, 170f), strokeWidth = 1.2f)
            drawCircle(radial(mx, my, 10f, 0f to hex("#AEB6C0"), 1f to hex("#2A2E34")), radius = 10f, center = Offset(mx, my))
        }
    }
}
