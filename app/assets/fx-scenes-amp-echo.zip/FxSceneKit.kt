package com.aetherkeys.fx.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform

/**
 * Shared drawing kit for scenes. Coordinates are the reference's LOGICAL panel coordinates (825 x 343).
 * Every scene draws over the WHOLE panel (the reference does too), so [panelSpace] maps the full panel.
 */
object FxSceneKit {
    const val W = FxGeom.LOGICAL_W
    const val H = FxGeom.LOGICAL_H
}

/** Runs [block] in logical panel coordinates. Non-uniform is avoided: sx and sy are equal in practice (825:343). */
inline fun DrawScope.panelSpace(block: DrawScope.() -> Unit) {
    val sx = size.width / FxSceneKit.W
    val sy = size.height / FxSceneKit.H
    withTransform({ scale(sx, sy, pivot = Offset.Zero) }) { block() }
}

/** Rounded rectangle in logical coordinates, matching the reference's rr2(x, a, b, w, h, r). */
fun DrawScope.fillRr(x: Float, y: Float, w: Float, h: Float, r: Float, color: Color) {
    drawRoundRect(color = color, topLeft = Offset(x, y), size = androidx.compose.ui.geometry.Size(w, h),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r))
}

fun radial(cx: Float, cy: Float, r: Float, vararg stops: Pair<Float, Color>): Brush =
    Brush.radialGradient(colorStops = stops, center = Offset(cx, cy), radius = r)

fun linear(x0: Float, y0: Float, x1: Float, y1: Float, vararg stops: Pair<Float, Color>): Brush =
    Brush.linearGradient(colorStops = stops, start = Offset(x0, y0), end = Offset(x1, y1))

fun hex(s: String): Color = Color(android.graphics.Color.parseColor(s))
fun alpha(c: Color, a: Float): Color = c.copy(alpha = a.coerceIn(0f, 1f))
