# Æther Instruments · Organ + Synth (Kotlin / Compose)

Package `com.aetherkeys.instruments`. Reproduit l'aperçu validé : onglet « Æther Instruments », cartes avec mini-previews centrées,
fenêtre d'instrument (Organ, Synth 3 pages), presets (22 + 28), MIDI, état conservé, déchargement.

## Fichiers (à copier tels quels, dossier à plat)
| Fichier | Rôle |
|---|---|
| `AeCore.kt` | `AeInstrument`, `AeHost` (interface moteur), `AeSession`, `AeManager` (état app, MIDI, presets) |
| `AeStage.kt` | scène 1000×460 mise à l'échelle uniforme, rendu SVG au pixel exact, polices, bois |
| `AeSvgAssets.kt` + `svg/*.svg` | éléments SVG isolés : 3 capuchons de tirette, rail, potard métal, potard verre, 2 mini-previews |
| `AeControls.kt` | potards, tirettes, chips, bascules, clavier multi-touch |
| `AeDraw.kt` | dessins animés : roues phoniques, rotor, sphère, filtre, enveloppe, ondes, LFO |
| `AeOrganUi.kt`, `AeSynthUi.kt` | les deux écrans, positions de l'aperçu |
| `AeWindow.kt` | fenêtre d'instrument, liste de presets, onglet + cartes |
| `AePresets.kt` + `presets-organ-synth.json` | presets (valeurs 0..1, ordre du registre : orgue 31, synth 32) |

## Dépendance (une seule)
`implementation("com.caverock:androidsvg-aar:1.4")` · Compose runtime ≥ 1.5 (`mutableIntStateOf`).

## Branchement (3 étapes)
1. **Polices** (une fois, au démarrage) : `AeFonts.plate = Cinzel`, `AeFonts.mono = Share Tech Mono`, `AeFonts.display = Sora`, `AeFonts.ui = Plus Jakarta Sans`. Sans cela : polices système (la mise en page reste juste, le rendu des lettres change).
2. **Hôte moteur** : implémenter `AeHost` en appelant `FxMixer` (déjà dans le C++) :
   `loadInstrument` → `setInstrument(strip, fxId)` · `unloadInstrument` → `setInstrument(strip, -1)` · `setParam` → `setInstrumentParam(strip, index, norm)` ·
   `noteOn/noteOff/allNotesOff` → mêmes noms sur `FxMixer`. Tout appel doit être posté vers le thread audio côté JNI.
   Puis, une seule fois : `val ae = AeManager(host, appScope)`.
3. **MIDI** : dans le répartiteur MIDI existant, avant d'envoyer à FluidSynth :
   `if (ae.onMidiNoteOn(ch, note, vel)) return` · `ae.onMidiNoteOff(ch, note)` · `ae.onMidiCc(ch, cc, value)` (CC64 = sustain, CC74/71/73/72/1/91/7 mappés, table modifiable `ae.ccOrgan` / `ae.ccSynth`).
   Canal n = piste n. Ids de paramètres pour MIDI Learn : `strip` + `index` (0..30 orgue, 0..31 synth).

## Intégration dans `SoundfontWindow.kt` (voir `PATCH-SoundfontWindow.md`)

## Comportement demandé
- Choisir une carte **charge et démarre** l'instrument immédiatement (`AeManager.load`), puis ouvre la fenêtre.
- **Quitter (✕)** garde l'instrument chargé et tous ses réglages ; rouvrir affiche l'interface laissée.
- **Décharger** : bouton « Unload » sur la carte, ou dans la liste de presets de la fenêtre.
- Les animations tournent seulement fenêtre ouverte (30 i/s en jeu, ~12 au repos) ; fermées = 0 CPU d'interface.

## NON vérifié (à contrôler dès la première compilation)
- **Rien n'a été compilé** (pas de Kotlin ni d'Android ici). Relecture et équilibrage des accolades faits ; attendre quelques erreurs d'import ou de signature.
- **Rien n'a été comparé pixel à pixel** : les positions sont celles de l'aperçu, mais le rendu réel est à confronter à `preview-aether-instruments.html` (`compare_refs.py` du paquet spec).
- Les 8 SVG ont été rendus et contrôlés sur fond clair et sombre ; ils n'ont pas été rendus par AndroidSVG lui-même (donc : si un dégradé manque, regarder d'abord le rendu AndroidSVG).
- Écarts connus : la lueur « shadowBlur » du navigateur est remplacée par des traits translucides superposés ; le dégradé de la sphère est à un seul cercle (l'aperçu en utilisait deux).
- Le niveau sonore animé vient de `AeHost.level()` ; sans mesure côté moteur, la sphère réagit aux touches tenues.
