# Patch `SoundfontWindow.kt` (5 modifications, ancres sur ton code)

1. **Signature** de `SoundfontWindow(...)` : ajouter `aether: AeManager? = null, aetherStrip: Int = 0`.
2. **États** (près de `var tab by remember …`, ligne ~296) :
   `var aetherTab by remember { mutableStateOf(false) }` · `var aetherOpen by remember { mutableStateOf(false) }`
   L'onglet n'existe que pour `state.variant == SoundfontVariant.Track` (pas pour Pad ni Drum).
3. **Colonne gauche** `SfLeftColumn` (ligne ~725) : ajouter `aetherOn: Boolean, onAether: (() -> Unit)?` ; juste après le `Spacer(Modifier.height(10.dp))` qui suit `SfTabStrip` :
   `if (onAether != null) { AeInstrumentsTabItem(selected = aetherOn, onClick = onAether); Spacer(Modifier.height(10.dp)) }`
   À l'appel (ligne ~463) : `aetherOn = aetherTab, onAether = if (aether != null && state.variant == SoundfontVariant.Track) ({ aetherTab = true }) else null`
   et dans le `onTabChange = { t -> … }` existant, ajouter `aetherTab = false`.
4. **Contenu de droite** : là où le panneau affiche la liste (SfList / grille), envelopper :
   `if (aetherTab && aether != null) AeInstrumentsTabContent(aether, aetherStrip, onOpen = { aetherOpen = true }, modifier = <même modifier que la liste>) else { <contenu existant> }`
5. **Fenêtre agrandie + ✕** : dans le `Box` racine, en frère du panneau (après le bloc `PanelShape`) :
   ```kotlin
   if (aetherOpen && aether != null) Box(Modifier.fillMaxSize().background(Color(0xCC05070D)), contentAlignment = Alignment.Center) {
       AeInstrumentWindow(aether, aetherStrip, onClose = { aetherOpen = false },
           modifier = Modifier.fillMaxWidth(0.97f).aspectRatio(AE_W / AE_H))
   }
   ```
Vérifier que `aetherStrip` reçoit bien l'index de la piste dont la fenêtre est ouverte (0..7).
