# Æther Instruments · Organ, Synth, Leads, Sax (Kotlin / Compose) — paquet final

Package `com.aetherkeys.instruments`. Quatre instruments dans l'onglet « Æther Instruments » de la fenêtre soundfonts :
cartes 2×2 avec mini-previews centrées, fenêtre d'instrument (✕ pour quitter), presets (Organ 22, Synth 28, Leads 30, Sax 23), MIDI, état conservé, déchargement.

## Contenu
| Élément | Rôle |
|---|---|
| `AeCore.kt` | `AeInstrument` (ORGAN 6, SYNTH 14, **LEADS 15, SAX 16**), `AeHost`, `AeSession`, `AeManager` (état, presets, MIDI) |
| `AeStage.kt` | scène 1000×460 à l'échelle uniforme, rendu SVG au pixel exact, polices, bois |
| `AeControls.kt` | potards (palettes violet / cyan / ambre), tirettes, chips, bascules, clavier multi-touch |
| `AeDraw.kt`, `AeDrawLeads.kt` | dessins animés (Organ, Synth, Leads) |
| `AeOrganUi.kt`, `AeSynthUi.kt`, `AeLeadsUi.kt`, `AeSaxUi.kt` | les quatre écrans, positions des aperçus validés |
| `AeWindow.kt` | fenêtre d'instrument, liste de presets, onglet + 4 cartes |
| `AeSaxAssets.kt` | chargement des photos du sax + géométrie (perles, pavillon) mesurée sur chaque photo |
| `AeSvgAssets.kt` + `svg/` | 13 SVG isolés (capuchons, rail, potards, faders, mini-previews) |
| `res/drawable-nodpi/` | **12 images WebP** du sax : soprano, alto, baryton × or, noir, argent, cuivre (fond retiré, retouchées) |
| `AePresets.kt` + 2 JSON | presets, valeurs 0..1, ordre du registre (Organ 31, Synth 32, Leads 32, Sax 21) |
| `preview-*.html` | aperçus de référence (ouvrir dans Chrome) |

## Installation
1. Copier les `.kt` dans le projet (package `com.aetherkeys.instruments`) et **`res/drawable-nodpi/*.webp` dans le dossier `res` de l'app** (les noms `ae_sax_<type>_<finition>` sont lus par nom, sans `R`).
2. Dépendances : `com.caverock:androidsvg-aar:1.4`, Compose runtime ≥ 1.5, compose-animation (déjà présent avec Compose).
3. Polices au démarrage : `AeFonts.plate` (Cinzel), `.mono` (Share Tech Mono), `.display` (Sora), `.ui` (Plus Jakarta Sans).
4. Hôte moteur : implémenter `AeHost` sur `FxMixer` (`setInstrument(strip, fxId)`, `setInstrumentParam`, `noteOn/noteOff/allNotesOff`). `val ae = AeManager(host, appScope)` une seule fois.
5. MIDI : avant FluidSynth, `if (ae.onMidiNoteOn(ch, note, vel)) return`, `ae.onMidiNoteOff(...)`, `ae.onMidiCc(...)`. Canal n = piste n. CC64 sustain ; Sax : CC2 souffle, CC11 expression, CC1 vibrato ; Leads/Synth/Organ : voir `ae.ccLeads`, `ccSynth`, `ccOrgan`.
6. Fenêtre soundfonts : appliquer `PATCH-SoundfontWindow.md`.

## Comportement
Choisir une carte **charge et démarre** l'instrument (`AeManager.load`) puis ouvre la fenêtre. ✕ garde l'instrument et ses réglages. « Unload » (carte ou liste de presets) le décharge. Animations : seulement fenêtre ouverte (30 i/s en jeu, ~12 au repos).

## Sax : photos
Le sax est la photo fournie (détourée, retouchée), recolorée par finition avec fondu de 450 ms. Les perles s'allument selon la hauteur de la note, un reflet balaie le métal, un souffle chaud sort du pavillon avec le niveau.
Ténor : **réutilise la photo de l'alto** (pas de photo de ténor fournie). Envoyer une photo pour la remplacer (ajouter `ae_sax_tenor_*` et passer `files[2]` à `"tenor"`).
La finition « or » de l'alto et la finition « noir » de l'alto sont recolorées à partir de la photo noir/or ; or/argent/cuivre sont des recolorations par carte de dégradé, pas des photos différentes.

## À savoir AVANT de compiler / tester
- **Le moteur audio de Leads (fxId 15) et de Sax (fxId 16) n'existe pas encore en C++** : tant que `loadInstrument` renvoie `false`, `AeManager.load` renvoie `null` et la carte ne s'ouvre pas. Pour tester l'interface seule, fournir un `AeHost` factice qui renvoie `true`. Le DSP (Leads : 32 paramètres ; Sax : 21) reste à écrire.
- **Rien n'a été compilé** (pas de Kotlin/Android ici) : relecture et équilibre des accolades faits ; attendre quelques erreurs d'import ou de signature.
- **Aucune comparaison pixel à pixel** du rendu Compose avec les aperçus.
- Oscilloscope des Leads : trace synthétique (calculée depuis les niveaux des couches). Les vrais échantillons sont un paramètre optionnel de `AeLeadsUi(samples)` et `AeHost.scope(...)`, **non branchés** pour l'instant.
- Doigté du sax : visuel approximatif (plus la note est grave, plus de perles allumées), pas un doigté exact. Les positions des perles ont été relevées sur les photos.
- SVG validés dans un navigateur, pas dans AndroidSVG.
