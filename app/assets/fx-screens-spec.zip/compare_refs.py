"""Compare a Compose capture with its reference PNG.
usage: python3 compare_refs.py capture.png references/ref-00-space.png
Exit code 0 = PASS (<= 1.5 % of pixels differ by more than 24/255 on any channel).
Capture must be the same logical size as the reference (rendered at 2x)."""
import sys
from PIL import Image, ImageChops
cap, ref = Image.open(sys.argv[1]).convert('RGB'), Image.open(sys.argv[2]).convert('RGB')
if cap.size != ref.size:
    print(f'FAIL size {cap.size} != reference {ref.size}'); sys.exit(1)
d = ImageChops.difference(cap, ref).split()
bad = [0] * (cap.size[0] * cap.size[1])
mask = Image.new('L', cap.size, 0)
for ch in d:
    m = ch.point(lambda v: 255 if v > 24 else 0)
    mask = ImageChops.lighter(mask, m)
n = sum(1 for v in mask.getdata() if v)
pct = 100.0 * n / (cap.size[0] * cap.size[1])
ok = pct <= 1.5
print(f"{'PASS' if ok else 'FAIL'} · écart = {pct:.2f} %")
sys.exit(0 if ok else 1)
