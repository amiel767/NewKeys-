# Fenêtre FX · Spécification exacte pour l'implémentation (ordre strict)

Objectif : la fenêtre Compose doit être **identique** à la référence, pixel près. Aucune interprétation.

## Sources, par ordre d'autorité
1. `reference_source_fx_window.html` : le code de référence. Ouvre-le dans un navigateur pour le voir. Toute valeur (couleur, rayon, position, durée) se lit dedans.
2. `fx_layout_spec.json` : mesures extraites de la référence, par effet (boîte de chaque potard, bouton, zone de scène, en pixels logiques, origine = coin du panneau d'effet).
3. `references/ref-NN-*.png` : rendu à 2× du preset par défaut. `references/ref-NN-*-presets.png` : tous les presets. `references/ref-tablet-*.png` : tablette.

Si une source contredit une autre, la source 1 gagne. Signale la contradiction, ne choisis pas.

## Règles de travail
- Aucune valeur « arrondie à l'œil ». Copie les nombres du JSON.
- Aucun écran ajouté, retiré ou simplifié. Chaque élément visible dans la référence doit exister dans l'app.
- Chaque effet est une étape. Une étape n'est terminée que si le test de la section « Comparaison » passe.
- Pas de « presque ». Un écart au-delà du seuil = étape non terminée.

## Ordre d'implémentation
1. Le cadre commun : panneau, en-tête (titre, compteur, boutons), zone de contenu, bandeau LEVEL. Mêmes dimensions que la référence.
2. Les composants communs : potard (sprite mis en cache), bouton de preset, bouton Bypass, bouton A/B, bouton Surprise me.
3. Un effet par étape, dans l'ordre : Ampli (10), Maximizer (4), puis les autres. Ne passe pas au suivant tant que le précédent n'est pas validé.

## Comparaison (obligatoire à chaque effet)
- Capture de l'écran Compose à la même taille logique que la référence, rendu à 2×.
- Superposition avec `references/ref-NN-*.png` via `compare_refs.py` (fourni).
- Seuil : au plus 1,5 % de pixels qui diffèrent de plus de 24/255 sur les 3 canaux, hors zones animées (les scènes sont comparées à l'image fixe de t = 0).
- Les zones animées ne sont pas comparées pixel à pixel ; elles sont vérifiées par un test de mouvement (la zone change entre deux instants).
- Rapport : `Effet N : PASS/FAIL · écart = X % · zones hors seuil = [...]`.

## Branchement (à vérifier séparément, pas dans le rendu)
Pour chaque potard : une valeur envoyée produit un changement attendu côté natif (journal + mesure). Pour chaque preset : tous les paramètres changent. Pour Bypass : le signal change.

## Ce qui n'est PAS dans fx_layout_spec.json
Les contrôles dessinés dans la scène (ex. les tirettes de l'orgue, les pistes du synthé, les micros de l'ampli) sont des zones définies dans le code de référence (tableaux `HS` et `AB`, fonctions `draw…`). Elles se lisent dans `reference_source_fx_window.html`. Ne les réinvente pas.
