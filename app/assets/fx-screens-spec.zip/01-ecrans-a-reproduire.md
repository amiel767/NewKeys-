# Liste des écrans à reproduire (une ligne par effet)

| Id | Effet | Potards (DOM) | Presets | Référence PNG |
|---|---|---|---|---|
| 0 | Æther Space | 7 | Hall, Plate, Room, Cathedral, Shimmer, Chamber, Bloom, Infinite | ref-00-*.png |
| 1 | Æther Echo | 4 | Dotted, Tape, Ping-pong, Slap, Ambient, Dub, Doubler, Pulse | ref-01-*.png |
| 2 | Prism Tone | 4 | Air, Warm, Vocal, Presence, Telephone, Smile, Flat, Black Box | ref-02-*.png |
| 3 | Iron Grip | 5 | Glue, Gentle, Punch, Limit, Vocal Leveler, Drum Bus, Parallel | ref-03-*.png |
| 4 | Solar Ceiling | 6 | Transparent, Loud, Punch, Wide, Master Glue, Warm Tape, Radio | ref-04-*.png |
| 5 | Aether Piano | 3 | Felt, Studio, Upright, Concert, Mellow, Bright | ref-05-*.png |
| 6 | Aether Organ | 4 | Gospel, Full, Jazz, Rock, Balanced, Whisper | ref-06-*.png |
| 7 | Aether Sax | 3 | Smooth, Breathy, Growl, Club, Bright, Subtone | ref-07-*.png |
| 8 | Aether Strings | 9 | Solo, Chamber, Orchestra, Cinematic, Warm, Bright | ref-08-*.png |
| 9 | Aether Guitar | 3 | Acoustic, Nylon, Clean, Crunch, Lead, Ambient | ref-09-*.png |
| 10 | Aether Amp | 7 | Clean, Crunch, Lead, Blues, Jazz, Metal | ref-10-*.png |
| 11 | Aether Bass | 4 | Motown, Rock, Slap, Fuzz, Dub, Clean DI | ref-11-*.png |
| 12 | Aether Brass | 3 | Open, Muted Jazz, Section Stab, Fanfare, Soft, Harmon | ref-12-*.png |
| 13 | Aether Voices | 6 | Ah, Ooh, Eeh, Ensemble, Whisper, Angels | ref-13-*.png |
| 14 | Aether Synth | 21 | Pad, Lead, Bass, Pluck, Keys, FX | ref-14-*.png |

Les contrôles dessinés dans la scène (tirettes, pistes, micros, pads) ne sont pas dans les potards DOM : ils sont dans le code de référence (HS/AB).
