# OrganUI – petit guide puzzle (AetherLab)

Référence : smartphone standard 360×800 dp utilisé en **paysage = 800×360 dp** (layout large comme l'original).

## Installation (4 étapes)
1. Copie `app/src/main/java/com/aetherlab/organ/ui/` dans ton projet (adapte `package` si besoin).
2. Copie `res/values/organ_colors.xml` et `organ_dimens.xml` (optionnels : les couleurs Kotlin sont déjà dans `WoodPalette`).
3. Dépendances : Compose BOM + `material3` + `ui-tooling-preview`.
4. Utilise l'écran :
```kotlin
var s by remember { mutableStateOf(OrganUiState()) }
OrganScreen(
    state = s, onStateChange = { s = it },
    onPrevPreset = { /* ton moteur */ }, onNextPreset = { /* ... */ },
    onOpenPresets = { /* ouvrir ta liste de presets */ },
    drawbarSlot = { MesDrawbars() }          // ton Drawbar vient ici
)
```

## Les pièces (chacune isolée)
| Fichier | Contenu |
|---|---|
| `WoodPalette.kt` | toutes les couleurs bois/gris |
| `WoodPanel.kt` | `WoodBackground` (fond) + `WoodCard` (case, en-tête, LED on/off) |
| `Knob3D.kt` | knob 3D : sans `scaleLabels` = style Pure Verb (arc ambre) ; avec = style Organ (0..10, dB) |
| `OrganButton.kt` | `OrganButton`, `LedButton` (LED+texte+bouton), `LedOption` (radio LED) |
| `Led.kt` | LED seule (couleur, taille) |
| `PresetDisplay.kt` | `< nom du preset >` (remplace Programs) |
| `OctaveSelector.kt` | `OCT − +1 +` (remplace Key Range) |
| `VibratoSelector.kt` | grille V1–V3 / C1–C3 |
| `OrganScreen.kt` | assemble tout ; `OrganUiState` contient tous les états |

## Moduler les cases
Dans `OrganScreen.kt` : `weight(...)` règle la taille relative, `height(...)` une taille fixe. Pour ajouter/retirer une case, ajoute/supprime un `WoodCard(...) { ... }` dans la colonne voulue. Le contenu d'une case est centré avec espacement égal.

## Notes
- Interaction knob : glisser verticalement ; `steps = 10` pour valeurs discrètes.
- Retirés : pedal bend, sustain, transpose, Learn MIDI CC.
- `jsx/OrganPreview.jsx` = aperçu interactif du même design (mêmes couleurs et proportions).
