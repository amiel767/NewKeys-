package com.aetherlab.organ.ui.theme

import androidx.compose.ui.graphics.Color

/** Palette bois + gris chauds. Miroir de res/values/organ_colors.xml */
object WoodPalette {
    val WoodDeep = Color(0xFF24130A)
    val WoodDark = Color(0xFF3E2210)
    val WoodMid = Color(0xFF6B3F1D)
    val WoodLight = Color(0xFF93612E)
    val WoodGrain = Color(0xFF2A150A)

    val CardTop = Color(0xFF4A413B)
    val CardBottom = Color(0xFF362F2B)
    val CardBorder = Color(0xFF1C1411)
    val HeaderTop = Color(0xFFCDBBA5)
    val HeaderBottom = Color(0xFF9F8D79)
    val HeaderText = Color(0xFF2A1A10)

    val TextMain = Color(0xFFF2E6D6)
    val TextMuted = Color(0xFFB9A892)
    val Amber = Color(0xFFFFB04A)
    val AmberGlow = Color(0xFFFF8A1F)
    val LedGreen = Color(0xFF6BFF8A)
    val LedRed = Color(0xFFFF4B3A)

    val KnobLight = Color(0xFF8A817A)
    val KnobMid = Color(0xFF4E4741)
    val KnobDark = Color(0xFF1F1B18)
    val Track = Color(0xFF17120F)

    val DisplayBg = Color(0xFF120B07)
    val ButtonTop = Color(0xFF3A3532)
    val ButtonBottom = Color(0xFF0E0C0B)
}
