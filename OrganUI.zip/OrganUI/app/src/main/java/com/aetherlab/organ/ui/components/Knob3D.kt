package com.aetherlab.organ.ui.components

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aetherlab.organ.ui.theme.WoodPalette as P
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private const val START = 135f
private const val SWEEP = 270f

/**
 * Knob 3D réutilisable.
 * - scaleLabels vide  -> style "Pure Verb" : arc de progression ambre autour du knob.
 * - scaleLabels rempli -> style "Organ" : graduations + chiffres autour (0..10, -15dB..15dB).
 * - value 0f..1f ; steps > 0 = valeurs discrètes. Glisser verticalement pour tourner.
 */
@Composable
fun Knob3D(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 52.dp,
    label: String? = null,
    valueText: String? = null,
    scaleLabels: List<String> = emptyList(),
    steps: Int = 0,
    accent: Color = P.Amber,
) {
    val current by rememberUpdatedState(value)
    val callback by rememberUpdatedState(onValueChange)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier
                .size(size)
                .pointerInput(steps) {
                    var acc = 0f
                    detectDragGestures(onDragStart = { acc = current }) { change, drag ->
                        change.consume()
                        acc = (acc - drag.y / 220f + drag.x / 440f).coerceIn(0f, 1f)
                        callback(if (steps > 0) (acc * steps).roundToInt() / steps.toFloat() else acc)
                    }
                }
        ) { drawKnob(value, scaleLabels, accent) }
        if (label != null) Text(label.uppercase(), color = P.TextMuted, fontSize = 7.sp)
        if (valueText != null) Text(valueText, color = P.Amber, fontSize = 8.sp)
    }
}

private fun DrawScope.drawKnob(value: Float, scale: List<String>, accent: Color) {
    val r = size.minDimension / 2f
    val c = center
    val hasScale = scale.isNotEmpty()
    val bodyR = if (hasScale) r * 0.56f else r * 0.70f

    if (!hasScale) {
        val arcR = r * 0.90f
        val stroke = r * 0.09f
        val tl = Offset(c.x - arcR, c.y - arcR)
        val sz = Size(arcR * 2, arcR * 2)
        drawArc(P.Track, START, SWEEP, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
        drawArc(accent, START, SWEEP * value, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
    } else {
        val n = scale.size
        val paint = Paint().apply {
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            color = android.graphics.Color.rgb(0xF2, 0xE6, 0xD6)
            textSize = r * 0.24f
            typeface = Typeface.DEFAULT_BOLD
        }
        for (i in 0 until n) {
            val a = Math.toRadians((START + SWEEP * i / (n - 1)).toDouble())
            val d = Offset(cos(a).toFloat(), sin(a).toFloat())
            drawLine(P.TextMuted, c + d * (r * 0.66f), c + d * (r * 0.74f), strokeWidth = r * 0.04f)
            val tp = c + d * (r * 0.90f)
            drawContext.canvas.nativeCanvas.drawText(scale[i], tp.x, tp.y + paint.textSize * 0.35f, paint)
        }
    }

    // Ombre portée
    drawCircle(Color.Black.copy(0.35f), bodyR * 1.06f, c + Offset(0f, bodyR * 0.14f))
    drawCircle(Color.Black.copy(0.22f), bodyR * 1.14f, c + Offset(0f, bodyR * 0.20f))
    // Anneau métallique
    drawCircle(
        Brush.verticalGradient(listOf(P.KnobLight, P.KnobDark), startY = c.y - bodyR, endY = c.y + bodyR),
        bodyR, c,
    )
    // Cannelures de grip sur l'anneau
    val faceR = bodyR * 0.84f
    for (i in 0 until 28) {
        val a = Math.toRadians(i * 360.0 / 28)
        val d = Offset(cos(a).toFloat(), sin(a).toFloat())
        drawLine(Color.Black.copy(0.28f), c + d * (faceR * 1.02f), c + d * (bodyR * 0.98f), strokeWidth = r * 0.025f)
    }
    // Face en dôme
    drawCircle(
        Brush.radialGradient(
            listOf(P.KnobLight, P.KnobMid, P.KnobDark),
            center = c + Offset(-faceR * 0.35f, -faceR * 0.40f),
            radius = faceR * 1.7f,
        ),
        faceR, c,
    )
    // Reflet spéculaire
    val ow = faceR * 1.2f
    val oh = faceR * 0.7f
    val otl = c + Offset(-faceR * 0.6f, -faceR * 0.85f)
    drawOval(
        Brush.verticalGradient(listOf(Color.White.copy(0.35f), Color.Transparent), startY = otl.y, endY = otl.y + oh),
        topLeft = otl, size = Size(ow, oh),
    )
    // Repère lumineux
    val a = Math.toRadians((START + SWEEP * value).toDouble())
    val dir = Offset(cos(a).toFloat(), sin(a).toFloat())
    drawLine(accent.copy(0.35f), c + dir * (faceR * 0.25f), c + dir * (faceR * 0.95f), strokeWidth = r * 0.14f, cap = StrokeCap.Round)
    drawLine(Color(0xFFFFF1DA), c + dir * (faceR * 0.25f), c + dir * (faceR * 0.95f), strokeWidth = r * 0.07f, cap = StrokeCap.Round)
}
