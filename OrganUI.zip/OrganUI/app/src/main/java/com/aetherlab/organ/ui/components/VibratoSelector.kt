package com.aetherlab.organ.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Sélecteur V1..V3 / C1..C3 (index 0..5 : V1,V2,V3,C1,C2,C3). */
@Composable
fun VibratoChorusSelector(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val labels = listOf("V1", "V2", "V3", "C1", "C2", "C3")
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        for (col in 0..1) {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                for (row in 0..2) {
                    val idx = col * 3 + row
                    LedOption(labels[idx], selected == idx, { onSelect(idx) })
                }
            }
        }
    }
}
