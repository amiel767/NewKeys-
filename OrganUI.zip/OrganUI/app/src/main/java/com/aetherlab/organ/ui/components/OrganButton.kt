package com.aetherlab.organ.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aetherlab.organ.ui.theme.WoodPalette as P

/** Bouton noir bombé (état pressé = inversion du dégradé). */
@Composable
fun OrganButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = 40.dp,
    height: Dp = 20.dp,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val shape = RoundedCornerShape(height / 2.6f)
    Box(
        modifier
            .size(width, height)
            .shadow(if (pressed) 1.dp else 3.dp, shape)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    if (pressed) listOf(P.ButtonBottom, P.ButtonTop) else listOf(P.ButtonTop, P.ButtonBottom)
                )
            )
            .border(1.dp, Color.Black.copy(0.8f), shape)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth(0.84f)
                .height(height * 0.28f)
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = if (pressed) 0.06f else 0.16f))
        )
        content()
    }
}

/** LED + libellé au-dessus, bouton dessous (Speed, Cabinet, Soft, Fast, Third). */
@Composable
fun LedButton(
    label: String,
    on: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    ledColor: Color = P.LedRed,
    buttonWidth: Dp = 40.dp,
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Led(on, color = ledColor, diameter = 6.dp)
            Text(label.uppercase(), color = P.TextMain, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
        OrganButton(onToggle, width = buttonWidth, height = 16.dp)
    }
}

/** Option type radio : LED + texte (B3/PIPE/FARF, Room/Stage/Hall). */
@Composable
fun LedOption(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    ledColor: Color = P.LedRed,
) {
    Row(
        modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Led(selected, color = ledColor, diameter = 6.dp)
        Text(label, color = if (selected) P.TextMain else P.TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}
