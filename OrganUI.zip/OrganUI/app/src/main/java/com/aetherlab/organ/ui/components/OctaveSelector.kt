package com.aetherlab.organ.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aetherlab.organ.ui.theme.WoodPalette as P

/** Remplace Key Range : OCT  [-] [+1] [+] */
@Composable
fun OctaveSelector(
    octave: Int,
    onChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
    range: IntRange = -3..3,
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text("OCT", color = P.TextMain, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            OrganButton({ onChange((octave - 1).coerceIn(range.first, range.last)) }, width = 24.dp, height = 18.dp) {
                Text("−", color = P.TextMain, fontSize = 11.sp)
            }
            val shape = RoundedCornerShape(4.dp)
            Box(
                Modifier.size(34.dp, 18.dp).background(P.DisplayBg, shape).border(1.dp, Color(0xFF5A4636), shape),
                contentAlignment = Alignment.Center,
            ) {
                Text(if (octave > 0) "+$octave" else "$octave", color = P.Amber, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            OrganButton({ onChange((octave + 1).coerceIn(range.first, range.last)) }, width = 24.dp, height = 18.dp) {
                Text("+", color = P.TextMain, fontSize = 11.sp)
            }
        }
    }
}
