package com.aetherlab.organ.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aetherlab.organ.ui.theme.WoodPalette as P
import kotlin.random.Random

/** Fond bois : dégradé + veines procédurales + vignettage. Change `seed` pour une autre veine. */
@Composable
fun WoodBackground(
    modifier: Modifier = Modifier,
    seed: Int = 7,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier.drawBehind {
            drawRect(Brush.verticalGradient(listOf(P.WoodMid, P.WoodDark, P.WoodMid)))
            val rnd = Random(seed)
            repeat(70) {
                val y = rnd.nextFloat() * size.height
                val amp = rnd.nextFloat() * 6f + 1f
                val path = Path().apply {
                    moveTo(0f, y)
                    cubicTo(size.width * 0.3f, y - amp, size.width * 0.6f, y + amp, size.width, y + amp * 0.5f)
                }
                val col = if (rnd.nextBoolean()) P.WoodGrain.copy(alpha = rnd.nextFloat() * 0.25f)
                else P.WoodLight.copy(alpha = rnd.nextFloat() * 0.12f)
                drawPath(path, col, style = Stroke(rnd.nextFloat() * 2.5f + 0.5f))
            }
            drawRect(Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(0.45f)), center = center, radius = size.maxDimension * 0.7f))
        },
        content = content,
    )
}

/**
 * Case de contrôle. À toi de choisir taille/nombre : Modifier.weight(...) / height(...) depuis l'écran.
 * title = null -> pas d'en-tête. headerLed != null -> LED on/off dans l'en-tête.
 */
@Composable
fun WoodCard(
    title: String?,
    modifier: Modifier = Modifier,
    headerLed: Boolean? = null,
    onHeaderLedChange: ((Boolean) -> Unit)? = null,
    contentPadding: Dp = 6.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(8.dp)
    Column(
        modifier
            .shadow(4.dp, shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(P.CardTop, P.CardBottom)))
            .border(1.dp, P.CardBorder, shape)
    ) {
        if (title != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(18.dp)
                    .background(Brush.verticalGradient(listOf(P.HeaderTop, P.HeaderBottom)))
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                if (headerLed != null) {
                    Led(headerLed, Modifier.clickable { onHeaderLedChange?.invoke(!headerLed) }, diameter = 8.dp)
                    Spacer(Modifier.width(6.dp))
                }
                Text(title.uppercase(), color = P.HeaderText, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
            }
        }
        Column(
            Modifier.fillMaxWidth().weight(1f).padding(contentPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly,
            content = content,
        )
    }
}
