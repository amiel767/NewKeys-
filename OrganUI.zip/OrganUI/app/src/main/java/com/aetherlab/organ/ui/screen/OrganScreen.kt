package com.aetherlab.organ.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aetherlab.organ.ui.components.*
import com.aetherlab.organ.ui.theme.WoodPalette as P

data class OrganUiState(
    val presetName: String = "My Gospel B3",
    val organModel: Float = 0.9f,
    val tone: Int = 0,               // 0 B3, 1 PIPE, 2 FARF
    val octave: Int = 0,
    val rotaryOn: Boolean = true,
    val rotaryFast: Boolean = false,
    val cabinetOn: Boolean = true,
    val vibratoOn: Boolean = true,
    val vibratoMode: Int = 5,        // V1,V2,V3,C1,C2,C3
    val percSoft: Boolean = true,
    val percFast: Boolean = true,
    val percThird: Boolean = true,
    val eqOn: Boolean = true,
    val treble: Float = 0.5f,
    val mid: Float = 0.5f,
    val bass: Float = 0.5f,
    val driveOn: Boolean = true,
    val drive: Float = 0.15f,
    val reverbOn: Boolean = true,
    val reverb: Float = 0.35f,
    val reverbType: Int = 1,         // 0 Room, 1 Stage, 2 Hall
)

private val num = (0..10).map { it.toString() }
private val eqScale = listOf("-15dB", "-10", "-5", "0", "5", "10", "15dB")

/**
 * Écran de référence 800x360 dp (smartphone standard 360x800 en paysage).
 * Disposition : colonne gauche 17% | centre 46% | droite 37%.
 * Change les weight()/height() pour moduler nombre et taille des cases.
 */
@Composable
fun OrganScreen(
    state: OrganUiState,
    onStateChange: (OrganUiState) -> Unit,
    modifier: Modifier = Modifier,
    onPrevPreset: () -> Unit = {},
    onNextPreset: () -> Unit = {},
    onOpenPresets: (() -> Unit)? = null,
    drawbarSlot: @Composable BoxScope.() -> Unit = {
        Text("DRAWBARS", Modifier.align(Alignment.Center), color = P.TextMuted, fontSize = 12.sp)
    },
) {
    val s = state
    fun up(n: OrganUiState) = onStateChange(n)

    WoodBackground(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxSize().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {

            // ── Colonne gauche
            Column(Modifier.weight(0.17f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                WoodCard("Organ Model", Modifier.weight(1.7f).fillMaxWidth()) {
                    Knob3D(s.organModel, { up(s.copy(organModel = it)) }, size = 56.dp, scaleLabels = num, steps = 10)
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        listOf("B3", "PIPE", "FARF").forEachIndexed { i, l ->
                            LedOption(l, s.tone == i, { up(s.copy(tone = i)) })
                        }
                    }
                    OctaveSelector(s.octave, { up(s.copy(octave = it)) })
                }
                WoodCard("Rotary", Modifier.weight(0.8f).fillMaxWidth(), s.rotaryOn, { up(s.copy(rotaryOn = it)) }) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        LedButton("Speed", s.rotaryFast, { up(s.copy(rotaryFast = !s.rotaryFast)) }, ledColor = P.LedGreen, buttonWidth = 38.dp)
                        LedButton("Cabinet", s.cabinetOn, { up(s.copy(cabinetOn = !s.cabinetOn)) }, buttonWidth = 38.dp)
                    }
                }
            }

            // ── Centre
            Column(Modifier.weight(0.46f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                WoodCard("Presets", Modifier.height(80.dp).fillMaxWidth()) {
                    PresetDisplay(s.presetName, onPrevPreset, onNextPreset, Modifier.padding(horizontal = 6.dp), onOpenPresets)
                }
                WoodCard(null, Modifier.weight(1f).fillMaxWidth(), contentPadding = 0.dp) {
                    Box(Modifier.fillMaxSize(), content = drawbarSlot)
                }
            }

            // ── Droite
            Column(Modifier.weight(0.37f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.height(86.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WoodCard("Vibrato", Modifier.weight(1f).fillMaxHeight(), s.vibratoOn, { up(s.copy(vibratoOn = it)) }) {
                        VibratoChorusSelector(s.vibratoMode, { up(s.copy(vibratoMode = it)) })
                    }
                    WoodCard("B3 Percussion", Modifier.weight(1.2f).fillMaxHeight()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            LedButton("Soft", s.percSoft, { up(s.copy(percSoft = !s.percSoft)) }, buttonWidth = 34.dp)
                            LedButton("Fast", s.percFast, { up(s.copy(percFast = !s.percFast)) }, buttonWidth = 34.dp)
                            LedButton("Third", s.percThird, { up(s.copy(percThird = !s.percThird)) }, buttonWidth = 34.dp)
                        }
                    }
                }
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WoodCard("Equalizer", Modifier.weight(1.1f).fillMaxHeight(), s.eqOn, { up(s.copy(eqOn = it)) }) {
                        Knob3D(s.treble, { up(s.copy(treble = it)) }, label = "Treble", scaleLabels = eqScale)
                        Knob3D(s.mid, { up(s.copy(mid = it)) }, label = "Mid", scaleLabels = eqScale)
                        Knob3D(s.bass, { up(s.copy(bass = it)) }, label = "Bass", scaleLabels = eqScale)
                    }
                    Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        WoodCard("Drive", Modifier.weight(1f).fillMaxWidth(), s.driveOn, { up(s.copy(driveOn = it)) }) {
                            Knob3D(s.drive, { up(s.copy(drive = it)) }, label = "Amount", scaleLabels = num)
                        }
                        WoodCard("Reverb", Modifier.weight(1.3f).fillMaxWidth(), s.reverbOn, { up(s.copy(reverbOn = it)) }) {
                            Knob3D(s.reverb, { up(s.copy(reverb = it)) }, label = "Amount", scaleLabels = num)
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                listOf("ROOM", "STAGE", "HALL").forEachIndexed { i, l ->
                                    LedOption(l, s.reverbType == i, { up(s.copy(reverbType = i)) })
                                }
                            }
                            OrganButton({ up(s.copy(reverbType = (s.reverbType + 1) % 3)) }, width = 36.dp, height = 14.dp)
                        }
                    }
                }
            }
        }
    }
}

@Preview(widthDp = 800, heightDp = 360)
@Composable
fun OrganScreenPreview() {
    var s by remember { mutableStateOf(OrganUiState()) }
    OrganScreen(s, { s = it })
}
