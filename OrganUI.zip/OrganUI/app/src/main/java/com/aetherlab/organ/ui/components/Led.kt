package com.aetherlab.organ.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aetherlab.organ.ui.theme.WoodPalette

/** LED isolée : halo + lentille + reflet. */
@Composable
fun Led(
    on: Boolean,
    modifier: Modifier = Modifier,
    color: Color = WoodPalette.LedRed,
    diameter: Dp = 8.dp,
) {
    Canvas(modifier.size(diameter)) {
        val r = this.size.minDimension / 2f
        if (on) drawCircle(color.copy(alpha = 0.30f), radius = r * 1.9f)
        drawCircle(Color(0xFF0A0706), radius = r)
        drawCircle(
            brush = Brush.radialGradient(
                colors = if (on) listOf(Color.White.copy(0.9f), color, color.copy(alpha = 0.6f))
                else listOf(color.copy(0.35f), color.copy(0.18f), Color(0xFF1A0E0B)),
                center = Offset(r * 0.8f, r * 0.7f),
                radius = r,
            ),
            radius = r * 0.82f,
        )
        drawCircle(
            Color.White.copy(alpha = if (on) 0.5f else 0.15f),
            radius = r * 0.18f,
            center = Offset(r * 0.7f, r * 0.6f),
        )
    }
}
