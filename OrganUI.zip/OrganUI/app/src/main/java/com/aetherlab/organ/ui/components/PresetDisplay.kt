package com.aetherlab.organ.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aetherlab.organ.ui.theme.WoodPalette as P

/** Remplace "Programs" : < nom du preset utilisateur >. Tap sur l'écran = ouvrir ta liste. */
@Composable
fun PresetDisplay(
    name: String,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier,
    onOpenList: (() -> Unit)? = null,
    caption: String = "USER PRESET",
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OrganButton(onPrev, width = 34.dp, height = 22.dp) { Text("◀", color = P.TextMain, fontSize = 9.sp) }
            val shape = RoundedCornerShape(5.dp)
            Box(
                Modifier
                    .weight(1f)
                    .height(32.dp)
                    .clip(shape)
                    .background(Brush.verticalGradient(listOf(Color.Black, P.DisplayBg)))
                    .border(1.dp, Color(0xFF5A4636), shape)
                    .clickable(enabled = onOpenList != null) { onOpenList?.invoke() }
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    name, color = P.Amber, fontFamily = FontFamily.Monospace, fontSize = 14.sp,
                    fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = TextStyle(shadow = Shadow(P.AmberGlow, blurRadius = 12f)),
                )
            }
            OrganButton(onNext, width = 34.dp, height = 22.dp) { Text("▶", color = P.TextMain, fontSize = 9.sp) }
        }
        Text(caption, color = P.TextMuted, fontSize = 7.sp)
    }
}
